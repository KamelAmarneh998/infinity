# Sourced by Plasma at login. Infinity's renamed app entries
# (/usr/lib/infinity/app-names) come before the apps' own ones.
case ":${XDG_DATA_DIRS}:" in
    *:/var/lib/infinity/xdg:*) ;;
    *) export XDG_DATA_DIRS="/var/lib/infinity/xdg:${XDG_DATA_DIRS:-/usr/local/share:/usr/share}" ;;
esac
