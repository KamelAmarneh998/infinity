// While installing: slides about Infinity, one every 8 seconds. Calamares
// draws the progress bar and the current step under them.
import QtQuick

Rectangle {
    id: show
    color: "#101630"
    property bool activatedInCalamares: false
    function onActivate() { activatedInCalamares = true }
    function onLeave() { activatedInCalamares = false }

    FontLoader { id: medium; source: "file:///usr/share/sddm/themes/infinity/Montserrat-Medium.ttf" }

    property int current: 0
    readonly property var slides: [
        { title: qsTr("Updates take care of themselves"),
          text: qsTr("Infinity checks for updates and installs them while you are away. It never restarts on its own."),
          icon: "slide-updates.svg" },
        { title: qsTr("Protected from day one"),
          text: qsTr("The firewall is on, and every file you download is checked. Anything dangerous is locked away."),
          icon: "slide-security.svg" },
        { title: qsTr("Brave and VLC are ready"),
          text: qsTr("A fast, private browser and a player that opens any video or song. Nothing else you didn't ask for."),
          icon: "slide-apps.svg" },
        { title: qsTr("Light by day, Night after sunset"),
          text: qsTr("Pick Light, Night or Automatic. Windows, the dock and the wallpaper change together."),
          icon: "slide-look.svg" },
        { title: qsTr("Install apps with a double-click"),
          text: qsTr("Open a downloaded app and Infinity installs it, or find thousands more in Settings > Apps."),
          icon: "slide-install.svg" },
        { title: qsTr("Downloads that finish faster"),
          text: qsTr("Every download from Brave runs over several connections, and videos get a Download button."),
          icon: "slide-downloads.svg" },
        { title: qsTr("Settings that show you everything"),
          text: qsTr("Wi-Fi, battery, sound, security and updates at a glance. Click a tile and it opens."),
          icon: "slide-settings.svg" }
    ]
    Timer {
        interval: 8000
        running: show.activatedInCalamares
        repeat: true
        onTriggered: show.current = (show.current + 1) % show.slides.length
    }

    Rectangle {
        anchors.fill: parent
        anchors.leftMargin: 48
        anchors.rightMargin: 48
        anchors.topMargin: 16
        anchors.bottomMargin: 10
        radius: 18
        border.color: Qt.rgba(125 / 255, 151 / 255, 1, 0.12)
        gradient: Gradient {
            orientation: Gradient.Horizontal
            GradientStop { position: 0; color: "#0B1230" }
            GradientStop { position: 1; color: "#1A2A6A" }
        }
        clip: true

        Repeater {
            model: show.slides
            Item {
                anchors.fill: parent
                opacity: index === show.current ? 1 : 0
                Behavior on opacity { NumberAnimation { duration: 600 } }

                Column {
                    anchors.left: parent.left
                    anchors.leftMargin: 56
                    anchors.verticalCenter: parent.verticalCenter
                    width: parent.width * 0.5
                    spacing: 12
                    Text {
                        width: parent.width
                        text: modelData.title
                        color: "#E8ECFA"
                        font.family: medium.name
                        font.pixelSize: 30
                        wrapMode: Text.Wrap
                    }
                    Text {
                        width: parent.width
                        text: modelData.text
                        color: "#A9B1D1"
                        font.pixelSize: 16
                        wrapMode: Text.Wrap
                        lineHeight: 1.2
                    }
                }
                Image {
                    anchors.right: parent.right
                    anchors.rightMargin: parent.width * 0.12
                    anchors.verticalCenter: parent.verticalCenter
                    source: modelData.icon
                    sourceSize.width: Math.min(parent.height * 0.5, 200)
                    sourceSize.height: Math.min(parent.height * 0.5, 200)
                }
            }
        }
    }
}
