// Top of the installer card: the mark, one dot per step (the current one
// long), and the current step's name.
import io.calamares.ui 1.0
import io.calamares.core 1.0
import QtQuick

Rectangle {
    id: bar
    height: 60
    color: "#101630"

    // Our names for the steps, in settings.conf's order (Calamares' own
    // names are used for anything not listed).
    readonly property var names: ["Welcome", "Keyboard", "Location", "Disk", "You", "Ready", "Installing", "Done"]

    Image {
        x: 32
        anchors.verticalCenter: parent.verticalCenter
        source: "mark.svg"
        sourceSize.width: 44
        sourceSize.height: 22
    }

    Row {
        anchors.centerIn: parent
        spacing: 8
        Repeater {
            model: ViewManager
            Rectangle {
                readonly property bool current: index === ViewManager.currentStepIndex
                anchors.verticalCenter: parent.verticalCenter
                width: current ? 26 : 8
                height: 8
                radius: 4
                color: current ? "#4169E1" : index < ViewManager.currentStepIndex ? "#7D97FF" : Qt.rgba(1, 1, 1, 0.18)
                Behavior on width { NumberAnimation { duration: 250; easing.type: Easing.OutCubic } }
                Behavior on color { ColorAnimation { duration: 250 } }
                onCurrentChanged: if (current) stepName.text = index < bar.names.length ? bar.names[index] : display
                Component.onCompleted: if (current) stepName.text = index < bar.names.length ? bar.names[index] : display
            }
        }
    }

    Text {
        id: stepName
        anchors.right: parent.right
        anchors.rightMargin: 32
        anchors.verticalCenter: parent.verticalCenter
        color: "#8A93B8"
        font.pixelSize: 14
    }
}
