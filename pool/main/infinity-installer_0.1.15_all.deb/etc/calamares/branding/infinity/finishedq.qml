// Done: restart into the new system (or keep using the live USB). If the
// install failed, says so and shows what went wrong.
import io.calamares.core 1.0
import io.calamares.ui 1.0
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

Item {
    id: page
    Rectangle { anchors.fill: parent; color: "#101630" }
    FontLoader { id: light; source: "file:///usr/share/sddm/themes/infinity/Montserrat-Light.ttf" }

    ColumnLayout {
        anchors.centerIn: parent
        width: Math.min(parent.width - 96, 720)
        spacing: 18

        Rectangle {
            Layout.alignment: Qt.AlignHCenter
            width: 96; height: 96; radius: 48
            color: config.failed ? Qt.rgba(1, 107 / 255, 122 / 255, 0.16) : Qt.rgba(94 / 255, 214 / 255, 160 / 255, 0.15)
            Text {
                anchors.centerIn: parent
                text: config.failed ? "!" : "✓"
                color: config.failed ? "#FF6B7A" : "#5ED6A0"
                font.pixelSize: 44
                font.bold: true
            }
        }
        Text {
            Layout.alignment: Qt.AlignHCenter
            text: config.failed ? qsTr("The install didn't finish") : qsTr("%1 is installed").arg(Branding.string(Branding.ProductName))
            color: "#E8ECFA"
            font.family: light.name
            font.pixelSize: 36
        }
        Text {
            Layout.fillWidth: true
            horizontalAlignment: Text.AlignHCenter
            wrapMode: Text.Wrap
            color: "#8A93B8"
            font.pixelSize: 16
            text: config.failed ? config.failureMessage
                : qsTr("Restart to start using it. Take out the USB stick when the screen goes dark.")
        }
        ScrollView {
            visible: config.failed && config.failureDetails !== ""
            Layout.fillWidth: true
            Layout.preferredHeight: 160
            TextArea {
                readOnly: true
                text: config.failureDetails
                color: "#E8ECFA"
                font.family: "monospace"
                font.pixelSize: 12
                wrapMode: Text.Wrap
                background: Rectangle { radius: 10; color: Qt.rgba(1, 1, 1, 0.04) }
            }
        }
        RowLayout {
            Layout.alignment: Qt.AlignHCenter
            Layout.topMargin: 8
            spacing: 14
            Pill {
                text: config.failed ? qsTr("Close") : qsTr("Keep trying")
                onClicked: ViewManager.quit()
            }
            Pill {
                visible: !config.failed
                primary: true
                big: true
                text: qsTr("Restart now")
                onClicked: config.doRestart(true)
            }
        }
    }
}
