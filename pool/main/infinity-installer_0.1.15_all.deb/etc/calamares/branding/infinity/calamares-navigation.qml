// Bottom of the installer card: Back and Next. Hidden on the first screen
// (it has its own buttons), while installing and on the last screen.
import io.calamares.ui 1.0
import io.calamares.core 1.0
import QtQuick
import QtQuick.Layouts

Rectangle {
    id: nav
    height: 64
    color: "#101630"

    readonly property bool first: ViewManager.currentStepIndex === 0
    readonly property bool last: ViewManager.currentStepIndex === ViewManager.rowCount() - 1
    readonly property bool shown: ViewManager.backAndNextVisible && !first && !last
    // The step before the install (the summary) says what Next will do.
    readonly property bool installNext: ViewManager.currentStepIndex === ViewManager.rowCount() - 3

    RowLayout {
        anchors.fill: parent
        anchors.leftMargin: 40
        anchors.rightMargin: 40
        anchors.bottomMargin: 18
        spacing: 14
        visible: nav.shown

        Pill {
            text: qsTr("Back")
            enabled: ViewManager.backEnabled
            onClicked: ViewManager.back()
        }
        Text {
            Layout.fillWidth: true
            text: nav.installNext ? qsTr("The disk changes after this.") : ""
            color: "#8A93B8"
            font.pixelSize: 13
        }
        Pill {
            primary: true
            text: nav.installNext ? qsTr("Install now") : qsTr("Next")
            enabled: ViewManager.nextEnabled
            onClicked: ViewManager.next()
        }
    }
}
