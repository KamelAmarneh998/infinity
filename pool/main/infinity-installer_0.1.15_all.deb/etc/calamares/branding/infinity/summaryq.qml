// Ready: what each step will do (Calamares' own summaries), and what the
// installer found out about this computer (infinity-installer's hardware
// probe, /tmp/infinity-hardware.json).
import io.calamares.core 1.0
import io.calamares.ui 1.0
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

Item {
    id: page
    Rectangle { anchors.fill: parent; color: "#101630" }

    property var hw: ({})
    Component.onCompleted: {
        var x = new XMLHttpRequest()
        x.onreadystatechange = function () {
            if (x.readyState === XMLHttpRequest.DONE && x.responseText !== "") {
                try { hw = JSON.parse(x.responseText) } catch (e) { }
            }
        }
        x.open("GET", "file:///tmp/infinity-hardware.json")
        x.send()
    }

    // [label, value, note, good] rows for "This computer".
    function hardwareRows() {
        var rows = []
        if (hw.gpu) rows.push([qsTr("Graphics"), hw.gpu,
            hw.nvidia ? qsTr("works now; the faster NVIDIA driver can be added later in Settings")
                      : hw.gpuDriver ? qsTr("works out of the box") : qsTr("basic driver"), !!hw.gpuDriver && !hw.nvidia])
        if (hw.wifi) rows.push([qsTr("Wi-Fi"), hw.wifi,
            hw.wifiDriver ? qsTr("driver included") : qsTr("no driver found: use a cable to get updates"), !!hw.wifiDriver])
        if (hw.cpu) rows.push([qsTr("Processor"), hw.cpu + " · " + qsTr("%1 cores").arg(hw.cores) + " · " + qsTr("%1 GB memory").arg(hw.memory), "", false])
        return rows
    }

    Flickable {
        anchors.fill: parent
        anchors.leftMargin: 48
        anchors.rightMargin: 48
        anchors.topMargin: 20
        contentHeight: column.implicitHeight + 12
        clip: true
        boundsBehavior: Flickable.StopAtBounds
        ScrollBar.vertical: ThinScrollBar { }

        ColumnLayout {
            id: column
            width: parent.width - 18 // room for the scroll bar
            spacing: 14

            Heading { text: qsTr("Ready to install") }
            Text {
                Layout.fillWidth: true
                Layout.topMargin: -6
                text: qsTr("Check this over. Nothing has changed yet; after <b>Install now</b> the disk changes for real.")
                textFormat: Text.StyledText
                color: "#8A93B8"
                font.pixelSize: 15
                wrapMode: Text.Wrap
            }

            Repeater {
                model: config.summaryModel
                delegate: Card {
                    Layout.fillWidth: true
                    title: model.title
                    Text {
                        width: parent.width
                        text: model.message
                        textFormat: Text.RichText
                        wrapMode: Text.Wrap
                        color: "#E8ECFA"
                        linkColor: "#7D97FF"
                        font.pixelSize: 14
                    }
                }
            }

            Card {
                Layout.fillWidth: true
                visible: page.hardwareRows().length > 0
                title: qsTr("This computer")
                Repeater {
                    model: page.hardwareRows()
                    delegate: Row {
                        width: parent.width
                        spacing: 14
                        Text { width: 90; text: modelData[0]; color: "#8A93B8"; font.pixelSize: 14 }
                        Text {
                            width: parent.width - 104
                            wrapMode: Text.Wrap
                            textFormat: Text.StyledText
                            font.pixelSize: 14
                            color: "#E8ECFA"
                            text: modelData[1] + (modelData[2] ? " · <font color='" + (modelData[3] ? "#5ED6A0" : "#FFB547") + "'>" + modelData[2] + "</font>" : "")
                        }
                    }
                }
            }
        }
    }
}
