// You: name, account name, password and the computer's name.
import io.calamares.core 1.0
import io.calamares.ui 1.0
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

Item {
    id: page
    Rectangle { anchors.fill: parent; color: "#101630" }
    FontLoader { id: medium; source: "file:///usr/share/sddm/themes/infinity/Montserrat-Medium.ttf" }

    function strength(p) {
        var s = 0
        if (p.length >= 8) s++
        if (p.length >= 12) s++
        if (/[0-9]/.test(p) && /[a-zA-Z]/.test(p)) s++
        if (/[^a-zA-Z0-9]/.test(p)) s++
        return s
    }

    ColumnLayout {
        anchors.fill: parent
        anchors.leftMargin: 48
        anchors.rightMargin: 48
        anchors.topMargin: 20
        anchors.bottomMargin: 8
        spacing: 18

        Heading { text: qsTr("Who will use this computer?") }

        RowLayout {
            Layout.fillWidth: true
            spacing: 26

            Rectangle {
                Layout.alignment: Qt.AlignTop
                Layout.topMargin: 6
                width: 84; height: 84; radius: 42
                gradient: Gradient {
                    GradientStop { position: 0; color: "#7D97FF" }
                    GradientStop { position: 1; color: "#2B4FD8" }
                }
                border.width: 3
                border.color: Qt.rgba(1, 1, 1, 0.12)
                Text {
                    anchors.centerIn: parent
                    text: config.fullName.trim() !== "" ? config.fullName.trim()[0].toUpperCase() : "?"
                    color: "white"
                    font.family: medium.name
                    font.pixelSize: 34
                }
            }

            GridLayout {
                Layout.fillWidth: true
                columns: 2
                columnSpacing: 20
                rowSpacing: 10

                Field {
                    Layout.fillWidth: true
                    Layout.preferredWidth: 1
                    Layout.alignment: Qt.AlignTop
                    label: qsTr("Your name")
                    text: config.fullName
                    onEdited: function (t) { config.setFullName(t) }
                    Component.onCompleted: input.forceActiveFocus()
                }
                Field {
                    Layout.fillWidth: true
                    Layout.preferredWidth: 1
                    Layout.alignment: Qt.AlignTop
                    label: qsTr("Account name")
                    text: config.loginName
                    onEdited: function (t) { config.setLoginName(t) }
                    hint: config.loginNameStatus !== "" ? config.loginNameStatus : qsTr("Lower-case letters and numbers. You don't type it to log in.")
                    hintKind: config.loginNameStatus !== "" ? -1 : 0
                }
                Field {
                    id: pw1
                    Layout.fillWidth: true
                    Layout.preferredWidth: 1
                    Layout.alignment: Qt.AlignTop
                    label: qsTr("Password")
                    echoMode: TextInput.Password
                    text: config.userPassword
                    onEdited: function (t) { config.setUserPassword(t) }
                    readonly property int score: page.strength(text)
                    hint: text === "" ? qsTr("At least 8 characters.")
                        : text.length < 8 ? qsTr("Too short: at least 8 characters.")
                        : [qsTr("Weak"), qsTr("Okay"), qsTr("Okay"), qsTr("Strong"), qsTr("Very strong")][score]
                    hintKind: text !== "" && text.length < 8 ? -1 : score >= 3 ? 1 : 0
                }
                Field {
                    Layout.fillWidth: true
                    Layout.preferredWidth: 1
                    Layout.alignment: Qt.AlignTop
                    label: qsTr("Password again")
                    echoMode: TextInput.Password
                    text: config.userPasswordSecondary
                    onEdited: function (t) { config.setUserPasswordSecondary(t) }
                    hint: text === "" ? "" : text === pw1.text ? qsTr("They match.") : qsTr("They don't match.")
                    hintKind: text === "" ? 0 : text === pw1.text ? 1 : -1
                }
                // strength bar, under the first password field
                Rectangle {
                    Layout.fillWidth: true
                    Layout.topMargin: -6
                    height: 4
                    radius: 2
                    color: Qt.rgba(1, 1, 1, 0.08)
                    Rectangle {
                        height: parent.height
                        radius: 2
                        width: pw1.text === "" ? 0 : parent.width * Math.max(0.12, pw1.score / 4)
                        color: pw1.text.length < 8 ? "#FF6B7A" : pw1.score >= 3 ? "#5ED6A0" : "#FFB547"
                        Behavior on width { NumberAnimation { duration: 200 } }
                    }
                }
                Item { Layout.fillWidth: true; height: 1 }
                Field {
                    Layout.fillWidth: true
                    Layout.preferredWidth: 1
                    Layout.alignment: Qt.AlignTop
                    label: qsTr("Computer name")
                    text: config.hostname
                    onEdited: function (t) { config.setHostName(t) }
                    hint: config.hostnameStatus !== "" ? config.hostnameStatus : qsTr("How other devices on the network see it.")
                    hintKind: config.hostnameStatus !== "" ? -1 : 0
                }
            }
        }

        Text {
            Layout.fillWidth: true
            // Calamares' own verdict; its "OK!" for a good password adds nothing.
            visible: config.userPasswordMessage !== "" && config.userPasswordMessage !== "OK!" && pw1.text.length >= 8
            text: config.userPasswordMessage
            color: config.userPasswordValidity === 2 ? "#FF6B7A" : "#FFB547"
            font.pixelSize: 13
            wrapMode: Text.Wrap
        }

        RowLayout {
            Layout.fillWidth: true
            spacing: 16
            Column {
                Layout.fillWidth: true
                spacing: 2
                Text { text: qsTr("Log in without the password"); color: "#E8ECFA"; font.pixelSize: 15; font.weight: Font.Medium }
                Text {
                    width: parent.width
                    text: qsTr("Starts straight to the desktop. The password is still needed to make changes.")
                    color: "#8A93B8"; font.pixelSize: 13; wrapMode: Text.Wrap
                }
            }
            Toggle {
                on: config.doAutoLogin
                onToggled: config.setAutoLogin(!config.doAutoLogin)
            }
        }
        Item { Layout.fillHeight: true }
    }
}
