// A round account picture: the first letter of the name on royal blue.
import QtQuick

Rectangle {
    property real size: 48
    property string letter: ""
    property string fontFamily: ""
    width: size
    height: size
    radius: size / 2
    gradient: Gradient {
        GradientStop { position: 0; color: "#7D97FF" }
        GradientStop { position: 1; color: "#2B4FD8" }
    }
    border.color: Qt.rgba(1, 1, 1, 0.14)
    border.width: Math.max(1, size * 0.03)
    Text {
        anchors.centerIn: parent
        text: letter.length ? letter.charAt(0).toUpperCase() : ""
        color: "white"
        font.family: fontFamily
        font.weight: Font.Medium
        font.pixelSize: size * 0.4
    }
}
