// Infinity lock screen, as designed in distro/branding/system-preview.html:
// the login screen's card again (clock, date, the user, the password field),
// so locking and signing in look like one screen, with the same Sleep /
// Restart / Shut down buttons at the bottom right (no user switching); music
// that is playing shows below the card.
//
// kscreenlocker loads this file from the Plasma shell package; the stock one
// is diverted to LockScreen.qml.infinity-stock by infinity-branding's preinst.
// Shared pieces (fonts, icons, Avatar, InfinityMark) come from the login theme.
import QtQuick
import org.kde.coreaddons as KCoreAddons
import org.kde.plasma.private.keyboardindicator as KeyboardIndicator
import org.kde.plasma.private.mpris as Mpris
import org.kde.plasma.private.sessions
import org.kde.plasma.workspace.components as PW
import "file:///usr/share/sddm/themes/infinity" as Ui

Item {
    id: root
    property bool debug: false
    property string notification
    signal clearPassword()
    signal notificationRepeated()

    // These are magical properties that kscreenlocker looks for
    property bool viewVisible: false
    property bool suspendToRamSupported: false
    property bool suspendToDiskSupported: false

    // These are magical signals that kscreenlocker looks for
    signal suspendToDisk()
    signal suspendToRam()

    implicitWidth: 800
    implicitHeight: 600

    readonly property string assets: "file:///usr/share/sddm/themes/infinity/"
    // One unit = 1.25% of the screen width, as on the login screen.
    readonly property real u: Math.max(10, width * 0.0125)

    readonly property color ink: "#E8ECFA"
    readonly property color inkSoft: Qt.rgba(232 / 255, 236 / 255, 250 / 255, 0.78)
    readonly property color muted: "#8A93B8"
    readonly property color royal: "#4169E1"
    readonly property color royalLight: "#7D97FF"
    readonly property color glass: Qt.rgba(14 / 255, 20 / 255, 44 / 255, 0.62)
    readonly property color line: Qt.rgba(125 / 255, 151 / 255, 1, 0.22)
    readonly property color errorColor: "#FF6B7A"
    readonly property string uiFont: "Noto Sans"

    // An account without a password unlocks with the button alone.
    property bool noPassword: false

    // kscreenlocker only accepts a password while a check is running, and a
    // check can end on its own (e.g. after the screen went to sleep). Like
    // KDE's own lock screen, start one whenever the user shows up: a key
    // press or a mouse move. Starting while one runs does nothing.
    property double lastWake: 0
    function wake() {
        const now = Date.now()
        if (graceTimer.running || now - lastWake < 1000) // mouse moves come in floods
            return
        lastWake = now
        authenticator.startAuthenticating()
    }

    function unlock() {
        if (noPassword) {
            Qt.quit()
            return
        }
        if (!field.enabled)
            return
        message.text = ""
        authenticator.respond(password.text)
    }

    FontLoader { id: wordFont; source: root.assets + "Montserrat-Light.ttf" }
    FontLoader { source: root.assets + "Montserrat-Medium.ttf" }

    KCoreAddons.KUser { id: kuser }
    KeyboardIndicator.KeyState { id: capsLock; key: Qt.Key_CapsLock }
    SessionManagement { id: sessionManagement }

    Connections {
        target: authenticator
        function onFailed(kind) {
            if (kind != 0) // fingerprint and smartcard are turned off on Infinity
                return
            message.color = root.errorColor
            message.text = "Wrong password. Try again."
            password.text = ""
            shake.restart()
            graceTimer.restart()
        }
        function onSucceeded() {
            if (authenticator.hadPrompt) {
                Qt.quit()
            } else {
                root.noPassword = true
                go.forceActiveFocus()
            }
        }
        function onInfoMessageChanged() {
            message.color = root.inkSoft
            message.text = authenticator.infoMessage
        }
        function onErrorMessageChanged() {
            message.color = root.errorColor
            message.text = authenticator.errorMessage
        }
        function onPromptForSecretChanged() {
            password.forceActiveFocus()
        }
    }
    Connections {
        target: sessionManagement
        function onAboutToSuspend() { root.clearPassword() }
    }
    onClearPassword: password.text = ""

    // PAM waits a moment after a wrong password; then ask again.
    Timer {
        id: graceTimer
        interval: 2000
        onTriggered: {
            authenticator.startAuthenticating()
            password.forceActiveFocus()
        }
    }

    Timer {
        id: clock
        property date now: new Date()
        interval: 1000
        running: true
        repeat: true
        triggeredOnStart: true
        onTriggered: now = new Date()
    }

    Rectangle {
        id: content
        anchors.fill: parent
        color: "#070B1C"

        NumberAnimation on opacity { from: 0; to: 1; duration: 450; easing.type: Easing.InOutQuad }

        Image {
            anchors.fill: parent
            source: root.assets + "background.png"
            fillMode: Image.PreserveAspectCrop
        }
        Ui.InfinityMark { screen: content }

        MouseArea {
            anchors.fill: parent
            hoverEnabled: true
            onPositionChanged: root.wake()
            onClicked: { root.wake(); password.forceActiveFocus() }
        }

        // ---------- the card ----------
        Rectangle {
            id: card
            anchors.centerIn: parent
            width: 25 * root.u
            height: column.implicitHeight + 3.8 * root.u
            radius: 1.4 * root.u
            color: root.glass
            border.color: root.line
            border.width: 1

            Column {
                id: column
                y: 2.2 * root.u
                anchors.horizontalCenter: parent.horizontalCenter
                width: parent.width - 4.4 * root.u
                spacing: 0.9 * root.u

                Text {
                    anchors.horizontalCenter: parent.horizontalCenter
                    text: Qt.formatTime(clock.now, "h:mm AP")
                    color: root.ink
                    font.family: wordFont.name
                    font.weight: Font.Light
                    font.pixelSize: 3.4 * root.u
                }
                Text {
                    anchors.horizontalCenter: parent.horizontalCenter
                    text: Qt.formatDate(clock.now, "dddd, MMMM d")
                    color: root.inkSoft
                    font.family: root.uiFont
                    font.pixelSize: root.u
                }
                Row {
                    anchors.horizontalCenter: parent.horizontalCenter
                    topPadding: 0.6 * root.u
                    spacing: 0.7 * root.u
                    Ui.Avatar {
                        size: 3 * root.u
                        letter: kuser.fullName || kscreenlocker_userName
                        fontFamily: wordFont.name
                        anchors.verticalCenter: parent.verticalCenter
                    }
                    Text {
                        anchors.verticalCenter: parent.verticalCenter
                        text: kuser.fullName || kscreenlocker_userName
                        color: root.ink
                        font.family: root.uiFont
                        font.weight: Font.Medium
                        font.pixelSize: 1.35 * root.u
                    }
                }

                // Password field: on a wrong password only this field shakes.
                Item {
                    id: field
                    width: parent.width
                    height: 2.9 * root.u
                    enabled: !graceTimer.running
                    transform: Translate { id: shakeOffset }

                    Rectangle {
                        anchors.fill: parent
                        radius: height / 2
                        visible: !root.noPassword
                        color: Qt.rgba(1, 1, 1, 0.08)
                        border.color: password.activeFocus ? root.royalLight : Qt.rgba(1, 1, 1, 0.16)
                        border.width: 1
                    }
                    TextInput {
                        id: password
                        visible: !root.noPassword
                        anchors.left: parent.left
                        anchors.leftMargin: 1.2 * root.u
                        anchors.right: go.left
                        anchors.rightMargin: 0.6 * root.u
                        anchors.verticalCenter: parent.verticalCenter
                        echoMode: TextInput.Password
                        passwordCharacter: "•"
                        color: root.ink
                        selectionColor: root.royal
                        font.family: root.uiFont
                        font.pixelSize: root.u
                        clip: true
                        focus: true
                        Keys.onPressed: event => { root.wake(); event.accepted = false }
                        Keys.onReturnPressed: root.unlock()
                        Keys.onEnterPressed: root.unlock()
                        // Escape turns the screen off (kscreenlocker); start over.
                        Keys.onEscapePressed: event => { password.text = ""; event.accepted = false }

                        Text {
                            anchors.verticalCenter: parent.verticalCenter
                            visible: password.text.length === 0
                            text: "Password"
                            color: Qt.rgba(232 / 255, 236 / 255, 250 / 255, 0.5)
                            font: password.font
                        }
                    }
                    Rectangle {
                        id: go
                        width: root.noPassword ? parent.width : 2.2 * root.u
                        height: root.noPassword ? parent.height : width
                        radius: height / 2
                        anchors.right: parent.right
                        anchors.rightMargin: root.noPassword ? 0 : 0.35 * root.u
                        anchors.verticalCenter: parent.verticalCenter
                        color: goArea.containsMouse ? root.royalLight : root.royal
                        Keys.onReturnPressed: root.unlock()
                        Keys.onEnterPressed: root.unlock()
                        Image {
                            anchors.centerIn: parent
                            visible: !root.noPassword
                            source: root.assets + "icons/arrow.svg"
                            sourceSize.width: root.u
                            sourceSize.height: root.u
                        }
                        Text {
                            anchors.centerIn: parent
                            visible: root.noPassword
                            text: "Unlock"
                            color: "white"
                            font.family: root.uiFont
                            font.weight: Font.Medium
                            font.pixelSize: root.u
                        }
                        MouseArea {
                            id: goArea
                            anchors.fill: parent
                            hoverEnabled: true
                            cursorShape: Qt.PointingHandCursor
                            onClicked: root.unlock()
                        }
                    }

                    SequentialAnimation {
                        id: shake
                        NumberAnimation { target: shakeOffset; property: "x"; to: -0.6 * root.u; duration: 60 }
                        NumberAnimation { target: shakeOffset; property: "x"; to: 0.6 * root.u; duration: 80 }
                        NumberAnimation { target: shakeOffset; property: "x"; to: -0.6 * root.u; duration: 80 }
                        NumberAnimation { target: shakeOffset; property: "x"; to: 0.6 * root.u; duration: 80 }
                        NumberAnimation { target: shakeOffset; property: "x"; to: 0; duration: 60 }
                    }
                }

                Text {
                    id: message
                    width: parent.width
                    height: 1.4 * root.u
                    horizontalAlignment: Text.AlignHCenter
                    elide: Text.ElideRight
                    color: root.errorColor
                    font.family: root.uiFont
                    font.pixelSize: 0.9 * root.u
                }

                Row {
                    anchors.horizontalCenter: parent.horizontalCenter
                    spacing: 0.4 * root.u
                    Image {
                        anchors.verticalCenter: parent.verticalCenter
                        source: root.assets + "icons/lock.svg"
                        sourceSize.width: 0.9 * root.u
                        sourceSize.height: 0.9 * root.u
                        opacity: 0.6
                    }
                    Text {
                        anchors.verticalCenter: parent.verticalCenter
                        text: capsLock.locked ? "Locked · Caps Lock is on" : "Locked"
                        color: root.muted
                        font.family: root.uiFont
                        font.pixelSize: 0.8 * root.u
                    }
                }
            }
        }

        // ---------- now playing (only while a player is open) ----------
        Repeater {
            model: Mpris.MultiplexerModel { }
            delegate: Rectangle {
                anchors.horizontalCenter: parent.horizontalCenter
                anchors.bottom: parent.bottom
                anchors.bottomMargin: root.height * 0.06
                width: mediaRow.implicitWidth + 1.5 * root.u
                height: 4 * root.u
                radius: root.u
                color: root.glass
                border.color: root.line
                border.width: 1

                Row {
                    id: mediaRow
                    x: 0.6 * root.u
                    anchors.verticalCenter: parent.verticalCenter
                    spacing: 0.9 * root.u

                    Rectangle {
                        width: 2.8 * root.u
                        height: width
                        radius: 0.6 * root.u
                        clip: true
                        gradient: Gradient {
                            GradientStop { position: 0; color: "#7D97FF" }
                            GradientStop { position: 1; color: "#2B4FD8" }
                        }
                        Image {
                            anchors.fill: parent
                            source: model.artUrl || ""
                            fillMode: Image.PreserveAspectCrop
                            asynchronous: true
                        }
                    }
                    Column {
                        anchors.verticalCenter: parent.verticalCenter
                        width: Math.min(14 * root.u, Math.max(trackText.implicitWidth, appText.implicitWidth))
                        Text {
                            id: trackText
                            width: parent.width
                            elide: Text.ElideRight
                            text: model.track || "No title"
                            color: root.ink
                            font.family: root.uiFont
                            font.weight: Font.Medium
                            font.pixelSize: 0.9 * root.u
                        }
                        Text {
                            id: appText
                            width: parent.width
                            elide: Text.ElideRight
                            text: model.artist || model.identity || ""
                            color: root.muted
                            font.family: root.uiFont
                            font.pixelSize: 0.78 * root.u
                        }
                    }
                    Repeater {
                        model: [
                            { icon: "previous", run: () => model.container.Previous(), on: model.canGoPrevious },
                            { icon: model.playbackStatus === Mpris.PlaybackStatus.Playing ? "pause" : "play",
                              run: () => model.container.PlayPause(), on: true },
                            { icon: "next", run: () => model.container.Next(), on: model.canGoNext }
                        ]
                        delegate: Rectangle {
                            anchors.verticalCenter: parent.verticalCenter
                            width: 2 * root.u
                            height: width
                            radius: width / 2
                            color: mediaArea.containsMouse ? Qt.rgba(1, 1, 1, 0.08) : "transparent"
                            opacity: modelData.on ? 1 : 0.35
                            Image {
                                anchors.centerIn: parent
                                source: root.assets + "icons/" + modelData.icon + ".svg"
                                sourceSize.width: root.u
                                sourceSize.height: root.u
                            }
                            MouseArea {
                                id: mediaArea
                                anchors.fill: parent
                                hoverEnabled: true
                                enabled: modelData.on
                                onClicked: modelData.run()
                            }
                        }
                    }
                }
            }
        }

        // ---------- Sleep / Restart / Shut down (bottom right, as on the login screen) ----------
        Row {
            anchors.right: parent.right
            anchors.rightMargin: root.width * 0.04
            anchors.bottom: parent.bottom
            anchors.bottomMargin: root.height * 0.05
            spacing: root.u

            Ui.PowerButton {
                u: root.u; fontFamily: root.uiFont; icon: root.assets + "icons/sleep.svg"; label: "Sleep"
                visible: root.suspendToRamSupported
                onActivated: root.suspendToRam()
            }
            Ui.PowerButton {
                u: root.u; fontFamily: root.uiFont; icon: root.assets + "icons/restart.svg"; label: "Restart"
                visible: sessionManagement.canReboot
                onActivated: sessionManagement.requestReboot(SessionManagement.Skip)
            }
            Ui.PowerButton {
                u: root.u; fontFamily: root.uiFont; icon: root.assets + "icons/off.svg"; label: "Shut down"
                visible: sessionManagement.canShutdown
                onActivated: sessionManagement.requestShutdown(SessionManagement.Skip)
            }
        }

        // ---------- keyboard layout (bottom left, only with several) ----------
        Rectangle {
            anchors.left: parent.left
            anchors.leftMargin: root.width * 0.04
            anchors.bottom: parent.bottom
            anchors.bottomMargin: root.height * 0.05 + 0.6 * root.u
            visible: layouts.hasMultipleKeyboardLayouts
            width: layoutRow.implicitWidth + 1.4 * root.u
            height: 2.4 * root.u
            radius: height / 2
            color: root.glass
            border.color: root.line
            border.width: 1
            Row {
                id: layoutRow
                anchors.centerIn: parent
                spacing: 0.5 * root.u
                Image {
                    anchors.verticalCenter: parent.verticalCenter
                    source: root.assets + "icons/keyboard.svg"
                    sourceSize.width: root.u
                    sourceSize.height: root.u
                }
                Text {
                    anchors.verticalCenter: parent.verticalCenter
                    text: layouts.layoutNames.shortName.toUpperCase()
                    color: root.inkSoft
                    font.family: root.uiFont
                    font.pixelSize: 0.85 * root.u
                }
            }
            // A click switches to the next layout.
            PW.KeyboardLayoutSwitcher {
                id: layouts
                anchors.fill: parent
            }
        }
    }

    // Passwords are typed in a Latin layout: like macOS, switch to the first
    // one (e.g. from Arabic to English) when the screen locks. The layout
    // button at the bottom right still switches by hand.
    property bool layoutPicked: false
    function latinLayout() {
        const list = layouts.keyboardLayout.layoutsList
        if (layoutPicked || list.length === 0) // the list arrives a moment later
            return
        layoutPicked = true
        const nonLatin = ["ara", "ir", "af", "pk", "il", "ru", "ua", "by", "bg", "mk", "rs", "gr",
                          "am", "ge", "th", "kr", "jp", "cn", "in", "bd", "np", "lk", "kh", "la", "mm", "et"]
        for (let i = 0; i < list.length; ++i) {
            if (nonLatin.indexOf(list[i].shortName) < 0) {
                if (layouts.keyboardLayout.layout !== i)
                    layouts.keyboardLayout.layout = i
                return
            }
        }
    }

    Connections {
        target: layouts.keyboardLayout
        function onLayoutsListChanged() { root.latinLayout() }
    }

    Component.onCompleted: {
        latinLayout()
        authenticator.startAuthenticating()
        password.forceActiveFocus()
    }
}
