// Infinity login screen (SDDM), as designed in distro/branding/login-preview.html
// (proposal C, "Card").
//
// Kept deliberately light, plain QtQuick only, so it is on screen quickly after
// the boot screen hands over (see infinity-plymouth-handoff); there is no
// logo here, the boot screen already showed it.
//
// Layout: wallpaper with a faint ∞ and a slow band of light across it; one
// glass card in the middle (clock, date, the user, the password field);
// "Switch user" and the keyboard language floating bottom left; Sleep /
// Restart / Shut down bottom right.
import QtQuick
import QtQuick.Window
import org.kde.plasma.workspace.components as PW

Rectangle {
    id: root
    width: 1600
    height: 900
    color: "black"

    // One unit = 1.25% of the screen width (16 px on a 1280 px wide screen);
    // every size below is a multiple of it, like the preview's "em".
    readonly property real u: Math.max(10, width * 0.0125)

    readonly property color ink: "#E8ECFA"
    readonly property color inkSoft: Qt.rgba(232 / 255, 236 / 255, 250 / 255, 0.78)
    readonly property color muted: "#8A93B8"
    readonly property color royal: "#4169E1"
    readonly property color royalDeep: "#2B4FD8"
    readonly property color royalLight: "#7D97FF"
    readonly property color glass: Qt.rgba(14 / 255, 20 / 255, 44 / 255, 0.62)
    readonly property color line: Qt.rgba(125 / 255, 151 / 255, 1, 0.22)
    readonly property color errorColor: "#FF6B7A"
    readonly property string uiFont: "Noto Sans"

    // The account the password is for: the last one used, else the first.
    property string userName: userModel.lastUser
    property string userLabel: userName

    function signIn() {
        message.text = ""
        sddm.login(root.userName, password.text, sessionModel.lastIndex)
    }

    // Montserrat, the wordmark's face, for the clock and the initials. Static
    // weights: with the variable font Qt picks its thinnest instance.
    FontLoader { id: wordFont; source: "Montserrat-Light.ttf" }
    FontLoader { source: "Montserrat-Medium.ttf" }

    // Tell the boot screen this one is drawn, so it lets go of the display
    // only now (no black gap on slow computers): infinity-plymouth-handoff
    // waits for this file. A moment after the first frame, so the wallpaper
    // and the card are in it.
    property bool told: false
    Connections {
        target: root.Window.window
        enabled: !root.told
        function onFrameSwapped() { if (!root.told) drawn.start() }
    }
    Timer {
        id: drawn
        interval: 300
        onTriggered: {
            root.told = true
            var x = new XMLHttpRequest()
            x.open("PUT", "file:///tmp/infinity-greeter-drawn")
            x.send("1")
        }
    }

    Connections {
        target: sddm
        function onLoginFailed() {
            message.text = "Wrong password. Try again."
            password.text = ""
            shake.restart()
            password.forceActiveFocus()
        }
    }

    Timer {
        id: clock
        property date now: new Date()
        interval: 1000
        running: true
        repeat: true
        triggeredOnStart: true
        onTriggered: now = new Date()
    }

    Item {
        id: content
        anchors.fill: parent

        // Fade in from the black the boot screen hands over.
        NumberAnimation on opacity { from: 0; to: 1; duration: 450; easing.type: Easing.InOutQuad }

        Image {
            anchors.fill: parent
            source: "background.png"
            fillMode: Image.PreserveAspectCrop
        }

        // The faint ∞ with the band of light (InfinityMark.qml).
        InfinityMark { screen: root }

        // A click anywhere else closes the account list.
        MouseArea {
            anchors.fill: parent
            onClicked: { userList.visible = false; password.forceActiveFocus() }
        }

        // ---------- the card ----------
        Rectangle {
            id: card
            anchors.centerIn: parent
            width: 25 * root.u
            height: column.implicitHeight + 3.8 * root.u
            radius: 1.4 * root.u
            color: root.glass
            border.color: root.line
            border.width: 1

            Column {
                id: column
                y: 2.2 * root.u
                anchors.horizontalCenter: parent.horizontalCenter
                width: parent.width - 4.4 * root.u
                spacing: 0.9 * root.u

                Text {
                    anchors.horizontalCenter: parent.horizontalCenter
                    text: Qt.formatTime(clock.now, "h:mm AP")
                    color: root.ink
                    font.family: wordFont.name
                    font.weight: Font.Light
                    font.pixelSize: 3.4 * root.u
                }
                Text {
                    anchors.horizontalCenter: parent.horizontalCenter
                    text: Qt.formatDate(clock.now, "dddd, MMMM d")
                    color: root.inkSoft
                    font.family: root.uiFont
                    font.pixelSize: root.u
                }
                Row {
                    anchors.horizontalCenter: parent.horizontalCenter
                    topPadding: 0.6 * root.u
                    spacing: 0.7 * root.u
                    Avatar {
                        size: 3 * root.u
                        letter: root.userLabel
                        fontFamily: wordFont.name
                        anchors.verticalCenter: parent.verticalCenter
                    }
                    Text {
                        anchors.verticalCenter: parent.verticalCenter
                        text: root.userLabel
                        color: root.ink
                        font.family: root.uiFont
                        font.weight: Font.Medium
                        font.pixelSize: 1.35 * root.u
                    }
                }

                // Password field: on a wrong password only this field shakes.
                Item {
                    id: field
                    width: parent.width
                    height: 2.9 * root.u
                    transform: Translate { id: shakeOffset }

                    Rectangle {
                        anchors.fill: parent
                        radius: height / 2
                        color: Qt.rgba(1, 1, 1, 0.08)
                        border.color: password.activeFocus ? root.royalLight : Qt.rgba(1, 1, 1, 0.16)
                        border.width: 1
                    }
                    TextInput {
                        id: password
                        anchors.left: parent.left
                        anchors.leftMargin: 1.2 * root.u
                        anchors.right: go.left
                        anchors.rightMargin: 0.6 * root.u
                        anchors.verticalCenter: parent.verticalCenter
                        echoMode: TextInput.Password
                        passwordCharacter: "•"
                        color: root.ink
                        selectionColor: root.royal
                        font.family: root.uiFont
                        font.pixelSize: root.u
                        clip: true
                        focus: true
                        Keys.onReturnPressed: root.signIn()
                        Keys.onEnterPressed: root.signIn()
                        Keys.onEscapePressed: userList.visible = false

                        Text {
                            anchors.verticalCenter: parent.verticalCenter
                            visible: password.text.length === 0
                            text: "Password"
                            color: Qt.rgba(232 / 255, 236 / 255, 250 / 255, 0.5)
                            font: password.font
                        }
                    }
                    Rectangle {
                        id: go
                        width: 2.2 * root.u
                        height: width
                        radius: width / 2
                        anchors.right: parent.right
                        anchors.rightMargin: 0.35 * root.u
                        anchors.verticalCenter: parent.verticalCenter
                        color: goArea.containsMouse ? root.royalLight : root.royal
                        Image {
                            anchors.centerIn: parent
                            source: "icons/arrow.svg"
                            sourceSize.width: root.u
                            sourceSize.height: root.u
                        }
                        MouseArea {
                            id: goArea
                            anchors.fill: parent
                            hoverEnabled: true
                            cursorShape: Qt.PointingHandCursor
                            onClicked: root.signIn()
                        }
                    }

                    SequentialAnimation {
                        id: shake
                        NumberAnimation { target: shakeOffset; property: "x"; to: -0.6 * root.u; duration: 60 }
                        NumberAnimation { target: shakeOffset; property: "x"; to: 0.6 * root.u; duration: 80 }
                        NumberAnimation { target: shakeOffset; property: "x"; to: -0.6 * root.u; duration: 80 }
                        NumberAnimation { target: shakeOffset; property: "x"; to: 0.6 * root.u; duration: 80 }
                        NumberAnimation { target: shakeOffset; property: "x"; to: 0; duration: 60 }
                    }
                }

                Text {
                    id: message
                    width: parent.width
                    height: 1.4 * root.u
                    horizontalAlignment: Text.AlignHCenter
                    color: root.errorColor
                    font.family: root.uiFont
                    font.pixelSize: 0.9 * root.u
                }
            }
        }

        // ---------- Switch user (bottom left) ----------
        Column {
            anchors.left: parent.left
            anchors.leftMargin: root.width * 0.04
            anchors.bottom: parent.bottom
            anchors.bottomMargin: root.height * 0.05
            spacing: 0.6 * root.u

            Rectangle {
                id: userList
                visible: false
                width: 13 * root.u
                height: listColumn.implicitHeight + 1.6 * root.u
                radius: root.u
                color: root.glass
                border.color: root.line
                border.width: 1
                transform: Translate { id: listOffset }

                onVisibleChanged: if (visible) pop.restart()
                ParallelAnimation {
                    id: pop
                    NumberAnimation { target: userList; property: "opacity"; from: 0; to: 1; duration: 220; easing.type: Easing.OutQuad }
                    NumberAnimation { target: listOffset; property: "y"; from: 0.6 * root.u; to: 0; duration: 220; easing.type: Easing.OutQuad }
                }

                Column {
                    id: listColumn
                    x: 0.8 * root.u
                    y: 0.8 * root.u
                    width: parent.width - 1.6 * root.u
                    spacing: 0.2 * root.u

                    Text {
                        leftPadding: 0.4 * root.u
                        bottomPadding: 0.5 * root.u
                        text: "SWITCH USER"
                        color: root.muted
                        font.family: root.uiFont
                        font.weight: Font.Medium
                        font.pixelSize: 0.75 * root.u
                        font.letterSpacing: 0.06 * root.u
                    }
                    Repeater {
                        model: userModel
                        delegate: Rectangle {
                            id: entry
                            readonly property string label: model.realName || model.name
                            width: listColumn.width
                            height: 2.6 * root.u
                            radius: 0.7 * root.u
                            color: (rowArea.containsMouse || model.name === root.userName)
                                   ? Qt.rgba(125 / 255, 151 / 255, 1, 0.16) : "transparent"

                            // Show the real name of the preselected account.
                            Component.onCompleted: {
                                if (root.userName === "" && index === 0)
                                    root.userName = model.name
                                if (model.name === root.userName)
                                    root.userLabel = entry.label
                            }

                            Row {
                                x: 0.45 * root.u
                                anchors.verticalCenter: parent.verticalCenter
                                spacing: 0.7 * root.u
                                Avatar {
                                    size: 1.9 * root.u
                                    letter: entry.label
                                    fontFamily: wordFont.name
                                    anchors.verticalCenter: parent.verticalCenter
                                }
                                Text {
                                    anchors.verticalCenter: parent.verticalCenter
                                    text: entry.label
                                    color: root.ink
                                    font.family: root.uiFont
                                    font.pixelSize: 0.95 * root.u
                                }
                            }
                            MouseArea {
                                id: rowArea
                                anchors.fill: parent
                                hoverEnabled: true
                                cursorShape: Qt.PointingHandCursor
                                onClicked: {
                                    root.userName = model.name
                                    root.userLabel = entry.label
                                    userList.visible = false
                                    message.text = ""
                                    password.text = ""
                                    password.forceActiveFocus()
                                }
                            }
                        }
                    }
                }
            }

            Rectangle {
                width: switchRow.implicitWidth + 1.45 * root.u
                height: 2.9 * root.u
                radius: height / 2
                color: root.glass
                border.color: root.line
                border.width: 1
                visible: userModel.count > 1

                Row {
                    id: switchRow
                    x: 0.45 * root.u
                    anchors.verticalCenter: parent.verticalCenter
                    spacing: 0.6 * root.u
                    Rectangle {
                        width: 2 * root.u
                        height: width
                        radius: width / 2
                        color: Qt.rgba(1, 1, 1, 0.08)
                        Image {
                            anchors.centerIn: parent
                            source: "icons/users.svg"
                            sourceSize.width: 1.1 * root.u
                            sourceSize.height: 1.1 * root.u
                        }
                    }
                    Text {
                        anchors.verticalCenter: parent.verticalCenter
                        text: "Switch user"
                        color: root.inkSoft
                        font.family: root.uiFont
                        font.pixelSize: 0.85 * root.u
                    }
                }
                MouseArea {
                    anchors.fill: parent
                    cursorShape: Qt.PointingHandCursor
                    onClicked: userList.visible = !userList.visible
                }
            }

            // Keyboard language (only with several), as on the lock screen; a
            // click switches to the next one. SDDM's own keyboard model knows
            // nothing on Wayland; the login screen's KWin answers on its bus.
            Rectangle {
                visible: layouts.hasMultipleKeyboardLayouts
                width: layoutRow.implicitWidth + 1.4 * root.u
                height: 2.4 * root.u
                radius: height / 2
                color: root.glass
                border.color: root.line
                border.width: 1
                Row {
                    id: layoutRow
                    anchors.centerIn: parent
                    spacing: 0.5 * root.u
                    Image {
                        anchors.verticalCenter: parent.verticalCenter
                        source: "icons/keyboard.svg"
                        sourceSize.width: root.u
                        sourceSize.height: root.u
                    }
                    Text {
                        anchors.verticalCenter: parent.verticalCenter
                        text: layouts.layoutNames.shortName.toUpperCase()
                        color: root.inkSoft
                        font.family: root.uiFont
                        font.pixelSize: 0.85 * root.u
                    }
                }
                PW.KeyboardLayoutSwitcher {
                    id: layouts
                    anchors.fill: parent
                    onClicked: password.forceActiveFocus()
                }
            }
        }

        // ---------- Sleep / Restart / Shut down (bottom right) ----------
        Row {
            anchors.right: parent.right
            anchors.rightMargin: root.width * 0.04
            anchors.bottom: parent.bottom
            anchors.bottomMargin: root.height * 0.05
            spacing: root.u

            PowerButton { u: root.u; fontFamily: root.uiFont; icon: "icons/sleep.svg"; label: "Sleep"; visible: sddm.canSuspend; onActivated: sddm.suspend() }
            PowerButton { u: root.u; fontFamily: root.uiFont; icon: "icons/restart.svg"; label: "Restart"; visible: sddm.canReboot; onActivated: sddm.reboot() }
            PowerButton { u: root.u; fontFamily: root.uiFont; icon: "icons/off.svg"; label: "Shut down"; visible: sddm.canPowerOff; onActivated: sddm.powerOff() }
        }
    }

    Component.onCompleted: password.forceActiveFocus()
}
