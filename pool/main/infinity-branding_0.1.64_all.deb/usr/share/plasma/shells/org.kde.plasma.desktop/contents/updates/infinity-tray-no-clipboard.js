// Infinity: no clipboard icon in the top bar for accounts made before.
panels().forEach(function (panel) {
    // Plasma 6 keeps the tray's settings in the tray widget itself.
    panel.widgets("org.kde.plasma.systemtray").forEach(function (tray) {
        tray.currentConfigGroup = ["General"]
        var list = function (key) {
            var v = tray.readConfig(key, [])
            return typeof v === "string" ? (v ? v.split(",") : []) : Array.prototype.slice.call(v)
        }
        var extra = list("extraItems").filter(function (id) { return id !== "org.kde.plasma.clipboard" })
        var known = list("knownItems")
        if (known.indexOf("org.kde.plasma.clipboard") < 0)
            known.push("org.kde.plasma.clipboard")
        tray.writeConfig("extraItems", extra)
        tray.writeConfig("knownItems", known)
    })
})
