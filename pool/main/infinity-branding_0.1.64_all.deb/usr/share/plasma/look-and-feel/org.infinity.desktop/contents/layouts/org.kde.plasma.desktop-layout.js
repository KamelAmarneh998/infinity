// Infinity desktop layout (layout "A" in distro/branding/desktop-preview.html):
// a thin bar on top with the ∞ app menu, the active app's menus, status icons
// and the clock, and a floating dock at the bottom with the apps.
// Used for new users, and when the global theme is applied with its layout.

var top = new Panel
top.location = "top"
top.height = 24
top.floating = false

var menu = top.addWidget("org.kde.plasma.kickoff")
menu.currentConfigGroup = ["General"]
menu.writeConfig("icon", "/usr/share/icons/hicolor/scalable/apps/infinity-start.svg")
top.addWidget("org.kde.plasma.appmenu")
top.addWidget("org.kde.plasma.panelspacer")
// No clipboard icon in the top bar (it counts as known, so Plasma doesn't add it back).
var tray = top.addWidget("org.kde.plasma.systemtray")
tray.currentConfigGroup = ["General"]
tray.writeConfig("knownItems", ["org.kde.plasma.clipboard"])
var clock = top.addWidget("org.kde.plasma.digitalclock")
clock.currentConfigGroup = ["Appearance"]
clock.writeConfig("showDate", true)
clock.writeConfig("dateDisplayFormat", "BesideTime")

var dock = new Panel
dock.location = "bottom"
dock.height = 42
dock.floating = true
// Windows reach the bottom of the screen; the dock floats above them.
// (Settings > Dock offers hiding it.)
dock.hiding = "windowsgobelow"
dock.lengthMode = "fit"
dock.alignment = "center"

var tasks = dock.addWidget("org.kde.plasma.icontasks")
tasks.currentConfigGroup = ["General"]
tasks.writeConfig("launchers", [
    "applications:brave-browser.desktop",
    "applications:org.kde.dolphin.desktop",
    "applications:vlc.desktop",
    "applications:org.kde.konsole.desktop",
    "applications:systemsettings.desktop"
].join(","))

var desktops = desktopsForActivity(currentActivity())
for (var i = 0; i < desktops.length; i++) {
    desktops[i].wallpaperPlugin = "org.kde.image"
    desktops[i].currentConfigGroup = ["Wallpaper", "org.kde.image", "General"]
    desktops[i].writeConfig("Image", "file:///usr/share/wallpapers/Infinity/")
}
