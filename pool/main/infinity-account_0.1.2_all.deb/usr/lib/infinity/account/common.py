# Infinity Account: shared parts of accountd (the root service) and pam-auth.
#
# An Infinity Account is the user's own e-mail with a password, kept by Firebase
# Authentication (project infinityos-desktop, free plan). A computer account
# linked to it uses the same password: signing in checks the computer's copy first
# (works offline), then the Infinity Account (a password changed elsewhere, or
# after "Forgot password?" by e-mail), and keeps the computer's copy up to date.
# A recovery key (any account) signs in once when the password is forgotten.
#
# State, root only: /var/lib/infinity/account/
#   users/<user>.json     {"email", "firebase"}       the link
#   keys/<user>.json      {"salt", "hash", "made"}    the recovery key (PBKDF2)
#   tries/<user>          failed recovery-key tries (time per line)
#   reset/<user>          signed in with the key: must choose a new password
import ctypes, ctypes.util, hashlib, hmac, json, os, secrets, subprocess, time, urllib.error, urllib.request

STATE = "/var/lib/infinity/account"
KEY = "AIzaSyBV5w8N2YHEkJTg3p8jDyJKQnKKBIEfqJo"
API = "https://identitytoolkit.googleapis.com/v1/accounts:"
if os.geteuid() == 0:
    for d in ("users", "keys", "tries", "reset"):
        os.makedirs(os.path.join(STATE, d), mode=0o700, exist_ok=True)


class Problem(Exception):
    """Something to tell the person (plain English)."""


def _path(kind, user, ext=".json"):
    if not user or "/" in user or user.startswith("."):
        raise Problem("Unknown account.")
    return os.path.join(STATE, kind, user + ext)


def read(kind, user):
    try:
        with open(_path(kind, user)) as f:
            return json.load(f)
    except FileNotFoundError:
        return None


def write(kind, user, data):
    path = _path(kind, user)
    tmp = path + ".new"
    with open(os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600), "w") as f:
        json.dump(data, f)
    os.replace(tmp, path)


def remove(kind, user, ext=".json"):
    try:
        os.remove(_path(kind, user, ext))
    except FileNotFoundError:
        pass


# ---------- Firebase (REST) ----------

MESSAGES = {
    "EMAIL_EXISTS": "There is already an Infinity Account with this e-mail. Sign in instead.",
    "INVALID_LOGIN_CREDENTIALS": "The e-mail or the password is not right.",
    "INVALID_PASSWORD": "The e-mail or the password is not right.",
    "EMAIL_NOT_FOUND": "The e-mail or the password is not right.",
    "INVALID_EMAIL": "That doesn't look like an e-mail address.",
    "USER_DISABLED": "This Infinity Account has been turned off.",
    "TOO_MANY_ATTEMPTS_TRY_LATER": "Too many tries. Wait a few minutes and try again.",
    "WEAK_PASSWORD": "Choose a longer password (at least 6 characters).",
    "PASSWORD_DOES_NOT_MEET_REQUIREMENTS": "Choose a stronger password.",
    "CREDENTIAL_TOO_OLD_LOGIN_AGAIN": "Sign in again, then change the password.",
}


def firebase(method, body, timeout=8):
    req = urllib.request.Request(API + method + "?key=" + KEY, data=json.dumps(body).encode(),
                                 headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.load(r)
    except urllib.error.HTTPError as e:
        try:
            code = json.load(e)["error"]["message"]
        except Exception:
            code = str(e.code)
        code = code.split(" ")[0].split(":")[0]
        raise Problem(MESSAGES.get(code, "The Infinity Account service said no (" + code + ")."))
    except (urllib.error.URLError, TimeoutError, OSError):
        raise Problem("No internet connection. Connect and try again.")


def sign_in(email, password, timeout=8):
    return firebase("signInWithPassword", {"email": email, "password": password, "returnSecureToken": True}, timeout)


def sign_up(email, password):
    r = firebase("signUp", {"email": email, "password": password, "returnSecureToken": True})
    send_verify(r["idToken"])
    return r


def send_verify(id_token):
    firebase("sendOobCode", {"requestType": "VERIFY_EMAIL", "idToken": id_token})


def verified(id_token):
    users = firebase("lookup", {"idToken": id_token}).get("users", [{}])
    return bool(users[0].get("emailVerified"))


# ---------- the computer's own password ----------

def set_local_password(user, password):
    if "\n" in password or ":" in user:
        raise Problem("That password can't be used.")
    r = subprocess.run(["chpasswd"], input=f"{user}:{password}\n", text=True, capture_output=True)
    if r.returncode != 0:
        raise Problem("The computer's password couldn't be changed.")


# Checks a password with PAM's own "login" rules (pam_unix), as root.
class _Msg(ctypes.Structure):
    _fields_ = [("style", ctypes.c_int), ("msg", ctypes.c_char_p)]


class _Resp(ctypes.Structure):
    _fields_ = [("resp", ctypes.c_void_p), ("retcode", ctypes.c_int)]  # PAM frees resp: malloc'd


_CONV = ctypes.CFUNCTYPE(ctypes.c_int, ctypes.c_int, ctypes.POINTER(ctypes.POINTER(_Msg)),
                         ctypes.POINTER(ctypes.POINTER(_Resp)), ctypes.c_void_p)


class _Conv(ctypes.Structure):
    _fields_ = [("conv", _CONV), ("data", ctypes.c_void_p)]


def local_password_ok(user, password):
    """Only pam_unix (the computer's own copy): never the Infinity Account."""
    pam = ctypes.CDLL(ctypes.util.find_library("pam"))
    libc = ctypes.CDLL(ctypes.util.find_library("c"))
    libc.calloc.restype = ctypes.c_void_p
    libc.calloc.argtypes = [ctypes.c_size_t, ctypes.c_size_t]
    libc.strdup.restype = ctypes.c_void_p
    libc.strdup.argtypes = [ctypes.c_char_p]

    @_CONV
    def conv(n, msgs, resp, data):
        arr = ctypes.cast(libc.calloc(n, ctypes.sizeof(_Resp)), ctypes.POINTER(_Resp))
        for i in range(n):
            if msgs[i].contents.style in (1, 2):  # PAM_PROMPT_ECHO_OFF / ON: the password
                arr[i].resp = libc.strdup(password.encode())
        resp[0] = arr
        return 0

    handle = ctypes.c_void_p()
    # "infinity-account-check" = pam_unix only (/etc/pam.d), so the check never
    # loops back into the Infinity Account.
    if pam.pam_start(b"infinity-account-check", user.encode(), ctypes.byref(_Conv(conv, None)), ctypes.byref(handle)) != 0:
        return False
    ok = pam.pam_authenticate(handle, 0) == 0
    pam.pam_end(handle, 0)
    return ok


# ---------- recovery keys ----------

ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"  # no 0/O, 1/I


def make_key(user):
    raw = "".join(secrets.choice(ALPHABET) for _ in range(24))
    key = "-".join(raw[i:i + 4] for i in range(0, 24, 4))
    salt = secrets.token_hex(16)
    write("keys", user, {"salt": salt, "hash": _hash(key, salt), "made": int(time.time())})
    return key


def _hash(key, salt):
    clean = key.upper().replace("-", "").replace(" ", "")
    return hashlib.pbkdf2_hmac("sha256", clean.encode(), bytes.fromhex(salt), 300000).hex()


def looks_like_key(text):
    clean = text.upper().replace("-", "").replace(" ", "")
    return len(clean) == 24 and all(c in ALPHABET for c in clean)


def key_ok(user, key):
    """True once: a used key is gone. Five wrong tries wait 15 minutes."""
    k = read("keys", user)
    if not k:
        return False
    tries_file = _path("tries", user, "")
    now = time.time()
    try:
        tries = [float(t) for t in open(tries_file).read().split() if now - float(t) < 900]
    except FileNotFoundError:
        tries = []
    if len(tries) >= 5:
        return False
    if hmac.compare_digest(_hash(key, k["salt"]), k["hash"]):
        remove("keys", user)
        remove("tries", user, "")
        return True
    tries.append(now)
    with open(os.open(tries_file, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600), "w") as f:
        f.write("\n".join(str(t) for t in tries))
    return False
