// Three fingers left or right on the touchpad: the next or previous app, like
// moving between full-screen apps on a Mac. Apps keep the order they were
// opened in, so a swipe always goes the same way along the row. Turned on and
// off in Settings > Mouse & Touchpad > Touchpad (kwinrc [Plugins]).
import QtQuick
import org.kde.kwin

Item {
    id: root

    // Windows in the order they were opened.
    property var order: []

    function wanted(w) {
        return w && w.normalWindow && !w.skipTaskbar && !w.deleted;
    }

    function add(w) {
        if (wanted(w) && order.indexOf(w) < 0)
            order.push(w);
    }

    function step(by) {
        const here = order.filter(w => wanted(w) && (w.onAllDesktops || w.desktops.indexOf(Workspace.currentDesktop) >= 0));
        if (here.length < 2)
            return;
        let i = here.indexOf(Workspace.activeWindow);
        i = i < 0 ? 0 : (i + by + here.length) % here.length;
        const w = here[i];
        if (w.minimized)
            w.minimized = false;
        Workspace.activeWindow = w;
    }

    Component.onCompleted: {
        const windows = Workspace.windows;
        for (let i = 0; i < windows.length; i++)
            add(windows[i]);
    }

    Connections {
        target: Workspace
        function onWindowAdded(w) { root.add(w); }
        function onWindowRemoved(w) {
            const i = root.order.indexOf(w);
            if (i >= 0)
                root.order.splice(i, 1);
        }
    }

    // Fingers moving left bring in the app on the right, as on a Mac.
    SwipeGestureHandler {
        direction: SwipeGestureHandler.Direction.Left
        fingerCount: 3
        deviceType: SwipeGestureHandler.Device.Touchpad
        onActivated: root.step(1)
    }
    SwipeGestureHandler {
        direction: SwipeGestureHandler.Direction.Right
        fingerCount: 3
        deviceType: SwipeGestureHandler.Device.Touchpad
        onActivated: root.step(-1)
    }
}
