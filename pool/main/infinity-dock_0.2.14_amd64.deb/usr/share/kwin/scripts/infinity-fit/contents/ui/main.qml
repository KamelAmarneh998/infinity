// A new window never opens bigger than its screen: VS Code's "open this website?"
// box with a long address was wider than the screen and its buttons were off the
// edge. Windows that can be resized are shrunk to the screen's free area; the
// others are moved so their right side (where the buttons are) shows. Only when a
// window first shows: moving or resizing it later is left to the user.
import QtQuick
import org.kde.kwin

Item {
    id: root

    function fit(w) {
        // never the lock screen (KWin can report it as a normal window: Start+L put it
        // under the top bar, a black strip above), nor anything covering the whole screen
        if (!w || w.deleted || w.lockScreen || !(w.normalWindow || w.dialog) || w.fullScreen || w.specialWindow)
            return;
        const screen = w.output ? w.output.geometry : null;
        if (screen && w.frameGeometry.width >= screen.width && w.frameGeometry.height >= screen.height)
            return;
        const area = Workspace.clientArea(KWin.MaximizeArea, w.output, Workspace.currentDesktop);
        const g = w.frameGeometry;
        if (g.width <= area.width && g.height <= area.height
            && g.x >= area.x && g.y >= area.y
            && g.x + g.width <= area.x + area.width && g.y + g.height <= area.y + area.height)
            return;
        let width = g.width, height = g.height;
        if (w.resizeable) {
            width = Math.min(width, area.width);
            height = Math.min(height, area.height);
        }
        // inside the area; a window still too wide keeps its right side in view, too tall its top
        let x = Math.min(Math.max(g.x, area.x), area.x + area.width - width);
        let y = Math.max(Math.min(g.y, area.y + area.height - height), area.y);
        w.frameGeometry = Qt.rect(Math.round(x), Math.round(y), Math.round(width), Math.round(height));
    }

    Connections {
        target: Workspace
        function onWindowAdded(w) {
            root.fit(w);
            // apps often settle their size right after they show
            Qt.callLater(() => root.fit(w));
        }
    }
}
