// The popup that shows when the volume, the brightness or the keyboard language
// changes (Plasma's on-screen display): KWin puts it low in the middle of the
// screen; here it goes to the top right of the screen in use, just under the
// top bar, where those icons are (like on a Mac).
import QtQuick
import org.kde.kwin

Item {
    id: root

    readonly property real gap: 10

    function place(w) {
        if (!w || w.deleted || !w.onScreenDisplay)
            return;
        // the screen's free area leaves out the top bar and the dock
        const area = Workspace.clientArea(KWin.MaximizeArea, Workspace.activeScreen, Workspace.currentDesktop);
        const g = w.frameGeometry;
        const x = Math.round(area.x + area.width - g.width - gap);
        const y = Math.round(area.y + gap);
        if (g.x !== x || g.y !== y)
            w.frameGeometry = Qt.rect(x, y, g.width, g.height);
    }

    function watch(w) {
        if (!w || !w.onScreenDisplay)
            return;
        place(w);
        // KWin may place it again right after it shows, and its size changes with its text
        Qt.callLater(() => place(w));
        w.frameGeometryChanged.connect(() => place(w));
    }

    Connections {
        target: Workspace
        function onWindowAdded(w) { root.watch(w); }
    }

    Component.onCompleted: Workspace.windows.forEach(w => root.watch(w))
}
