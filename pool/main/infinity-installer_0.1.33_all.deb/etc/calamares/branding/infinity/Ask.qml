// Talking to the installer's helper (/usr/lib/infinity/installer/helper, root):
// a request file in, an answer file out (QML can only read and write files here).
//   ask({do: "disks"}, function (answer) { ... })   answer.ok false: answer.error
// note(file, data) writes one of the small files other steps read (the navigation's
// "block", the summary, installer/account).
import QtQuick

QtObject {
    id: helper
    readonly property string dir: "file:///tmp/infinity-installer/"
    property var waiting: ({})
    property int pending: 0

    function ask(request, done, seconds) {
        const id = Date.now() + "-" + Math.floor(Math.random() * 1000000)
        const x = new XMLHttpRequest()
        x.open("PUT", dir + "req-" + id + ".json")
        x.send(JSON.stringify(request))
        waiting[id] = { done: done, until: Date.now() + 1000 * (seconds || 120) }
        pending++
        poll.start()
    }
    function note(file, data) {
        const x = new XMLHttpRequest()
        x.open("PUT", dir + file)
        x.send(JSON.stringify(data))
    }
    function finish(id, answer) {
        const w = waiting[id]
        if (!w) return
        delete waiting[id]
        pending--
        if (pending <= 0) poll.stop()
        if (w.done) w.done(answer)
    }
    function check() {
        for (const id in waiting) {
            if (Date.now() > waiting[id].until) {
                finish(id, { ok: false, error: qsTr("The installer didn't answer. Try again.") })
                continue
            }
            const x = new XMLHttpRequest()
            x.onreadystatechange = function () {
                if (x.readyState !== XMLHttpRequest.DONE || x.responseText === "") return
                let a = null
                try { a = JSON.parse(x.responseText) } catch (e) { return }   // still being written
                finish(id, a)
            }
            x.open("GET", dir + "ans-" + id + ".json")
            x.send()
        }
    }
    property Timer poll: Timer { interval: 250; repeat: true; onTriggered: helper.check() }
}
