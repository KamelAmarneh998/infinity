// A rounded box with a title, for the summary screen.
import QtQuick

Rectangle {
    id: card
    property alias title: heading.text
    default property alias content: body.data
    implicitHeight: body.y + body.implicitHeight + 18
    radius: 14
    color: Qt.rgba(1, 1, 1, 0.03)
    border.color: Qt.rgba(125 / 255, 151 / 255, 1, 0.12)

    Text {
        id: heading
        x: 18; y: 14
        color: "#E8ECFA"
        font.pixelSize: 15
        font.weight: Font.Medium
    }
    Column {
        id: body
        x: 18
        y: heading.y + heading.height + 10
        width: card.width - 36
        spacing: 6
    }
}
