// Bottom of the installer window: Back, a line about what's missing, and Next.
// Hidden on the first screen (it has its own buttons), while installing and on the
// last screen. A screen can hold Next back with a reason (Disk: nothing picked;
// Account: no PIN yet): it writes block.json ({step, reason}) through Ask.qml,
// read here, since each screen is a QML scene of its own.
import io.calamares.ui 1.0
import io.calamares.core 1.0
import QtQuick
import QtQuick.Layouts

Rectangle {
    id: nav
    height: 72
    color: "#101630"

    readonly property bool first: ViewManager.currentStepIndex === 0
    readonly property bool last: ViewManager.currentStepIndex === ViewManager.rowCount() - 1
    readonly property bool shown: ViewManager.backAndNextVisible && !first && !last
    // The step before the install (the summary) says what Next will do.
    readonly property bool installNext: ViewManager.currentStepIndex === ViewManager.rowCount() - 3
    readonly property var steps: ["welcome", "keyboard", "location", "disk", "network", "account", "ready", "installing", "done"]
    property string reason: ""

    Timer {
        interval: 300
        repeat: true
        running: nav.shown
        triggeredOnStart: true
        onTriggered: {
            const x = new XMLHttpRequest()
            x.onreadystatechange = function () {
                if (x.readyState !== XMLHttpRequest.DONE) return
                let b = {}
                try { b = JSON.parse(x.responseText) } catch (e) { }
                nav.reason = b && b.step === nav.steps[ViewManager.currentStepIndex] ? (b.reason || "") : ""
            }
            x.open("GET", "file:///tmp/infinity-installer/block.json")
            x.send()
        }
    }

    RowLayout {
        anchors.fill: parent
        anchors.leftMargin: 36
        anchors.rightMargin: 36
        anchors.bottomMargin: 18
        spacing: 14
        visible: nav.shown

        Pill {
            text: qsTr("Back")
            enabled: ViewManager.backEnabled
            onClicked: ViewManager.back()
        }
        Text {
            Layout.fillWidth: true
            text: nav.reason !== "" ? nav.reason : nav.installNext ? qsTr("The disk changes after this.") : ""
            color: "#8A93B8"
            font.pixelSize: 13
            elide: Text.ElideRight
        }
        Pill {
            primary: true
            text: nav.installNext ? qsTr("Install now") : qsTr("Next")
            enabled: ViewManager.nextEnabled && nav.reason === ""
            onClicked: ViewManager.next()
        }
    }
}
