// Network (notesqml@network): the internet for the Account step (signing in with
// Google or Zoho) and for updates. A cable connects by itself; Wi-Fi networks are
// listed (the helper asks NetworkManager), a locked one asks its password in place.
// Without internet the Account step only offers a local account.
import io.calamares.core 1.0
import io.calamares.ui 1.0
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

Item {
    id: page
    Rectangle { anchors.fill: parent; color: "#101630" }
    Ask { id: helper }

    property var net: ({ networks: [] })
    property bool loaded: false
    property string picked: ""          // a locked network waiting for its password
    property bool connecting: false
    property string error: ""

    function onActivate() { refresh(true); timer.start() }
    function onLeave() { timer.stop() }
    onVisibleChanged: if (visible) onActivate(); else onLeave()
    Component.onCompleted: refresh(true)

    function refresh(rescan) {
        helper.ask({ do: "net", rescan: !!rescan }, function (a) {
            if (!a.ok) return
            loaded = true
            net = a
        }, 40)
    }
    Timer { id: timer; interval: 5000; repeat: true; onTriggered: if (!page.connecting) page.refresh(false) }

    function connectTo(ssid, password) {
        connecting = true
        error = ""
        helper.ask({ do: "connect", ssid: ssid, password: password || "" }, function (a) {
            connecting = false
            if (!a.ok) { error = a.error; return }
            picked = ""
            refresh(false)
        }, 90)
    }

    ColumnLayout {
        anchors.fill: parent
        anchors.leftMargin: 40
        anchors.rightMargin: 40
        anchors.topMargin: 24
        anchors.bottomMargin: 8
        spacing: 12

        Heading { text: qsTr("Connect to the internet") }
        Text {
            Layout.fillWidth: true
            text: qsTr("With internet you can sign in with your account on the next step, and updates come in while it installs.")
            color: "#8A93B8"; font.pixelSize: 14; wrapMode: Text.Wrap
        }

        // where things stand
        Rectangle {
            Layout.fillWidth: true
            implicitHeight: 58
            radius: 12
            color: page.net.online ? Qt.rgba(94 / 255, 214 / 255, 160 / 255, 0.08) : Qt.rgba(1, 1, 1, 0.03)
            border.color: page.net.online ? Qt.rgba(94 / 255, 214 / 255, 160 / 255, 0.45) : Qt.rgba(125 / 255, 151 / 255, 1, 0.14)
            Column {
                anchors.verticalCenter: parent.verticalCenter
                x: 16
                spacing: 2
                Text {
                    color: "#E8ECFA"; font.pixelSize: 15; font.weight: Font.Medium
                    text: !page.loaded ? qsTr("Looking…")
                        : page.net.cable && page.net.online ? qsTr("Connected by cable")
                        : page.net.active && page.net.online ? qsTr("Connected to %1").arg(page.net.active)
                        : page.net.active ? qsTr("Connected to %1, but no internet yet").arg(page.net.active)
                        : qsTr("Not connected")
                }
                Text {
                    color: "#8A93B8"; font.pixelSize: 12
                    text: page.net.online ? qsTr("You can sign in with your account on the next step.")
                        : page.net.wifi ? qsTr("Choose a network below, or plug in a cable.")
                        : qsTr("Plug in a cable, or continue without internet.")
                }
            }
        }

        // Wi-Fi networks
        Rectangle {
            visible: !!page.net.wifi && !page.net.cable
            Layout.fillWidth: true
            Layout.fillHeight: true
            radius: 12
            color: "transparent"
            border.color: Qt.rgba(125 / 255, 151 / 255, 1, 0.14)
            clip: true
            Flickable {
                anchors.fill: parent
                anchors.margins: 1
                contentHeight: list.implicitHeight
                boundsBehavior: Flickable.StopAtBounds
                ScrollBar.vertical: ThinScrollBar { }
                Column {
                    id: list
                    width: parent.width
                    Repeater {
                        model: page.net.networks || []
                        delegate: Column {
                            id: netRow
                            required property var modelData
                            width: list.width
                            Rectangle {
                                width: parent.width; height: 50
                                color: netRow.modelData.active ? Qt.rgba(65 / 255, 105 / 255, 225 / 255, 0.16)
                                     : area.containsMouse ? Qt.rgba(1, 1, 1, 0.04) : "transparent"
                                RowLayout {
                                    anchors.fill: parent
                                    anchors.leftMargin: 16
                                    anchors.rightMargin: 16
                                    spacing: 12
                                    // signal: three bars
                                    Row {
                                        spacing: 2
                                        Repeater {
                                            model: 3
                                            Rectangle {
                                                required property int index
                                                anchors.bottom: parent ? parent.bottom : undefined
                                                width: 4; height: 6 + 4 * index; radius: 1
                                                color: netRow.modelData.signal > 25 + 25 * index ? "#E8ECFA" : Qt.rgba(1, 1, 1, 0.2)
                                            }
                                        }
                                    }
                                    Column {
                                        Layout.fillWidth: true
                                        Text { text: netRow.modelData.ssid; color: "#E8ECFA"; font.pixelSize: 14; elide: Text.ElideRight; width: parent.width }
                                        Text {
                                            text: netRow.modelData.active ? qsTr("Connected") : netRow.modelData.secure ? qsTr("Locked") : qsTr("Open")
                                            color: netRow.modelData.active ? "#5ED6A0" : "#8A93B8"; font.pixelSize: 12
                                        }
                                    }
                                }
                                MouseArea {
                                    id: area
                                    anchors.fill: parent
                                    hoverEnabled: true
                                    enabled: !page.connecting && !netRow.modelData.active
                                    onClicked: {
                                        page.error = ""
                                        if (netRow.modelData.secure) page.picked = netRow.modelData.ssid
                                        else page.connectTo(netRow.modelData.ssid, "")
                                    }
                                }
                                Rectangle { anchors.bottom: parent.bottom; width: parent.width; height: 1; color: Qt.rgba(125 / 255, 151 / 255, 1, 0.1) }
                            }
                            // the password, right under the network
                            Rectangle {
                                visible: page.picked === netRow.modelData.ssid
                                onVisibleChanged: if (visible) pwField.input.forceActiveFocus()
                                width: parent.width; height: visible ? 76 : 0
                                color: Qt.rgba(65 / 255, 105 / 255, 225 / 255, 0.08)
                                RowLayout {
                                    anchors.fill: parent
                                    anchors.leftMargin: 16
                                    anchors.rightMargin: 16
                                    spacing: 10
                                    Field {
                                        id: pwField
                                        Layout.fillWidth: true
                                        label: qsTr("Wi-Fi password for %1").arg(netRow.modelData.ssid)
                                        echoMode: TextInput.Password
                                    }
                                    Connections {
                                        target: pwField.input
                                        function onAccepted() { page.connectTo(netRow.modelData.ssid, pwField.text) }
                                    }
                                    Pill {
                                        primary: true
                                        text: page.connecting ? qsTr("Connecting…") : qsTr("Connect")
                                        enabled: !page.connecting
                                        onClicked: page.connectTo(netRow.modelData.ssid, pwField.text)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        Item { visible: !page.net.wifi || page.net.cable; Layout.fillHeight: true }

        Text {
            visible: page.error !== "" || page.connecting
            Layout.fillWidth: true
            text: page.connecting ? qsTr("Connecting…") : page.error
            color: page.connecting ? "#8A93B8" : "#FF6B7A"
            font.pixelSize: 13
            wrapMode: Text.Wrap
        }
        Text {
            visible: !page.net.online
            text: "<u>" + qsTr("No internet here: continue without it") + "</u>"
            textFormat: Text.StyledText
            color: "#8A93B8"; font.pixelSize: 13
            MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: ViewManager.next() }
        }
    }
}
