// A labelled text field with a hint line under it.
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

ColumnLayout {
    id: field
    property alias label: caption.text
    property alias text: input.text
    property alias placeholder: input.placeholderText
    property alias echoMode: input.echoMode
    property alias input: input
    property string hint: ""
    property int hintKind: 0 // 0 plain, 1 good, -1 bad
    signal edited(string text)
    spacing: 6

    Text { id: caption; color: "#8A93B8"; font.pixelSize: 13 }
    TextField {
        id: input
        Layout.fillWidth: true
        onTextEdited: field.edited(text)
        color: "#E8ECFA"
        placeholderTextColor: Qt.rgba(232 / 255, 236 / 255, 250 / 255, 0.4)
        selectionColor: "#4169E1"
        font.pixelSize: 15
        leftPadding: 14; rightPadding: 14; topPadding: 11; bottomPadding: 11
        background: Rectangle {
            radius: 11
            color: Qt.rgba(1, 1, 1, 0.06)
            border.width: input.activeFocus ? 2 : 1
            border.color: input.activeFocus ? "#7D97FF" : Qt.rgba(1, 1, 1, 0.14)
        }
    }
    Text {
        Layout.fillWidth: true
        visible: text !== ""
        text: field.hint
        wrapMode: Text.Wrap
        font.pixelSize: 12
        color: field.hintKind > 0 ? "#5ED6A0" : field.hintKind < 0 ? "#FF6B7A" : "#8A93B8"
    }
}
