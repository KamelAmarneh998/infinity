// Disk (notesqml@disk): where Infinity goes, the way Windows Setup asks it. Every
// disk with its partitions and free space; New, Delete and Format happen when they
// are confirmed (the helper does them); picking free space or a partition of at
// least 20 GB makes the plan (helper "plan": checked, saved for installer/disk-apply,
// and Calamares' partition data for its mount/fstab/bootloader steps: gs.json, read
// by the infinitydisk install step). No resizing,
// no "next to Windows": a partition is only ever used whole.
import io.calamares.core 1.0
import io.calamares.ui 1.0
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

Item {
    id: page
    Rectangle { anchors.fill: parent; color: "#101630" }
    Ask { id: helper }

    property var disks: []
    property bool loading: true
    property string error: ""
    property var sel: null          // {disk, item}
    property string ask: ""         // new | delete | format: the confirm row
    property bool working: false
    property string planText: ""
    property bool planOk: false

    function onActivate() { refresh() }
    onVisibleChanged: if (visible) refresh()
    Component.onCompleted: refresh()

    function gb(b) {
        return b < 1e9 ? Math.round(b / 1e6) + " MB" : (Math.round(b / 1e8) / 10) + " GB"
    }
    function refresh() {
        loading = true
        helper.ask({ do: "disks" }, function (a) {
            loading = false
            if (!a.ok) { error = a.error; return }
            error = ""
            disks = a.disks
            // keep the choice when it is still there
            if (sel) {
                const d = disks.find(x => x.path === sel.disk)
                const it = d && d.items.find(i => sel.item.kind === "part" ? i.number === sel.item.number : i.kind === "free" && i.start <= sel.item.start + 1048576 && i.start + i.size >= sel.item.start)
                sel = it ? { disk: d.path, item: it } : null
            }
            if (!sel) {
                // the first free space big enough, as a start
                for (const d of disks) {
                    if (d.installer) continue
                    const f = d.items.find(i => i.kind === "free" && i.size >= 20e9)
                    if (f) { sel = { disk: d.path, item: f }; break }
                }
            }
            plan()
        })
    }
    function block(reason) { helper.note("block.json", { step: "disk", reason: reason }) }
    function plan() {
        planOk = false
        if (!sel) { planText = qsTr("Pick where Infinity goes."); block(qsTr("Pick free space or a partition of at least 20 GB.")); return }
        const it = sel.item
        if (it.kind === "part" && it.role !== "data") { planText = qsTr("This one is part of the computer's own startup: pick another one."); block(planText); return }
        if (it.size < 20e9) { planText = qsTr("Too small: Infinity needs at least 20 GB."); block(qsTr("Pick free space or a partition of at least 20 GB.")); return }
        planText = qsTr("Checking…")
        block(planText)
        const target = it.kind === "part" ? { disk: sel.disk, number: it.number } : { disk: sel.disk, start: it.start, size: it.size }
        helper.ask({ do: "plan", target: target }, function (a) {
            if (!a.ok) { planText = a.error; block(a.error); return }
            planOk = true
            planText = it.kind === "free" ? qsTr("✓ Infinity goes into the unallocated space (%1).").arg(gb(it.size))
                     : it.used > 1e8 ? qsTr("✓ Infinity goes into “%1” (%2). Its %3 of files are deleted.").arg(it.name).arg(gb(it.size)).arg(gb(it.used))
                     : qsTr("✓ Infinity goes into “%1” (%2).").arg(it.name).arg(gb(it.size))
            helper.note("disk-summary.json", { text: it.kind === "free" ? qsTr("A new partition in the unallocated space · %1").arg(gb(it.size))
                                                                         : qsTr("“%1” · %2 (formatted)").arg(it.name).arg(gb(it.size)),
                                               disk: sel.disk })
            block("")
        })
    }
    function choose(d, it) { sel = { disk: d.path, item: it }; ask = ""; plan() }
    function act(what, extra) {
        working = true
        const it = sel.item
        const req = what === "delete" ? { do: "delete", disk: sel.disk, number: it.number }
                  : what === "format" ? { do: "format", path: it.path }
                  : { do: "new", disk: sel.disk, start: it.start, size: extra }
        helper.ask(req, function (a) {
            working = false
            ask = ""
            if (!a.ok) { error = a.error; return }
            error = ""
            if (what === "new") sel = { disk: sel.disk, item: { kind: "part", number: a.number, start: it.start } }
            refresh()
        }, 900)
    }

    readonly property var colors: ({ efi: "#59607E", system: "#59607E", data: "#3B6FD6", free: Qt.rgba(1, 1, 1, 0.15) })

    ColumnLayout {
        anchors.fill: parent
        anchors.leftMargin: 40
        anchors.rightMargin: 40
        anchors.topMargin: 24
        anchors.bottomMargin: 8
        spacing: 12

        Heading { text: qsTr("Where should Infinity go?") }
        Text {
            Layout.fillWidth: true
            text: qsTr("Pick free space, or a partition to put it in. You can delete, make or format partitions here first.")
            color: "#8A93B8"; font.pixelSize: 14; wrapMode: Text.Wrap
        }

        // ---------- the list ----------
        Rectangle {
            Layout.fillWidth: true
            Layout.fillHeight: true
            radius: 12
            color: Qt.rgba(1, 1, 1, 0.02)
            border.color: Qt.rgba(125 / 255, 151 / 255, 1, 0.14)
            clip: true

            Text {
                anchors.centerIn: parent
                visible: page.loading && page.disks.length === 0
                text: qsTr("Looking at the disks…")
                color: "#8A93B8"; font.pixelSize: 14
            }

            ColumnLayout {
                anchors.fill: parent
                spacing: 0
                // headings
                RowLayout {
                    Layout.fillWidth: true
                    Layout.margins: 10
                    Layout.leftMargin: 16
                    spacing: 12
                    Text { Layout.fillWidth: true; Layout.preferredWidth: 5; text: qsTr("Name"); color: "#8A93B8"; font.pixelSize: 12 }
                    Text { Layout.preferredWidth: 90; text: qsTr("Total size"); color: "#8A93B8"; font.pixelSize: 12 }
                    Text { Layout.preferredWidth: 90; text: qsTr("Free"); color: "#8A93B8"; font.pixelSize: 12 }
                    Text { Layout.preferredWidth: 120; text: qsTr("Type"); color: "#8A93B8"; font.pixelSize: 12 }
                }
                Rectangle { Layout.fillWidth: true; height: 1; color: Qt.rgba(125 / 255, 151 / 255, 1, 0.14) }

                Flickable {
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    contentHeight: rows.implicitHeight
                    clip: true
                    boundsBehavior: Flickable.StopAtBounds
                    ScrollBar.vertical: ThinScrollBar { }
                    Column {
                        id: rows
                        width: parent.width
                        Repeater {
                            model: page.disks
                            delegate: Column {
                                id: diskCol
                                required property var modelData
                                required property int index
                                width: rows.width
                                Rectangle {
                                    width: parent.width; height: 32
                                    color: Qt.rgba(1, 1, 1, 0.03)
                                    Text {
                                        x: 16; anchors.verticalCenter: parent.verticalCenter
                                        width: parent.width - 32; elide: Text.ElideRight
                                        textFormat: Text.StyledText
                                        text: "<b>" + qsTr("Disk %1").arg(diskCol.index) + "</b>  ·  "
                                              + (diskCol.modelData.usb ? qsTr("USB drive") : diskCol.modelData.hdd ? qsTr("Hard disk") : qsTr("SSD"))
                                              + " · " + page.gb(diskCol.modelData.size)
                                              + (diskCol.modelData.model ? " · " + diskCol.modelData.model : "")
                                              + (diskCol.modelData.installer ? " · " + qsTr("the installer is on it") : "")
                                        color: "#8A93B8"; font.pixelSize: 12
                                    }
                                }
                                Repeater {
                                    model: diskCol.modelData.installer ? [] : diskCol.modelData.items
                                    delegate: Rectangle {
                                        id: row
                                        required property var modelData
                                        readonly property bool chosen: page.sel && page.sel.disk === diskCol.modelData.path
                                            && (modelData.kind === "part" ? page.sel.item.kind === "part" && page.sel.item.number === modelData.number
                                                                          : page.sel.item.kind === "free" && page.sel.item.start === modelData.start)
                                        width: rows.width; height: 40
                                        color: chosen ? Qt.rgba(65 / 255, 105 / 255, 225 / 255, 0.2) : area.containsMouse ? Qt.rgba(1, 1, 1, 0.04) : "transparent"
                                        Rectangle { visible: row.chosen; width: 3; height: parent.height; color: "#4169E1" }
                                        Rectangle { anchors.bottom: parent.bottom; width: parent.width; height: 1; color: Qt.rgba(125 / 255, 151 / 255, 1, 0.1) }
                                        RowLayout {
                                            anchors.fill: parent
                                            anchors.leftMargin: 16
                                            anchors.rightMargin: 10
                                            spacing: 12
                                            RowLayout {
                                                Layout.fillWidth: true
                                                Layout.preferredWidth: 5
                                                spacing: 10
                                                Rectangle { width: 10; height: 10; radius: 2; color: page.colors[row.modelData.kind === "free" ? "free" : row.modelData.role] }
                                                Text {
                                                    Layout.fillWidth: true
                                                    elide: Text.ElideRight
                                                    text: row.modelData.kind === "free" ? qsTr("Unallocated space")
                                                        : qsTr("Partition %1: %2").arg(row.modelData.number).arg(row.modelData.name)
                                                    font.italic: row.modelData.kind === "free"
                                                    color: row.modelData.kind === "free" ? "#8A93B8" : "#E8ECFA"
                                                    font.pixelSize: 14
                                                }
                                            }
                                            Text { Layout.preferredWidth: 90; text: page.gb(row.modelData.size); color: "#E8ECFA"; font.pixelSize: 14 }
                                            Text { Layout.preferredWidth: 90; text: page.gb(row.modelData.size - (row.modelData.used || 0)); color: "#E8ECFA"; font.pixelSize: 14 }
                                            Text {
                                                Layout.preferredWidth: 120
                                                text: row.modelData.kind === "free" ? "" : row.modelData.role === "efi" ? qsTr("System (FAT32)")
                                                    : row.modelData.fstype === "ext4" ? "ext4" : (row.modelData.fstype || "").toUpperCase()
                                                color: "#8A93B8"; font.pixelSize: 12
                                            }
                                        }
                                        MouseArea { id: area; anchors.fill: parent; hoverEnabled: true; enabled: !page.working; onClicked: page.choose(diskCol.modelData, row.modelData) }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // ---------- New / Delete / Format ----------
        RowLayout {
            spacing: 8
            enabled: !page.working
            SmallButton { text: qsTr("New"); enabled: !!page.sel && page.sel.item.kind === "free"; opacity: enabled ? 1 : 0.4; onClicked: page.ask = "new" }
            SmallButton { text: qsTr("Delete"); enabled: !!page.sel && page.sel.item.kind === "part" && page.sel.item.role !== "efi"; opacity: enabled ? 1 : 0.4; onClicked: page.ask = "delete" }
            SmallButton { text: qsTr("Format"); enabled: !!page.sel && page.sel.item.kind === "part" && page.sel.item.role === "data"; opacity: enabled ? 1 : 0.4; onClicked: page.ask = "format" }
            SmallButton { text: qsTr("Refresh"); onClicked: page.refresh() }
            Text { visible: page.working; text: qsTr("Working…"); color: "#8A93B8"; font.pixelSize: 13 }
        }

        // the confirm row
        Rectangle {
            visible: page.ask !== "" && !!page.sel
            Layout.fillWidth: true
            implicitHeight: confirmRow.implicitHeight + 20
            radius: 10
            color: page.ask === "new" ? Qt.rgba(65 / 255, 105 / 255, 225 / 255, 0.1) : Qt.rgba(1, 107 / 255, 122 / 255, 0.1)
            border.color: page.ask === "new" ? Qt.rgba(125 / 255, 151 / 255, 1, 0.3) : Qt.rgba(1, 107 / 255, 122 / 255, 0.35)
            RowLayout {
                id: confirmRow
                anchors.fill: parent
                anchors.margins: 10
                anchors.leftMargin: 14
                spacing: 10
                Text {
                    visible: page.ask !== "new"
                    Layout.fillWidth: true
                    wrapMode: Text.Wrap
                    color: "#E8ECFA"; font.pixelSize: 14
                    text: !page.sel ? "" : page.ask === "delete"
                        ? qsTr("Delete “%1” (%2)?").arg(page.sel.item.name).arg(page.gb(page.sel.item.size))
                          + (page.sel.item.used > 1e8 ? " " + qsTr("Its %1 of files will be gone.").arg(page.gb(page.sel.item.used)) : "")
                        : qsTr("Format “%1”? Everything on it (%2) will be gone.").arg(page.sel.item.name).arg(page.gb(page.sel.item.used || 0))
                }
                Field {
                    id: newSize
                    visible: page.ask === "new"
                    Layout.fillWidth: true
                    label: qsTr("Size of the new partition (GB)")
                    input.validator: RegularExpressionValidator { regularExpression: /[0-9]{0,5}([.][0-9]?)?/ }
                }
                SmallButton { text: qsTr("Cancel"); onClicked: page.ask = "" }
                Pill {
                    primary: true
                    text: page.ask === "new" ? qsTr("Make it") : page.ask === "delete" ? qsTr("Delete") : qsTr("Format")
                    onClicked: {
                        if (page.ask === "new") {
                            const whole = page.sel.item.size
                            let size = Math.min(whole, (parseFloat(newSize.text) || 0) * 1e9)
                            // a leftover under 1 GB is no use to anything: the new partition takes it
                            if (whole - size < 1e9) size = whole
                            page.act("new", size)
                        } else page.act(page.ask)
                    }
                }
            }
        }
        Connections {
            target: page
            function onAskChanged() { if (page.ask === "new" && page.sel) newSize.text = String(Math.round(page.sel.item.size / 1e8) / 10) }
        }

        Text {
            Layout.fillWidth: true
            text: page.error !== "" ? page.error : page.planText
            color: page.error !== "" ? "#FF6B7A" : page.planOk ? "#5ED6A0" : "#FFB547"
            font.pixelSize: 14
            wrapMode: Text.Wrap
        }
    }
}
