// A screen title (Montserrat, like the rest of Infinity's own screens).
import QtQuick

Text {
    FontLoader { id: word; source: "file:///usr/share/sddm/themes/infinity/Montserrat-Medium.ttf" }
    color: "#E8ECFA"
    font.family: word.name
    font.pixelSize: 28
    wrapMode: Text.Wrap
}
