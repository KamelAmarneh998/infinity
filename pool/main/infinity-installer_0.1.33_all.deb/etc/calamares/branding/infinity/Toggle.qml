// An on/off switch in Infinity's colors.
import QtQuick

Rectangle {
    id: sw
    property bool on: false
    signal toggled()

    width: 46
    height: 26
    radius: height / 2
    color: on ? "#4169E1" : Qt.rgba(1, 1, 1, 0.14)
    Behavior on color { ColorAnimation { duration: 150 } }
    activeFocusOnTab: true
    Keys.onSpacePressed: toggled()

    Rectangle {
        width: 20; height: 20; radius: 10
        y: 3
        x: sw.on ? sw.width - width - 3 : 3
        color: "white"
        Behavior on x { NumberAnimation { duration: 150 } }
    }
    Rectangle {
        visible: sw.activeFocus
        anchors.fill: parent; anchors.margins: -4
        radius: height / 2; color: "transparent"
        border.color: "#7D97FF"; border.width: 2
    }
    MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: sw.toggled() }
}
