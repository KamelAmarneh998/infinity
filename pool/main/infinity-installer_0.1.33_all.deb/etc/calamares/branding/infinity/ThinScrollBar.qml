// A thin scroll bar without a track (the default style draws a line).
import QtQuick
import QtQuick.Controls

ScrollBar {
    padding: 0
    implicitWidth: 6
    contentItem: Rectangle {
        implicitWidth: 6
        radius: 3
        color: Qt.rgba(1, 1, 1, 0.2)
    }
    background: Item { }
}
