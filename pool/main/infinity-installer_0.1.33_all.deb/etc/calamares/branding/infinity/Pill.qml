// A rounded button in Infinity's colors: filled (primary) or outlined.
import QtQuick

Rectangle {
    id: pill
    property alias text: label.text
    property bool primary: false
    property bool big: false
    signal clicked()

    implicitWidth: label.implicitWidth + (big ? 56 : 44)
    implicitHeight: big ? 50 : 42
    radius: height / 2
    opacity: enabled ? 1 : 0.4
    color: primary ? (area.containsMouse ? "#2B4FD8" : "#4169E1")
                   : (area.containsMouse ? Qt.rgba(1, 1, 1, 0.06) : "transparent")
    border.width: primary ? 0 : 1
    border.color: Qt.rgba(125 / 255, 151 / 255, 1, 0.3)
    activeFocusOnTab: true
    Keys.onReturnPressed: if (enabled) clicked()
    Keys.onSpacePressed: if (enabled) clicked()

    Text {
        id: label
        anchors.centerIn: parent
        color: pill.primary ? "white" : "#E8ECFA"
        font.pixelSize: pill.big ? 17 : 15
        font.weight: Font.Medium
    }
    Rectangle { // keyboard focus ring
        visible: pill.activeFocus
        anchors.fill: parent
        anchors.margins: -4
        radius: height / 2
        color: "transparent"
        border.color: "#7D97FF"
        border.width: 2
    }
    MouseArea {
        id: area
        anchors.fill: parent
        hoverEnabled: true
        cursorShape: Qt.PointingHandCursor
        onClicked: if (pill.enabled) pill.clicked()
    }
}
