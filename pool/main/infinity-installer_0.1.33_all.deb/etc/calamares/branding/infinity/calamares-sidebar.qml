// Layout A: the steps down the left side of the installer window, the one you are
// on highlighted, the ones done ticked (Welcome and Done aren't listed).
import io.calamares.ui 1.0
import io.calamares.core 1.0
import QtQuick

Rectangle {
    id: bar
    width: 230
    color: "#0B1024"

    // Our names for the steps, in settings.conf's order.
    readonly property var names: ["Welcome", "Keyboard", "Location", "Disk", "Network", "Account", "Ready", "Installing", "Done"]
    readonly property int cur: ViewManager.currentStepIndex
    FontLoader { id: medium; source: "file:///usr/share/sddm/themes/infinity/Montserrat-Medium.ttf" }

    Rectangle { anchors.right: parent.right; width: 1; height: parent.height; color: Qt.rgba(125 / 255, 151 / 255, 1, 0.12) }

    Row {
        x: 24; y: 26
        spacing: 10
        Image { source: "mark.svg"; sourceSize.width: 40; sourceSize.height: 20; anchors.verticalCenter: parent.verticalCenter }
        Text { text: "Infinity"; color: "#E8ECFA"; font.family: medium.name; font.pixelSize: 18; anchors.verticalCenter: parent.verticalCenter }
    }

    Column {
        x: 16; y: 80
        width: parent.width - 32
        spacing: 4
        Repeater {
            model: bar.names.length - 2
            Rectangle {
                readonly property int step: index + 1
                readonly property bool done: step < bar.cur
                readonly property bool current: step === bar.cur
                width: parent.width
                height: 38
                radius: 9
                color: current ? Qt.rgba(65 / 255, 105 / 255, 225 / 255, 0.18) : "transparent"
                Row {
                    anchors.verticalCenter: parent.verticalCenter
                    x: 10
                    spacing: 12
                    Rectangle {
                        width: 22; height: 22; radius: 11
                        anchors.verticalCenter: parent.verticalCenter
                        color: current ? "#4169E1" : done ? Qt.rgba(94 / 255, 214 / 255, 160 / 255, 0.16) : "transparent"
                        border.width: current || done ? 0 : 1
                        border.color: Qt.rgba(125 / 255, 151 / 255, 1, 0.3)
                        Text {
                            anchors.centerIn: parent
                            text: done ? "✓" : step
                            color: current ? "white" : done ? "#5ED6A0" : "#8A93B8"
                            font.pixelSize: 11
                        }
                    }
                    Text {
                        anchors.verticalCenter: parent.verticalCenter
                        text: qsTr(bar.names[step])
                        color: current || done ? "#E8ECFA" : "#8A93B8"
                        font.pixelSize: 14
                    }
                }
            }
        }
    }

    Text {
        x: 24
        anchors.bottom: parent.bottom
        anchors.bottomMargin: 22
        text: "Version 0.1"
        color: "#8A93B8"
        font.pixelSize: 12
    }
}
