// First screen: "Try" or "Install", the checks, and the language.
import io.calamares.core 1.0
import io.calamares.ui 1.0
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

Item {
    id: page
    Rectangle { anchors.fill: parent; color: "#101630" }
    FontLoader { id: light; source: "file:///usr/share/sddm/themes/infinity/Montserrat-Light.ttf" }
    FontLoader { id: medium; source: "file:///usr/share/sddm/themes/infinity/Montserrat-Medium.ttf" }

    // "Try" quits the installer without the "cancel?" question: the
    // launcher (infinity-installer) sees this file and closes it.
    function tryIt() {
        var x = new XMLHttpRequest()
        x.open("PUT", "file:///tmp/infinity-installer-try")
        x.send("try")
    }

    function checkText(name, ok) {
        switch (name) {
        case "storage": return ok ? qsTr("Enough space") : qsTr("Not enough space: 20 GB needed")
        case "ram": return ok ? qsTr("Enough memory") : qsTr("Not enough memory: 2 GB needed")
        case "power": return ok ? qsTr("Plugged in") : qsTr("On battery: plug in to be safe")
        case "internet": return ok ? qsTr("Connected to the internet") : qsTr("No internet: that's fine")
        default: return ""
        }
    }

    ColumnLayout {
        anchors.centerIn: parent
        width: Math.min(parent.width - 80, 760)
        spacing: 22

        Image {
            Layout.alignment: Qt.AlignHCenter
            source: "mark.svg"
            sourceSize.width: 200
            sourceSize.height: 100
        }
        Text {
            Layout.alignment: Qt.AlignHCenter
            text: qsTr("Welcome to %1").arg(Branding.string(Branding.ProductName))
            color: "#E8ECFA"
            font.family: light.name
            font.pixelSize: 40
        }
        Text {
            Layout.alignment: Qt.AlignHCenter
            Layout.topMargin: -10
            text: qsTr("Try it straight from this USB stick, or put it on this computer for good.")
            color: "#8A93B8"
            font.pixelSize: 16
        }

        RowLayout {
            Layout.alignment: Qt.AlignHCenter
            Layout.topMargin: 6
            spacing: 16

            Repeater {
                model: [
                    { title: qsTr("Try %1").arg(Branding.string(Branding.ProductName)),
                      note: qsTr("Look around first. Nothing on this computer changes."), install: false },
                    { title: qsTr("Install %1").arg(Branding.string(Branding.ProductName)),
                      note: qsTr("About 15 minutes. You choose where it goes."), install: true }
                ]
                delegate: Rectangle {
                    id: choice
                    readonly property bool install: modelData.install
                    readonly property bool ok: !install || config.requirementsModel.satisfiedMandatory
                    width: 260
                    height: 104
                    radius: 16
                    opacity: ok ? 1 : 0.45
                    border.width: activeFocus ? 2 : 1
                    border.color: activeFocus ? "#7D97FF" : install ? "#4169E1" : (hover.containsMouse ? "#7D97FF" : Qt.rgba(125 / 255, 151 / 255, 1, 0.22))
                    gradient: Gradient {
                        orientation: Gradient.Horizontal
                        GradientStop { position: 0; color: choice.install ? Qt.rgba(65 / 255, 105 / 255, 225 / 255, 0.55) : Qt.rgba(1, 1, 1, 0.03) }
                        GradientStop { position: 1; color: choice.install ? Qt.rgba(43 / 255, 79 / 255, 216 / 255, 0.3) : Qt.rgba(1, 1, 1, 0.03) }
                    }
                    activeFocusOnTab: true
                    // Enter installs straight away; Tab moves to Try.
                    Component.onCompleted: if (install) forceActiveFocus()
                    Keys.onReturnPressed: go()
                    Keys.onSpacePressed: go()
                    function go() {
                        if (!ok) return
                        if (install) ViewManager.next(); else page.tryIt()
                    }

                    Column {
                        x: 20; y: 18
                        width: parent.width - 40
                        spacing: 6
                        Text {
                            text: modelData.title
                            color: "#E8ECFA"
                            font.family: medium.name
                            font.pixelSize: 18
                        }
                        Text {
                            width: parent.width
                            text: modelData.note
                            color: "#A9B1D1"
                            font.pixelSize: 13
                            wrapMode: Text.Wrap
                        }
                    }
                    MouseArea {
                        id: hover
                        anchors.fill: parent
                        hoverEnabled: true
                        cursorShape: choice.ok ? Qt.PointingHandCursor : Qt.ArrowCursor
                        onClicked: choice.go()
                    }
                }
            }
        }

        // The checks (Calamares' requirements), in plain words.
        Flow {
            Layout.alignment: Qt.AlignHCenter
            Layout.maximumWidth: page.width - 80
            spacing: 22
            Repeater {
                model: config.requirementsModel
                delegate: Row {
                    visible: checkText(name, satisfied) !== ""
                    spacing: 6
                    readonly property color tone: satisfied ? "#5ED6A0" : mandatory ? "#FF6B7A" : "#FFB547"
                    Text { text: satisfied ? "✓" : "!"; color: parent.tone; font.pixelSize: 14; font.bold: true }
                    Text { text: checkText(name, satisfied); color: parent.tone; font.pixelSize: 13 }
                }
            }
        }

        RowLayout {
            Layout.alignment: Qt.AlignHCenter
            spacing: 10
            Text { text: qsTr("Language"); color: "#8A93B8"; font.pixelSize: 14 }
            ComboBox {
                id: languages
                implicitWidth: 240
                model: config.languagesModel
                textRole: "label"
                currentIndex: config.localeIndex
                onCurrentIndexChanged: config.localeIndex = currentIndex
                contentItem: Text {
                    leftPadding: 16
                    text: languages.displayText
                    color: "#E8ECFA"
                    font.pixelSize: 14
                    verticalAlignment: Text.AlignVCenter
                }
                background: Rectangle {
                    implicitHeight: 38
                    radius: 19
                    color: Qt.rgba(1, 1, 1, 0.06)
                    border.width: languages.activeFocus ? 2 : 1
                    border.color: languages.activeFocus ? "#7D97FF" : Qt.rgba(125 / 255, 151 / 255, 1, 0.3)
                }
            }
        }
    }
}
