// A rounded list to pick one item from, with a search box above it.
// model: a Calamares list model with "label" (and a currentIndex property).
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

ColumnLayout {
    id: pick
    property alias title: caption.text
    property var model
    property bool searchable: true
    spacing: 8

    Text {
        id: caption
        color: "#8A93B8"
        font.pixelSize: 12
        font.weight: Font.Medium
        font.letterSpacing: 1.2
        font.capitalization: Font.AllUppercase
    }
    TextField {
        id: search
        visible: pick.searchable
        Layout.fillWidth: true
        placeholderText: qsTr("Search")
        color: "#E8ECFA"
        placeholderTextColor: Qt.rgba(232 / 255, 236 / 255, 250 / 255, 0.4)
        font.pixelSize: 14
        leftPadding: 14; topPadding: 9; bottomPadding: 9
        background: Rectangle {
            radius: 10
            color: Qt.rgba(1, 1, 1, 0.05)
            border.width: search.activeFocus ? 2 : 1
            border.color: search.activeFocus ? "#7D97FF" : Qt.rgba(1, 1, 1, 0.12)
        }
    }
    Rectangle {
        Layout.fillWidth: true
        Layout.fillHeight: true
        radius: 14
        color: Qt.rgba(1, 1, 1, 0.02)
        border.color: Qt.rgba(125 / 255, 151 / 255, 1, 0.12)
        clip: true

        ListView {
            id: list
            anchors.fill: parent
            anchors.margins: 1
            model: pick.model
            currentIndex: pick.model ? pick.model.currentIndex : -1
            boundsBehavior: Flickable.StopAtBounds
            ScrollBar.vertical: ThinScrollBar { }
            Component.onCompleted: positionViewAtIndex(currentIndex, ListView.Center)
            onCountChanged: positionViewAtIndex(currentIndex, ListView.Center)
            delegate: Rectangle {
                readonly property bool match: search.text === "" || label.toLowerCase().indexOf(search.text.toLowerCase()) >= 0
                readonly property bool current: index === list.currentIndex
                width: list.width
                height: match ? 42 : 0
                visible: match
                color: current ? Qt.rgba(65 / 255, 105 / 255, 225 / 255, 0.25) : row.containsMouse ? Qt.rgba(1, 1, 1, 0.04) : "transparent"
                Text {
                    x: 16
                    width: parent.width - 52
                    anchors.verticalCenter: parent.verticalCenter
                    text: label
                    elide: Text.ElideRight
                    color: "#E8ECFA"
                    font.pixelSize: 14
                }
                Text {
                    visible: parent.current
                    anchors.right: parent.right
                    anchors.rightMargin: 16
                    anchors.verticalCenter: parent.verticalCenter
                    text: "✓"
                    color: "#7D97FF"
                    font.pixelSize: 15
                }
                Rectangle {
                    anchors.bottom: parent.bottom
                    width: parent.width; height: 1
                    color: Qt.rgba(125 / 255, 151 / 255, 1, 0.08)
                }
                MouseArea {
                    id: row
                    anchors.fill: parent
                    hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                    onClicked: pick.model.currentIndex = index
                }
            }
        }
    }
}
