// Keyboards: any number of them, the first is the main one (used when the
// computer starts). Calamares itself only knows one layout: it gets the main
// one; the whole list (e.g. "us,ara") goes to /tmp/infinity-keyboards and
// the "keyboards" install step writes it into the new system.
import io.calamares.core 1.0
import io.calamares.ui 1.0
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

Item {
    id: page
    Rectangle { anchors.fill: parent; color: "#101630" }

    property var chosen: [] // [{ key, label }], the first is the main one
    property bool ready: false

    // Every layout Calamares knows: [{ key, label, index }].
    Instantiator {
        id: all
        model: config.keyboardLayoutsModel
        delegate: QtObject {
            property string k: key
            property string l: label
        }
        onObjectAdded: page.start()
    }
    // Start with the layout Calamares guessed from the language (as soon as
    // both the list and the guess are there).
    function start() {
        if (chosen.length > 0) return
        var i = config.keyboardLayoutsModel.currentIndex
        if (i >= 0 && i < all.count && all.objectAt(i))
            setChosen([{ key: all.objectAt(i).k, label: all.objectAt(i).l }])
    }
    Connections {
        target: config.keyboardLayoutsModel
        function onCurrentIndexChanged() { page.start() }
    }
    Component.onCompleted: start()
    function indexOfKey(k) {
        for (var i = 0; i < all.count; i++)
            if (all.objectAt(i) && all.objectAt(i).k === k) return i
        return -1
    }
    function setChosen(list) {
        chosen = list
        if (list.length === 0) return
        var i = indexOfKey(list[0].key)
        if (i >= 0 && config.keyboardLayoutsModel.currentIndex !== i)
            config.keyboardLayoutsModel.currentIndex = i
        var x = new XMLHttpRequest()
        x.open("PUT", "file:///tmp/infinity-keyboards")
        x.send(list.map(function (k) { return k.key }).join(","))
    }
    function add(k, l) {
        for (var i = 0; i < chosen.length; i++) if (chosen[i].key === k) return
        setChosen(chosen.concat([{ key: k, label: l }]))
    }
    function remove(i) {
        var c = chosen.slice(); c.splice(i, 1); setChosen(c)
    }
    function makeMain(i) {
        var c = chosen.slice(); var x = c.splice(i, 1)[0]; c.unshift(x); setChosen(c)
    }

    ColumnLayout {
        anchors.fill: parent
        anchors.leftMargin: 48
        anchors.rightMargin: 48
        anchors.topMargin: 20
        anchors.bottomMargin: 8
        spacing: 14

        Heading { text: qsTr("Your keyboards") }
        Text {
            Layout.fillWidth: true
            Layout.topMargin: -6
            text: qsTr("Add as many as you like. The first one is used when the computer starts; switch between them with Meta + Space.")
            color: "#8A93B8"
            font.pixelSize: 15
            wrapMode: Text.Wrap
        }

        RowLayout {
            Layout.fillWidth: true
            Layout.fillHeight: true
            spacing: 20

            // ---------- the chosen keyboards ----------
            ColumnLayout {
                Layout.fillWidth: true
                Layout.fillHeight: true
                Layout.preferredWidth: 1
                spacing: 8
                Text {
                    text: qsTr("Chosen")
                    color: "#8A93B8"; font.pixelSize: 12; font.weight: Font.Medium
                    font.letterSpacing: 1.2; font.capitalization: Font.AllUppercase
                }
                Rectangle {
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    radius: 14
                    color: Qt.rgba(1, 1, 1, 0.02)
                    border.color: Qt.rgba(125 / 255, 151 / 255, 1, 0.12)
                    clip: true
                    Column {
                        anchors.fill: parent
                        anchors.margins: 1
                        Repeater {
                            model: page.chosen
                            delegate: Rectangle {
                                width: parent.width
                                height: 50
                                color: index === 0 ? Qt.rgba(65 / 255, 105 / 255, 225 / 255, 0.2) : "transparent"
                                RowLayout {
                                    anchors.fill: parent
                                    anchors.leftMargin: 16
                                    anchors.rightMargin: 10
                                    spacing: 8
                                    Text {
                                        Layout.fillWidth: true
                                        text: modelData.label
                                        elide: Text.ElideRight
                                        color: "#E8ECFA"
                                        font.pixelSize: 14
                                    }
                                    Rectangle {
                                        visible: index === 0
                                        width: mainText.implicitWidth + 16; height: 22; radius: 11
                                        color: "#4169E1"
                                        Text { id: mainText; anchors.centerIn: parent; text: qsTr("Main"); color: "white"; font.pixelSize: 11; font.weight: Font.Medium }
                                    }
                                    SmallButton {
                                        visible: index > 0
                                        text: qsTr("Make main")
                                        onClicked: page.makeMain(index)
                                    }
                                    SmallButton {
                                        visible: page.chosen.length > 1
                                        text: "✕"
                                        onClicked: page.remove(index)
                                    }
                                }
                                Rectangle {
                                    anchors.bottom: parent.bottom
                                    width: parent.width; height: 1
                                    color: Qt.rgba(125 / 255, 151 / 255, 1, 0.08)
                                }
                            }
                        }
                    }
                }
            }

            // ---------- every keyboard, to add from ----------
            ColumnLayout {
                Layout.fillWidth: true
                Layout.fillHeight: true
                Layout.preferredWidth: 1
                spacing: 8
                Text {
                    text: qsTr("Add a keyboard")
                    color: "#8A93B8"; font.pixelSize: 12; font.weight: Font.Medium
                    font.letterSpacing: 1.2; font.capitalization: Font.AllUppercase
                }
                TextField {
                    id: search
                    Layout.fillWidth: true
                    placeholderText: qsTr("Search, for example Arabic")
                    color: "#E8ECFA"
                    placeholderTextColor: Qt.rgba(232 / 255, 236 / 255, 250 / 255, 0.4)
                    font.pixelSize: 14
                    leftPadding: 14; topPadding: 9; bottomPadding: 9
                    background: Rectangle {
                        radius: 10
                        color: Qt.rgba(1, 1, 1, 0.05)
                        border.width: search.activeFocus ? 2 : 1
                        border.color: search.activeFocus ? "#7D97FF" : Qt.rgba(1, 1, 1, 0.12)
                    }
                }
                Rectangle {
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    radius: 14
                    color: Qt.rgba(1, 1, 1, 0.02)
                    border.color: Qt.rgba(125 / 255, 151 / 255, 1, 0.12)
                    clip: true
                    ListView {
                        id: list
                        anchors.fill: parent
                        anchors.margins: 1
                        model: config.keyboardLayoutsModel
                        boundsBehavior: Flickable.StopAtBounds
                        ScrollBar.vertical: ThinScrollBar { }
                        delegate: Rectangle {
                            readonly property bool match: search.text === "" || label.toLowerCase().indexOf(search.text.toLowerCase()) >= 0
                            readonly property bool picked: page.chosen.some(function (x) { return x.key === key })
                            width: list.width
                            height: match ? 42 : 0
                            visible: match
                            color: row.containsMouse ? Qt.rgba(1, 1, 1, 0.04) : "transparent"
                            Text {
                                x: 16
                                width: parent.width - 60
                                anchors.verticalCenter: parent.verticalCenter
                                text: label
                                elide: Text.ElideRight
                                color: parent.picked ? "#8A93B8" : "#E8ECFA"
                                font.pixelSize: 14
                            }
                            Text {
                                anchors.right: parent.right
                                anchors.rightMargin: 18
                                anchors.verticalCenter: parent.verticalCenter
                                text: parent.picked ? "✓" : "+"
                                color: "#7D97FF"
                                font.pixelSize: 17
                            }
                            Rectangle {
                                anchors.bottom: parent.bottom
                                width: parent.width; height: 1
                                color: Qt.rgba(125 / 255, 151 / 255, 1, 0.08)
                            }
                            MouseArea {
                                id: row
                                anchors.fill: parent
                                hoverEnabled: true
                                cursorShape: Qt.PointingHandCursor
                                onClicked: page.add(key, label)
                            }
                        }
                    }
                }
            }
        }

        Field {
            Layout.fillWidth: true
            label: qsTr("Try it")
            placeholder: qsTr("Type here to test your keyboard")
        }
    }
}
