// A small text button inside list rows.
import QtQuick

Rectangle {
    id: b
    property alias text: t.text
    signal clicked()
    implicitWidth: t.implicitWidth + 18
    implicitHeight: 26
    radius: 13
    color: area.containsMouse ? Qt.rgba(1, 1, 1, 0.08) : "transparent"
    border.color: Qt.rgba(125 / 255, 151 / 255, 1, 0.3)
    Text { id: t; anchors.centerIn: parent; color: "#E8ECFA"; font.pixelSize: 12 }
    MouseArea { id: area; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: b.clicked() }
}
