// Location: a dotted world map (click your part of the world) and a city
// search. Sets the time zone; the language comes from the first screen.
import io.calamares.core 1.0
import io.calamares.ui 1.0
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

Item {
    id: page
    Rectangle { anchors.fill: parent; color: "#101630" }

    // world.svg spans 180W..180E and 84N..60S (see make-worldmap.py).
    readonly property real north: 84
    readonly property real south: -60
    property var coords: ({}) // "Asia/Amman" -> [lat, lon], from zone.tab
    readonly property string currentKey: config.currentLocation ? config.currentLocation.region + "/" + config.currentLocation.zone : ""
    readonly property var here: coords[currentKey]

    // Dates, times and numbers follow the system language, not the country
    // (the user asked for "12:03 AM" in Jordan, not Arabic digits).
    function sameFormats() {
        if (config.currentLanguageCode !== "" && config.currentLCCode !== config.currentLanguageCode)
            config.currentLCCode = config.currentLanguageCode
    }
    Connections {
        target: config
        function onCurrentLocationChanged() { page.sameFormats() }
        function onCurrentLCCodeChanged() { page.sameFormats() }
        function onCurrentLanguageCodeChanged() { page.sameFormats() }
    }

    function parseCoord(s) { // "+3157+03556" or "+313424+0355602"
        var m = s.match(/^([+-])(\d{2})(\d{2})(\d{2})?([+-])(\d{3})(\d{2})(\d{2})?$/)
        if (!m) return null
        var lat = (+m[2] + m[3] / 60 + (m[4] ? m[4] / 3600 : 0)) * (m[1] === "-" ? -1 : 1)
        var lon = (+m[6] + m[7] / 60 + (m[8] ? m[8] / 3600 : 0)) * (m[5] === "-" ? -1 : 1)
        return [lat, lon]
    }
    Component.onCompleted: {
        sameFormats()
        var x = new XMLHttpRequest()
        x.onreadystatechange = function () {
            if (x.readyState !== XMLHttpRequest.DONE) return
            var map = {}
            x.responseText.split("\n").forEach(function (line) {
                if (line === "" || line[0] === "#") return
                var f = line.split("\t")
                var c = parseCoord(f[1])
                if (c) map[f[2]] = c
            })
            coords = map
        }
        x.open("GET", "file:///usr/share/zoneinfo/zone.tab")
        x.send()
    }

    ColumnLayout {
        anchors.fill: parent
        anchors.leftMargin: 48
        anchors.rightMargin: 48
        anchors.topMargin: 20
        anchors.bottomMargin: 8
        spacing: 14

        Heading { text: qsTr("Where are you?") }
        Text {
            Layout.topMargin: -6
            text: qsTr("Sets the clock, and the date and number formats.")
            color: "#8A93B8"
            font.pixelSize: 15
        }

        // ---------- the map ----------
        Rectangle {
            id: mapBox
            Layout.fillWidth: true
            Layout.fillHeight: true
            radius: 16
            color: Qt.rgba(1, 1, 1, 0.02)
            border.color: Qt.rgba(125 / 255, 151 / 255, 1, 0.12)
            clip: true

            Image {
                id: world
                anchors.centerIn: parent
                width: Math.min(parent.width - 24, (parent.height - 24) * 2.5)
                height: width / 2.5
                source: "world.svg"
                sourceSize.width: width
                sourceSize.height: height

                MouseArea {
                    anchors.fill: parent
                    cursorShape: Qt.PointingHandCursor
                    onClicked: function (mouse) {
                        var lon = mouse.x / world.width * 360 - 180
                        var lat = page.north - mouse.y / world.height * (page.north - page.south)
                        var tz = config.zonesModel.lookup(lat, lon)
                        if (tz) config.setCurrentLocation(tz.region, tz.zone)
                    }
                }

                // the pin
                Item {
                    visible: page.here !== undefined
                    x: page.here ? (page.here[1] + 180) / 360 * world.width : 0
                    y: page.here ? (page.north - page.here[0]) / (page.north - page.south) * world.height : 0
                    Behavior on x { NumberAnimation { duration: 300; easing.type: Easing.OutCubic } }
                    Behavior on y { NumberAnimation { duration: 300; easing.type: Easing.OutCubic } }
                    Rectangle {
                        width: 30; height: 30; radius: 15
                        anchors.centerIn: parent
                        color: Qt.rgba(65 / 255, 105 / 255, 225 / 255, 0.35)
                    }
                    Rectangle {
                        width: 12; height: 12; radius: 6
                        anchors.centerIn: parent
                        color: "white"
                    }
                    Rectangle {
                        anchors.horizontalCenter: parent.horizontalCenter
                        anchors.bottom: parent.top
                        anchors.bottomMargin: 18
                        width: pinText.implicitWidth + 24
                        height: 28
                        radius: 14
                        color: "#4169E1"
                        Text {
                            id: pinText
                            anchors.centerIn: parent
                            text: config.currentLocation ? config.currentLocation.name.replace(/.*\//, "") : ""
                            color: "white"
                            font.pixelSize: 13
                            font.weight: Font.Medium
                        }
                    }
                }
            }
        }

        // ---------- the city search ----------
        RowLayout {
            Layout.fillWidth: true
            spacing: 20
            Field {
                id: city
                Layout.fillWidth: true
                label: qsTr("City or time zone")
                placeholder: qsTr("Search, for example Amman")
            }
            Column {
                Layout.alignment: Qt.AlignBottom
                Layout.bottomMargin: 6
                spacing: 2
                Text {
                    text: config.currentTimezoneName
                    color: "#E8ECFA"
                    font.pixelSize: 20
                }
                Text {
                    text: page.currentKey
                    color: "#5ED6A0"
                    font.pixelSize: 13
                }
            }
        }
    }

    // Search results float over the map.
    Rectangle {
        visible: city.input.activeFocus && city.text.length > 1 && results.count > 0
        x: city.mapToItem(page, 0, 0).x
        width: city.width
        height: Math.min(results.contentHeight + 2, 260)
        y: city.mapToItem(page, 0, 0).y - height - 6
        radius: 12
        color: "#18203C"
        border.color: Qt.rgba(125 / 255, 151 / 255, 1, 0.3)
        clip: true
        ListView {
            id: results
            anchors.fill: parent
            anchors.margins: 1
            boundsBehavior: Flickable.StopAtBounds
            // Every zone in zone.tab whose city or region matches.
            model: {
                var q = city.text.toLowerCase().replace(/ /g, "_")
                if (q.length < 2) return []
                return Object.keys(page.coords).filter(function (k) {
                    return k.toLowerCase().indexOf(q) >= 0
                }).sort().slice(0, 40)
            }
            delegate: Rectangle {
                width: results.width
                height: 38
                color: hit.containsMouse ? Qt.rgba(65 / 255, 105 / 255, 225 / 255, 0.25) : "transparent"
                Text {
                    x: 14
                    anchors.verticalCenter: parent.verticalCenter
                    text: modelData.replace(/.*\//, "").replace(/_/g, " ") + "  ·  " + modelData.replace(/\/.*/, "")
                    color: "#E8ECFA"
                    font.pixelSize: 14
                }
                MouseArea {
                    id: hit
                    anchors.fill: parent
                    hoverEnabled: true
                    onClicked: {
                        var i = modelData.indexOf("/")
                        config.setCurrentLocation(modelData.slice(0, i), modelData.slice(i + 1))
                        city.text = ""
                        page.forceActiveFocus()
                    }
                }
            }
        }
    }
}
