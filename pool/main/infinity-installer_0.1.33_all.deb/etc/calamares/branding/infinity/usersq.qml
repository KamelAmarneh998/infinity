// Account (Calamares' usersq: it makes the computer account from `config`).
// Online: Google or Zoho (signed in right here, in a small window of the account's
// own page: the helper's "signin"), then a PIN as in Settings > Accounts; or Later,
// which turns this step into a local account. Offline: only the local account.
// The PIN is the account's password (digits only). installer/account later puts the
// link and the PIN's length into the new system (account.json, who.json).
import io.calamares.core 1.0
import io.calamares.ui 1.0
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtQuick.Shapes

Item {
    id: page
    Rectangle { anchors.fill: parent; color: "#101630" }
    Ask { id: helper }
    FontLoader { id: medium; source: "file:///usr/share/sddm/themes/infinity/Montserrat-Medium.ttf" }

    property string online: "checking"     // checking | yes | no
    property string mode: ""                // "" (choose) | signing | linked | local
    property string provider: ""
    property var who: ({})
    property string signError: ""

    function onActivate() { checkNet() }
    onVisibleChanged: if (visible) checkNet()
    Component.onCompleted: checkNet()
    function checkNet() {
        helper.ask({ do: "net" }, function (a) {
            online = a.ok && a.online ? "yes" : "no"
            if (online === "no" && mode !== "linked") mode = "local"
            if (online === "yes" && mode === "local" && !chosenLater) mode = ""
            update()
        }, 40)
    }
    property bool chosenLater: false

    function pname(p) { return p === "google" ? "Google" : p === "zoho" ? "Zoho" : "" }
    function signIn(p) {
        provider = p
        mode = "signing"
        signError = ""
        update()
        helper.ask({ do: "signin", provider: p }, function (a) {
            if (mode !== "signing") return
            if (!a.ok) { mode = ""; signError = a.error; update(); return }
            who = a
            mode = "linked"
            config.setFullName(a.name || a.email.split("@")[0])
            update()
            pinA.input.forceActiveFocus()
        }, 900)
    }
    function later() { chosenLater = true; mode = "local"; who = ({}); update() }
    function backToChoose() { chosenLater = false; mode = ""; who = ({}); pin1 = ""; pin2 = ""; config.setUserPassword(""); config.setUserPasswordSecondary(""); update() }

    // the two PIN boxes as typed (Calamares doesn't signal every change of its copies)
    property string pin1: ""
    property string pin2: ""
    readonly property bool pinOk: /^[0-9]{4,16}$/.test(pin1) && pin1 === pin2
    function setPin(first, t) {
        if (first) { pin1 = t; config.setUserPassword(t) } else { pin2 = t; config.setUserPasswordSecondary(t) }
        update()
    }
    function update() {
        let reason = ""
        if (online === "checking") reason = qsTr("Checking the internet…")
        else if (mode === "") reason = qsTr("Choose an account, or Later.")
        else if (mode === "signing") reason = qsTr("Finish signing in, or close the sign-in window.")
        else if (mode === "local" && config.fullName.trim() === "") reason = qsTr("Type your name.")
        else if (!pinOk) reason = qsTr("Choose a PIN (4 to 16 digits) and type it twice.")
        helper.note("block.json", { step: "account", reason: reason })
        helper.note("account.json", { mode: mode === "linked" ? "linked" : "local", pinLength: pin1.length,
                                      provider: mode === "linked" ? provider : "", email: who.email || "" })
    }
    Connections {
        target: config
        function onFullNameChanged() { page.update() }
    }

    // ---------- small parts ----------
    component Choice: Rectangle {
        id: choice
        property string key
        property string name
        property string icon
        property string detail
        property bool ready: true
        signal picked()
        Layout.fillWidth: true
        implicitHeight: 62
        radius: 12
        color: area.containsMouse && ready ? Qt.rgba(1, 1, 1, 0.06) : Qt.rgba(1, 1, 1, 0.03)
        border.width: activeFocus ? 2 : 1
        border.color: activeFocus ? "#7D97FF" : Qt.rgba(125 / 255, 151 / 255, 1, 0.14)
        opacity: ready ? 1 : 0.45
        activeFocusOnTab: ready
        Keys.onSpacePressed: picked()
        Keys.onReturnPressed: picked()
        RowLayout {
            anchors.fill: parent
            anchors.leftMargin: 18
            anchors.rightMargin: 18
            spacing: 14
            Image { source: choice.icon; sourceSize.height: 26; fillMode: Image.PreserveAspectFit; Layout.preferredWidth: 26; Layout.preferredHeight: 26 }
            Column {
                Layout.fillWidth: true
                spacing: 2
                Text { text: choice.name; color: "#E8ECFA"; font.pixelSize: 15; font.weight: Font.Medium }
                Text { text: choice.detail; color: "#8A93B8"; font.pixelSize: 12; visible: text !== "" }
            }
            Text { visible: !choice.ready; text: qsTr("Soon"); color: "#8A93B8"; font.pixelSize: 12 }
            Text { visible: choice.ready; text: "›"; color: "#8A93B8"; font.pixelSize: 22 }
        }
        MouseArea { id: area; anchors.fill: parent; hoverEnabled: true; enabled: choice.ready; cursorShape: Qt.PointingHandCursor; onClicked: choice.picked() }
    }
    component PinField: Field {
        echoMode: eye.shown ? TextInput.Normal : TextInput.Password
        input.validator: RegularExpressionValidator { regularExpression: /[0-9]{0,16}/ }
        input.inputMethodHints: Qt.ImhDigitsOnly
        input.rightPadding: 40
        Item {
            id: eye
            property bool shown: false
            parent: input
            anchors.right: parent.right
            anchors.rightMargin: 12
            anchors.verticalCenter: parent.verticalCenter
            width: 22; height: 14
            // an eye: two curves and the pupil (filled in while the PIN shows)
            Shape {
                anchors.fill: parent
                ShapePath {
                    strokeColor: eye.shown ? "#7D97FF" : "#8A93B8"; strokeWidth: 1.5; fillColor: "transparent"
                    startX: 1; startY: 7
                    PathQuad { x: 21; y: 7; controlX: 11; controlY: -4 }
                    PathQuad { x: 1; y: 7; controlX: 11; controlY: 18 }
                }
            }
            Rectangle { anchors.centerIn: parent; width: 6; height: 6; radius: 3; color: eye.shown ? "#7D97FF" : "transparent"; border.width: 1.5; border.color: eye.shown ? "#7D97FF" : "#8A93B8" }
            MouseArea { anchors.fill: parent; anchors.margins: -6; cursorShape: Qt.PointingHandCursor; onClicked: eye.shown = !eye.shown }
        }
    }
    component Tip: Rectangle {
        Layout.fillWidth: true
        implicitHeight: tipRow.implicitHeight + 20
        radius: 10
        gradient: Gradient {
            orientation: Gradient.Horizontal
            GradientStop { position: 0; color: Qt.rgba(65 / 255, 105 / 255, 225 / 255, 0.14) }
            GradientStop { position: 1; color: Qt.rgba(125 / 255, 151 / 255, 1, 0.04) }
        }
        border.color: Qt.rgba(125 / 255, 151 / 255, 1, 0.14)
        RowLayout {
            id: tipRow
            anchors.fill: parent
            anchors.margins: 10
            anchors.leftMargin: 14
            spacing: 12
            // a phone
            Rectangle { Layout.alignment: Qt.AlignTop; width: 13; height: 21; radius: 3; color: "transparent"; border.width: 1.5; border.color: "#7D97FF"
                Rectangle { anchors.bottom: parent.bottom; anchors.bottomMargin: 3; anchors.horizontalCenter: parent.horizontalCenter; width: 4; height: 1.5; color: "#7D97FF" } }
            Text {
                Layout.fillWidth: true
                textFormat: Text.StyledText
                wrapMode: Text.Wrap
                color: "#8A93B8"; font.pixelSize: 13
                text: "<b><font color='#E8ECFA'>" + qsTr("Tip:") + "</font></b> " + qsTr("after setup, add an authenticator app in Settings > Accounts. A code from your phone then gets you back in if you forget the PIN, even without internet.")
            }
        }
    }
    component LinkText: Text {
        signal clicked()
        color: "#7D97FF"; font.pixelSize: 14
        MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: parent.clicked() }
    }

    Flickable {
        anchors.fill: parent
        anchors.leftMargin: 40
        anchors.rightMargin: 40
        anchors.topMargin: 24
        contentHeight: views.implicitHeight + 16
        clip: true
        boundsBehavior: Flickable.StopAtBounds
        ScrollBar.vertical: ThinScrollBar { }

        Item {
            id: views
            width: parent.width - 14
            implicitHeight: Math.max(choose.visible ? choose.implicitHeight : 0, linked.visible ? linked.implicitHeight : 0,
                                     local.visible ? local.implicitHeight : 0, wait.visible ? wait.implicitHeight : 0)

            // ---------- checking ----------
            ColumnLayout {
                id: wait
                visible: page.online === "checking"
                width: parent.width
                Heading { text: qsTr("Connect your account") }
                Text { text: qsTr("Checking the internet…"); color: "#8A93B8"; font.pixelSize: 14 }
            }

            // ---------- choose (online) ----------
            ColumnLayout {
                id: choose
                visible: page.online === "yes" && (page.mode === "" || page.mode === "signing")
                width: parent.width
                spacing: 12
                Heading { text: qsTr("Connect your account") }
                Text {
                    Layout.fillWidth: true
                    text: qsTr("If you forget your PIN, your account gets you back in. Your name and picture come with it. You still sign in with the PIN, even without internet.")
                    color: "#8A93B8"; font.pixelSize: 14; wrapMode: Text.Wrap
                }
                Choice { key: "google"; name: "Google"; icon: "google.svg"; detail: qsTr("Gmail and any Google account"); onPicked: page.signIn("google") }
                Choice { key: "zoho"; name: "Zoho"; icon: "zoho.svg"; detail: qsTr("Zoho Mail and any Zoho account"); onPicked: page.signIn("zoho") }
                Choice { key: "microsoft"; name: "Microsoft"; icon: "microsoft.svg"; ready: false }
                Choice { key: "later"; name: qsTr("Later"); icon: "mark.svg"; detail: qsTr("Make a local account now; connect one any time in Settings > Accounts"); onPicked: page.later() }
                Text {
                    Layout.fillWidth: true
                    visible: page.mode === "signing" || page.signError !== ""
                    text: page.mode === "signing" ? qsTr("Sign in to %1 in the window that opened…").arg(page.pname(page.provider)) : page.signError
                    color: page.mode === "signing" ? "#7D97FF" : "#FF6B7A"
                    font.pixelSize: 14; wrapMode: Text.Wrap
                }
            }

            // ---------- signed in: choose a PIN (like Settings > Accounts) ----------
            ColumnLayout {
                id: linked
                visible: page.mode === "linked"
                width: parent.width
                spacing: 14
                Heading { text: qsTr("Choose a PIN") }
                Rectangle {
                    Layout.fillWidth: true
                    implicitHeight: 92
                    radius: 14
                    color: "#151E42"
                    border.color: "#4169E1"
                    RowLayout {
                        anchors.fill: parent
                        anchors.margins: 16
                        spacing: 16
                        Item {
                            Layout.preferredWidth: 58; Layout.preferredHeight: 58
                            Rectangle { anchors.fill: parent; radius: 29; color: "#7D97FF"
                                Text { anchors.centerIn: parent; text: (page.who.name || page.who.email || "?").charAt(0).toUpperCase(); color: "white"; font.family: medium.name; font.pixelSize: 24 } }
                            Image { anchors.fill: parent; source: page.who.picture || ""; fillMode: Image.PreserveAspectCrop; sourceSize.width: 116; visible: status === Image.Ready }
                            // round the picture: the card's colour outside the circle
                            Shape {
                                anchors.fill: parent
                                ShapePath {
                                    fillColor: "#151E42"; strokeColor: "transparent"; fillRule: ShapePath.OddEvenFill
                                    PathRectangle { x: 0; y: 0; width: 58; height: 58 }
                                    PathAngleArc { centerX: 29; centerY: 29; radiusX: 29; radiusY: 29; startAngle: 0; sweepAngle: 360 }
                                }
                            }
                        }
                        Column {
                            Layout.fillWidth: true
                            spacing: 3
                            Text { text: page.who.name || ""; color: "#E8ECFA"; font.family: medium.name; font.pixelSize: 18; elide: Text.ElideRight; width: parent.width }
                            Text { text: page.who.email || ""; color: "#8A93B8"; font.pixelSize: 13 }
                            Rectangle {
                                width: badge.implicitWidth + 30; height: 22; radius: 11
                                color: "transparent"; border.color: Qt.rgba(125 / 255, 151 / 255, 1, 0.22)
                                Image { x: 8; anchors.verticalCenter: parent.verticalCenter; source: page.provider === "zoho" ? "zoho.svg" : "google.svg"; sourceSize.height: 12; fillMode: Image.PreserveAspectFit; height: 12; width: 12 }
                                Text { id: badge; x: 24; anchors.verticalCenter: parent.verticalCenter; text: qsTr("%1 account").arg(page.pname(page.provider)); color: "#8A93B8"; font.pixelSize: 11 }
                            }
                        }
                    }
                }
                Text {
                    Layout.fillWidth: true
                    text: qsTr("Choose a PIN for this computer. You'll sign in with it, even without internet. If you forget it, “Forgot your PIN?” on the sign-in screen gets you back in.")
                    color: "#8A93B8"; font.pixelSize: 14; wrapMode: Text.Wrap
                }
                GridLayout {
                    Layout.fillWidth: true
                    columns: 2
                    columnSpacing: 18
                    PinField {
                        id: pinA
                        Layout.fillWidth: true; Layout.preferredWidth: 1; Layout.alignment: Qt.AlignTop
                        label: qsTr("PIN"); placeholder: qsTr("4 to 16 digits")
                        text: page.pin1
                        onEdited: function (t) { page.setPin(true, t) }
                        hint: text !== "" && text.length < 4 ? qsTr("At least 4 digits.") : ""
                        hintKind: -1
                    }
                    PinField {
                        Layout.fillWidth: true; Layout.preferredWidth: 1; Layout.alignment: Qt.AlignTop
                        label: qsTr("The PIN again")
                        text: page.pin2
                        onEdited: function (t) { page.setPin(false, t) }
                        hint: text === "" ? "" : text === pinA.text ? qsTr("They match.") : qsTr("The two PINs are not the same.")
                        hintKind: text === pinA.text ? 1 : -1
                    }
                }
                // an account name Calamares can't make from the name (e.g. not in Latin letters)
                Field {
                    visible: config.loginNameStatus !== ""
                    Layout.fillWidth: true
                    label: qsTr("Account name")
                    text: config.loginName
                    onEdited: function (t) { config.setLoginName(t) }
                    hint: config.loginNameStatus
                    hintKind: -1
                }
                Tip { }
                LinkText { text: qsTr("Use another account"); onClicked: page.backToChoose() }
            }

            // ---------- local account (Later, or no internet) ----------
            ColumnLayout {
                id: local
                visible: page.mode === "local"
                width: parent.width
                spacing: 12
                Heading { text: qsTr("Who will use this computer?") }
                Text {
                    Layout.fillWidth: true
                    text: page.online === "yes" ? qsTr("A local account: you can connect Google or Zoho any time in Settings > Accounts.")
                                                : qsTr("No internet, so a local account. Connect Google or Zoho any time in Settings > Accounts.")
                    color: "#8A93B8"; font.pixelSize: 14; wrapMode: Text.Wrap
                }
                RowLayout {
                    Layout.fillWidth: true
                    spacing: 16
                    Rectangle {
                        Layout.alignment: Qt.AlignTop
                        Layout.topMargin: 22
                        width: 44; height: 44; radius: 22
                        gradient: Gradient {
                            GradientStop { position: 0; color: "#7D97FF" }
                            GradientStop { position: 1; color: "#2B4FD8" }
                        }
                        Text { anchors.centerIn: parent; text: config.fullName.trim() !== "" ? config.fullName.trim()[0].toUpperCase() : "?"; color: "white"; font.family: medium.name; font.pixelSize: 20 }
                    }
                    GridLayout {
                        Layout.fillWidth: true
                        columns: 2
                        columnSpacing: 18
                        Field {
                            Layout.fillWidth: true; Layout.preferredWidth: 1; Layout.alignment: Qt.AlignTop
                            label: qsTr("Your name")
                            text: config.fullName
                            onEdited: function (t) { config.setFullName(t) }
                        }
                        Field {
                            Layout.fillWidth: true; Layout.preferredWidth: 1; Layout.alignment: Qt.AlignTop
                            label: qsTr("Account name")
                            text: config.loginName
                            onEdited: function (t) { config.setLoginName(t) }
                            hint: config.loginNameStatus !== "" ? config.loginNameStatus : qsTr("Lower-case letters and numbers. You don't type it to log in.")
                            hintKind: config.loginNameStatus !== "" ? -1 : 0
                        }
                    }
                }
                GridLayout {
                    Layout.fillWidth: true
                    columns: 2
                    columnSpacing: 18
                    PinField {
                        id: pinL
                        Layout.fillWidth: true; Layout.preferredWidth: 1; Layout.alignment: Qt.AlignTop
                        label: qsTr("PIN"); placeholder: qsTr("4 to 16 digits")
                        text: page.pin1
                        onEdited: function (t) { page.setPin(true, t) }
                        hint: text === "" ? qsTr("You sign in with it, even without internet.") : text.length < 4 ? qsTr("At least 4 digits.") : ""
                        hintKind: text !== "" && text.length < 4 ? -1 : 0
                    }
                    PinField {
                        Layout.fillWidth: true; Layout.preferredWidth: 1; Layout.alignment: Qt.AlignTop
                        label: qsTr("The PIN again")
                        text: page.pin2
                        onEdited: function (t) { page.setPin(false, t) }
                        hint: text === "" ? "" : text === pinL.text ? qsTr("They match.") : qsTr("The two PINs are not the same.")
                        hintKind: text === pinL.text ? 1 : -1
                    }
                }
                Tip { }
                Field {
                    Layout.fillWidth: true
                    Layout.maximumWidth: (parent.width - 18) / 2
                    label: qsTr("Computer name")
                    text: config.hostname
                    onEdited: function (t) { config.setHostName(t) }
                    hint: config.hostnameStatus !== "" ? config.hostnameStatus : qsTr("How other devices on the network see it.")
                    hintKind: config.hostnameStatus !== "" ? -1 : 0
                }
                LinkText { visible: page.online === "yes"; text: qsTr("Sign in with an account instead"); onClicked: page.backToChoose() }
            }
        }
    }
}
