# See module.desc.
import json

import libcalamares

GS = "/tmp/infinity-installer/gs.json"


def pretty_name():
    return "Getting the disk ready"


def run():
    try:
        with open(GS) as f:
            gs = json.load(f)
    except (OSError, ValueError):
        return ("No disk was chosen", "Go back to the Disk step and pick where Infinity goes.")
    for key, value in gs.items():
        libcalamares.globalstorage.insert(key, value)
    return None
