# Calamares' stock bootloader module (see module.desc), run as it is: its
# job configuration is infinitybootloader.conf (the stock settings).
import importlib.util

_spec = importlib.util.spec_from_file_location(
    "stock_bootloader", "/usr/lib/x86_64-linux-gnu/calamares/modules/bootloader/main.py")
_stock = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_stock)


def pretty_name():
    return _stock.pretty_name()


def run():
    return _stock.run()
