// The top bar's battery menu (in place of Plasma's org.kde.plasma.battery, whose
// time left came from UPower's jumpy guess): charge, a time left that holds
// still, battery health, the power mode and "Keep the computer awake".
// Everything comes from the battery agent (/usr/lib/infinity/battery,
// org.infinity.Battery on the session bus); on a computer without a battery
// it isn't there and this stays hidden.
import QtQuick
import QtQuick.Layouts
import org.kde.plasma.plasmoid
import org.kde.plasma.core as PlasmaCore
import org.kde.plasma.components as PlasmaComponents3
import org.kde.kirigami as Kirigami
import org.kde.kcmutils as KCMUtils
import org.kde.plasma.workspace.dbus as DBus

PlasmoidItem {
    id: root

    property var info: ({ present: false })
    readonly property int percent: info.percent || 0
    readonly property string state: info.state || ""

    function call(member, args, done) {
        const reply = DBus.SessionBus.asyncCall({
            service: "org.infinity.Battery", path: "/org/infinity/Battery",
            iface: "org.infinity.Battery", member: member, arguments: args })
        reply.finished.connect(function () {
            if (reply.isError) {
                root.info = { present: false }
                return
            }
            try { root.info = JSON.parse(reply.value) } catch (e) {}
            if (done) done()
        })
    }
    function refresh() { call("Get", []) }

    // 3 h 35 min (5-minute steps above an hour: the minutes aren't that exact)
    function duration(seconds) {
        let minutes = Math.round(seconds / 60)
        if (minutes < 60)
            return Math.max(1, minutes) + " min"
        minutes = Math.round(minutes / 5) * 5
        const h = Math.floor(minutes / 60), m = minutes % 60
        return m === 0 ? h + " h" : h + " h " + m + " min"
    }
    function stateText() {
        const left = info.secondsLeft === undefined ? -1 : info.secondsLeft
        switch (state) {
        case "discharging": return left >= 0 ? duration(left) + " left" : "Calculating time left…"
        case "charging": return left >= 0 ? "Charging · full in " + duration(left) : "Charging"
        case "full": return "Fully charged"
        case "plugged": return "Plugged in, not charging"
        }
        return ""
    }
    function iconName() {
        const level = ("00" + Math.min(100, Math.round(percent / 10) * 10)).slice(-3)
        return state === "full" ? "battery-100-charging"
             : "battery-" + level + (state === "charging" || state === "plugged" ? "-charging" : "")
    }
    function profileName(p) {
        return p === "power-saver" ? "Power saver" : p === "performance" ? "Performance" : "Balanced"
    }

    Plasmoid.icon: iconName()
    Plasmoid.status: !info.present ? PlasmaCore.Types.HiddenStatus
        : state === "discharging" && percent <= 10 ? PlasmaCore.Types.NeedsAttentionStatus
        : PlasmaCore.Types.ActiveStatus
    toolTipMainText: "Battery " + percent + "%"
    toolTipSubText: stateText()

    // more often while the menu is open
    Timer {
        interval: root.expanded ? 3000 : 15000
        running: true
        repeat: true
        triggeredOnStart: true
        onTriggered: root.refresh()
    }
    onExpandedChanged: if (expanded) refresh()

    fullRepresentation: Item {
        Layout.preferredWidth: Kirigami.Units.gridUnit * 20
        Layout.minimumWidth: Kirigami.Units.gridUnit * 16
        Layout.preferredHeight: content.implicitHeight + 2 * Kirigami.Units.gridUnit
        Layout.minimumHeight: Layout.preferredHeight

        ColumnLayout {
            id: content
            anchors.fill: parent
            anchors.margins: Kirigami.Units.gridUnit
            spacing: Kirigami.Units.largeSpacing

            // ---------- charge ----------
            RowLayout {
                Layout.fillWidth: true
                spacing: Kirigami.Units.largeSpacing
                Kirigami.Icon {
                    source: root.iconName()
                    Layout.preferredWidth: Kirigami.Units.iconSizes.large
                    Layout.preferredHeight: Kirigami.Units.iconSizes.large
                }
                ColumnLayout {
                    Layout.fillWidth: true
                    spacing: 0
                    Kirigami.Heading {
                        level: 1
                        text: root.percent + "%"
                    }
                    PlasmaComponents3.Label {
                        Layout.fillWidth: true
                        wrapMode: Text.Wrap
                        text: root.stateText()
                        opacity: 0.8
                    }
                }
            }
            PlasmaComponents3.ProgressBar {
                Layout.fillWidth: true
                from: 0
                to: 100
                value: root.percent
            }

            // ---------- details ----------
            GridLayout {
                Layout.fillWidth: true
                columns: 2
                columnSpacing: Kirigami.Units.largeSpacing
                rowSpacing: Kirigami.Units.smallSpacing
                PlasmaComponents3.Label { visible: root.info.health > 0; text: "Battery health"; opacity: 0.7 }
                PlasmaComponents3.Label {
                    visible: root.info.health > 0
                    Layout.fillWidth: true
                    horizontalAlignment: Text.AlignRight
                    text: root.info.health + "% of its capacity when new"
                }
                PlasmaComponents3.Label { visible: root.info.cycles > 0; text: "Charge cycles"; opacity: 0.7 }
                PlasmaComponents3.Label {
                    visible: root.info.cycles > 0
                    Layout.fillWidth: true
                    horizontalAlignment: Text.AlignRight
                    text: String(root.info.cycles || 0)
                }
                PlasmaComponents3.Label {
                    visible: root.info.watts > 0 && (root.state === "discharging" || root.state === "charging")
                    text: root.state === "charging" ? "Charging at" : "Using"
                    opacity: 0.7
                }
                PlasmaComponents3.Label {
                    visible: root.info.watts > 0 && (root.state === "discharging" || root.state === "charging")
                    Layout.fillWidth: true
                    horizontalAlignment: Text.AlignRight
                    text: (root.info.watts || 0).toFixed(1) + " W"
                }
            }

            // ---------- power mode ----------
            ColumnLayout {
                visible: (root.info.profiles || []).length > 1
                Layout.fillWidth: true
                spacing: Kirigami.Units.smallSpacing
                PlasmaComponents3.Label {
                    text: "Power mode"
                    opacity: 0.7
                }
                RowLayout {
                    Layout.fillWidth: true
                    spacing: Kirigami.Units.smallSpacing
                    Repeater {
                        model: root.info.profiles || []
                        PlasmaComponents3.Button {
                            required property string modelData
                            Layout.fillWidth: true
                            text: root.profileName(modelData)
                            // shown, not toggled by a click: the agent's answer decides
                            checkable: false
                            checked: root.info.profile === modelData
                            onClicked: root.call("Do", ["profile " + modelData])
                        }
                    }
                }
            }

            // ---------- keep awake ----------
            PlasmaComponents3.Switch {
                Layout.fillWidth: true
                text: "Keep the computer awake (no sleep, no screen lock)"
                checked: !!root.info.blocked
                onToggled: {
                    root.call("Do", ["block " + (checked ? "on" : "off")])
                    checked = Qt.binding(() => !!root.info.blocked)   // the click broke it
                }
            }

            PlasmaComponents3.ToolButton {
                Layout.alignment: Qt.AlignRight
                icon.name: "configure"
                text: "Power settings"
                onClicked: KCMUtils.KCMLauncher.openSystemSettings("kcm_powerdevilprofilesconfig")
            }
        }
    }
}
