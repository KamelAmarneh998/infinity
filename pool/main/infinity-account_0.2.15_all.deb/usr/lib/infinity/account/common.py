# Infinity Account: shared parts of accountd (the root service) and pam-auth.
#
# A computer account can be connected to the person's Google account (Microsoft
# and Zoho later): they sign in on Google's own page, and the computer keeps who
# they are (Google's "sub", e-mail, name, picture). Google never gives us the
# password, so the computer gets its own PIN (the computer account's password,
# digits only). Forgot the PIN: signing in with Google again (on a phone, from
# the sign-in screen) lets them choose a new one. A recovery key (any account)
# signs in once.
#
# State, root only: /var/lib/infinity/account/
#   users/<user>.json     {"provider", "sub", "email", "name", "picture"}   the link
#   keys/<user>.json      {"salt", "hash", "made"}    the recovery key (PBKDF2)
#   tries/<user>          failed tries (time per line)
#   reset/<user>.json     signed in with the key: must choose a new PIN/password
# Readable by the sign-in and lock screens: /var/lib/infinity/account-public/
#   <user>.json           {"pin": length, "provider", "email"}: the PIN screen
#                         signs in when this many digits are typed
import ctypes, ctypes.util, hashlib, hmac, json, os, pwd, secrets, subprocess, time, urllib.error, urllib.parse, urllib.request

STATE = "/var/lib/infinity/account"
KEY = "AIzaSyBV5w8N2YHEkJTg3p8jDyJKQnKKBIEfqJo"
API = "https://identitytoolkit.googleapis.com/v1/accounts:"
PROJECT = "infinityos-desktop"
REPO_URL = "https://kamelamarneh998.github.io/infinity"
PUBLIC = "/var/lib/infinity/account-public"
GOOGLE_CLIENTS = ("521329188473-ihqkb8mnm3v5m24h2ssvjpo7b6knma2e.apps.googleusercontent.com", "521329188473-36qqh519671qvk0a4km1g4svtj220d4t.apps.googleusercontent.com")
if os.geteuid() == 0:
    for d in ("users", "keys", "tries", "reset", "emailreset", "totp", "totp-new", "grant", "newkey", "pintries", "wallet"):
        os.makedirs(os.path.join(STATE, d), mode=0o700, exist_ok=True)
    os.makedirs(PUBLIC, mode=0o755, exist_ok=True)


class Problem(Exception):
    """Something to tell the person (plain English)."""


def _path(kind, user, ext=".json"):
    if not user or "/" in user or user.startswith("."):
        raise Problem("Unknown account.")
    return os.path.join(STATE, kind, user + ext)


def read(kind, user):
    try:
        with open(_path(kind, user)) as f:
            return json.load(f)
    except FileNotFoundError:
        return None


def write(kind, user, data):
    path = _path(kind, user)
    tmp = path + ".new"
    with open(os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600), "w") as f:
        json.dump(data, f)
    os.replace(tmp, path)


def remove(kind, user, ext=".json"):
    try:
        os.remove(_path(kind, user, ext))
    except FileNotFoundError:
        pass


# ---------- Firebase (REST) ----------

MESSAGES = {
    "EMAIL_EXISTS": "There is already an Infinity Account with this e-mail. Sign in instead.",
    "INVALID_LOGIN_CREDENTIALS": "The e-mail or the password is not right.",
    "INVALID_PASSWORD": "The e-mail or the password is not right.",
    "EMAIL_NOT_FOUND": "The e-mail or the password is not right.",
    "INVALID_EMAIL": "That doesn't look like an e-mail address.",
    "USER_DISABLED": "This Infinity Account has been turned off.",
    "TOO_MANY_ATTEMPTS_TRY_LATER": "Too many tries. Wait a few minutes and try again.",
    "WEAK_PASSWORD": "Choose a longer password (at least 6 characters).",
    "PASSWORD_DOES_NOT_MEET_REQUIREMENTS": "Choose a stronger password.",
    "CREDENTIAL_TOO_OLD_LOGIN_AGAIN": "Sign in again, then change the password.",
}


def firebase(method, body, timeout=8):
    req = urllib.request.Request(API + method + "?key=" + KEY, data=json.dumps(body).encode(),
                                 headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.load(r)
    except urllib.error.HTTPError as e:
        try:
            code = json.load(e)["error"]["message"]
        except Exception:
            code = str(e.code)
        code = code.split(" ")[0].split(":")[0]
        raise Problem(MESSAGES.get(code, "The Infinity Account service said no (" + code + ")."))
    except (urllib.error.URLError, TimeoutError, OSError):
        raise Problem("No internet connection. Connect and try again.")


def google_identity(id_token):
    """Who an ID token from Google's sign-in says this is, checked by Google itself:
    issued for one of Infinity's clients, not expired, e-mail verified."""
    url = "https://oauth2.googleapis.com/tokeninfo?id_token=" + urllib.parse.quote(id_token)
    try:
        with urllib.request.urlopen(url, timeout=10) as r:
            info = json.load(r)
    except urllib.error.HTTPError:
        raise Problem("Google didn't accept the sign-in. Try again.")
    except (urllib.error.URLError, TimeoutError, OSError):
        raise Problem("No internet connection. Connect and try again.")
    if info.get("aud") not in GOOGLE_CLIENTS or info.get("iss") not in ("accounts.google.com", "https://accounts.google.com"):
        raise Problem("That sign-in wasn't made for Infinity.")
    if int(info.get("exp", 0)) < time.time():
        raise Problem("The sign-in took too long. Try again.")
    if info.get("email_verified") not in (True, "true"):
        raise Problem("Google hasn't confirmed this e-mail yet.")
    return {"provider": "google", "sub": info["sub"], "email": info.get("email", ""),
            "name": info.get("name", ""), "picture": info.get("picture", "")}


def zoho_identity(token):
    """Zoho: Settings sends the access token and the account's data centre; Zoho's own
    user-info answer says who this is (only Zoho's servers are asked)."""
    try:
        t = json.loads(token)
        access, server = t["access_token"], t["server"]
    except (ValueError, KeyError, TypeError):
        raise Problem("Zoho didn't finish the sign-in. Try again.")
    host = urllib.parse.urlparse(server).hostname or ""
    if not server.startswith("https://") or not host.startswith("accounts.zoho.") or "/" in server[8:]:
        raise Problem("That sign-in wasn't made for Infinity.")
    req = urllib.request.Request(server + "/oauth/v2/userinfo", headers={"Authorization": "Bearer " + access})
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            info = json.load(r)
    except urllib.error.HTTPError:
        raise Problem("Zoho didn't accept the sign-in. Try again.")
    except (urllib.error.URLError, TimeoutError, OSError):
        raise Problem("No internet connection. Connect and try again.")
    if not info.get("sub") or not info.get("email"):
        raise Problem("Zoho didn't say which account this is. Try again.")
    if info.get("email_verified") in (False, "false"):
        raise Problem("Zoho hasn't confirmed this e-mail yet.")
    name = info.get("name") or (str(info.get("first_name", "")) + " " + str(info.get("last_name", ""))).strip()
    return {"provider": "zoho", "sub": "zoho:" + str(info["sub"]), "email": info["email"],
            "name": name, "picture": info.get("picture", "")}


def identity(provider, token):
    if provider == "google":
        return google_identity(token)
    if provider == "zoho":
        return zoho_identity(token)
    raise Problem("This kind of account isn't ready yet.")


def publish(user):
    """What the sign-in and lock screens may know: how long the PIN is, and the account."""
    path = os.path.join(PUBLIC, user + ".json")
    link = read("users", user) or {}
    data = {}
    try:
        with open(os.path.join(STATE, "pinlen", user)) as f:
            data["pin"] = int(f.read().strip() or 0)
    except (FileNotFoundError, ValueError):
        pass
    if read("totp", user):
        data["totp"] = True   # the screens offer "Authenticator app" only then
    data["key"] = read("keys", user) is not None
    if link:
        data["provider"] = link["provider"]
        data["name"] = link.get("name", "")
        set_real_name(user, link.get("name", ""))
        pic = os.path.join(PUBLIC, user + ".jpg")
        if link.get("picture") and not _picture_ok(pic):
            fetch_picture(user, link["picture"])
        if os.path.exists(pic):
            data["picture"] = "file://" + pic
        e = link.get("email", "")
        # hidden a little: k•••l@gmail.com
        at = e.find("@")
        data["email"] = (e[0] + "•••" + e[at - 1:]) if at > 1 else e
    tmp = path + ".new"
    with open(tmp, "w") as f:
        json.dump(data, f)
    os.chmod(tmp, 0o644)
    os.replace(tmp, path)


def _picture_ok(path):
    try:
        with open(path, "rb") as f:
            head = f.read(4)
    except FileNotFoundError:
        return False
    return head[:3] == b"\xff\xd8\xff" or head == b"\x89PNG"


def fetch_picture(user, url):
    """The connected account's picture, kept on the computer: the screens show it without
    internet (the lock screen has none at all), and it becomes the computer account's
    picture (AccountsService: the menu, Settings > Users)."""
    if not url.startswith("https://"):
        return
    # 256 px, as JPEG ("-rj"; Google sends WebP otherwise, which Qt here can't read)
    url = url.replace("=s96-c", "=s256-c-rj")
    pic = os.path.join(PUBLIC, user + ".jpg")
    try:
        req = urllib.request.Request(url, headers={"Accept": "image/jpeg,image/png;q=0.9"})
        with urllib.request.urlopen(req, timeout=10) as r:
            data = r.read(2 * 1024 * 1024 + 1)
    except (urllib.error.URLError, TimeoutError, OSError, ValueError):
        return
    if not data or len(data) > 2 * 1024 * 1024 or not (data[:3] == b"\xff\xd8\xff" or data[:4] == b"\x89PNG"):
        return
    tmp = pic + ".new"
    with open(tmp, "wb") as f:
        f.write(data)
    os.chmod(tmp, 0o644)
    os.replace(tmp, pic)
    try:
        uid = pwd.getpwnam(user).pw_uid
        subprocess.run(["busctl", "call", "org.freedesktop.Accounts", f"/org/freedesktop/Accounts/User{uid}",
                        "org.freedesktop.Accounts.User", "SetIconFile", "s", pic],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=10, check=False)
    except (KeyError, OSError, subprocess.SubprocessError):
        pass


def set_real_name(user, name):
    """The computer account's full name becomes the connected account's name: Settings'
    greeting, the menu, the screens all show the same name."""
    name = name.replace(":", " ").replace(",", " ").replace("\n", " ").strip()[:80]
    try:
        p = pwd.getpwnam(user)
    except KeyError:
        return
    if not name or p.pw_gecos.split(",")[0] == name:
        return
    subprocess.run(["busctl", "call", "org.freedesktop.Accounts", f"/org/freedesktop/Accounts/User{p.pw_uid}",
                    "org.freedesktop.Accounts.User", "SetRealName", "s", name],
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=10, check=False)


def forget_picture(user):
    try:
        os.remove(os.path.join(PUBLIC, user + ".jpg"))
    except FileNotFoundError:
        pass


def set_pin(user, pin):
    if not pin.isdigit() or not 4 <= len(pin) <= 16:
        raise Problem("A PIN is 4 to 16 digits.")
    set_local_password(user, pin)
    os.makedirs(os.path.join(STATE, "pinlen"), mode=0o700, exist_ok=True)
    with open(os.open(os.path.join(STATE, "pinlen", user), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600), "w") as f:
        f.write(str(len(pin)))
    publish(user)


def set_password(user, password):
    """A password instead of a PIN: the screens wait for Enter again."""
    if len(password) < 6:
        raise Problem("Choose a longer password (at least 6 characters).")
    set_local_password(user, password)
    try:
        os.remove(os.path.join(STATE, "pinlen", user))
    except FileNotFoundError:
        pass
    publish(user)


def too_many(user, limit=8, window=900):
    """Tries (wrong PINs at the reset, wrong keys) in the last 15 minutes."""
    try:
        now = time.time()
        return len([t for t in open(_path("tries", user, "")).read().split() if now - float(t) < window]) >= limit
    except FileNotFoundError:
        return False


# ---------- the computer's own password ----------

def set_local_password(user, password):
    if "\n" in password or ":" in user:
        raise Problem("That password can't be used.")
    r = subprocess.run(["chpasswd"], input=f"{user}:{password}\n", text=True, capture_output=True)
    if r.returncode != 0:
        raise Problem("The computer's password couldn't be changed.")


# Checks a password with PAM's own "login" rules (pam_unix), as root.
class _Msg(ctypes.Structure):
    _fields_ = [("style", ctypes.c_int), ("msg", ctypes.c_char_p)]


class _Resp(ctypes.Structure):
    _fields_ = [("resp", ctypes.c_void_p), ("retcode", ctypes.c_int)]  # PAM frees resp: malloc'd


_CONV = ctypes.CFUNCTYPE(ctypes.c_int, ctypes.c_int, ctypes.POINTER(ctypes.POINTER(_Msg)),
                         ctypes.POINTER(ctypes.POINTER(_Resp)), ctypes.c_void_p)


class _Conv(ctypes.Structure):
    _fields_ = [("conv", _CONV), ("data", ctypes.c_void_p)]


_DELAY = ctypes.CFUNCTYPE(None, ctypes.c_int, ctypes.c_uint, ctypes.c_void_p)
_NO_DELAY = _DELAY(lambda retval, usec, data: None)
PAM_FAIL_DELAY = 10


def local_password_ok(user, password, wait=True):
    """Only pam_unix (the computer's own copy): never the Infinity Account.
    wait=False: no pam_unix pause after a wrong one (the caller limits tries itself)."""
    pam = ctypes.CDLL(ctypes.util.find_library("pam"))
    libc = ctypes.CDLL(ctypes.util.find_library("c"))
    libc.calloc.restype = ctypes.c_void_p
    libc.calloc.argtypes = [ctypes.c_size_t, ctypes.c_size_t]
    libc.strdup.restype = ctypes.c_void_p
    libc.strdup.argtypes = [ctypes.c_char_p]

    @_CONV
    def conv(n, msgs, resp, data):
        arr = ctypes.cast(libc.calloc(n, ctypes.sizeof(_Resp)), ctypes.POINTER(_Resp))
        for i in range(n):
            if msgs[i].contents.style in (1, 2):  # PAM_PROMPT_ECHO_OFF / ON: the password
                arr[i].resp = libc.strdup(password.encode())
        resp[0] = arr
        return 0

    handle = ctypes.c_void_p()
    # "infinity-account-check" = pam_unix only (/etc/pam.d), so the check never
    # loops back into the Infinity Account.
    if pam.pam_start(b"infinity-account-check", user.encode(), ctypes.byref(_Conv(conv, None)), ctypes.byref(handle)) != 0:
        return False
    if not wait:
        pam.pam_set_item(handle, PAM_FAIL_DELAY, _NO_DELAY)
    ok = pam.pam_authenticate(handle, 0) == 0
    pam.pam_end(handle, 0)
    return ok


# ---------- recovery keys ----------

ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"  # no 0/O, 1/I


def make_key(user):
    raw = "".join(secrets.choice(ALPHABET) for _ in range(24))
    key = "-".join(raw[i:i + 4] for i in range(0, 24, 4))
    salt = secrets.token_hex(16)
    write("keys", user, {"salt": salt, "hash": _hash(key, salt), "made": int(time.time())})
    return key


def _hash(key, salt):
    clean = key.upper().replace("-", "").replace(" ", "")
    return hashlib.pbkdf2_hmac("sha256", clean.encode(), bytes.fromhex(salt), 300000).hex()


def looks_like_key(text):
    clean = text.upper().replace("-", "").replace(" ", "")
    return len(clean) == 24 and all(c in ALPHABET for c in clean)


def key_ok(user, key):
    """True once: a used key is gone. Five wrong tries wait 15 minutes."""
    k = read("keys", user)
    if not k:
        return False
    tries_file = _path("tries", user, "")
    now = time.time()
    try:
        tries = [float(t) for t in open(tries_file).read().split() if now - float(t) < 900]
    except FileNotFoundError:
        tries = []
    if len(tries) >= 5:
        return False
    if hmac.compare_digest(_hash(key, k["salt"]), k["hash"]):
        remove("keys", user)
        remove("tries", user, "")
        return True
    tries.append(now)
    with open(os.open(tries_file, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600), "w") as f:
        f.write("\n".join(str(t) for t in tries))
    return False


def add_try(user):
    path = _path("tries", user, "")
    now = time.time()
    try:
        tries = [t for t in open(path).read().split() if now - float(t) < 900]
    except FileNotFoundError:
        tries = []
    tries.append(str(now))
    with open(os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600), "w") as f:
        f.write("\n".join(tries))


# ---------- authenticator app (TOTP, RFC 6238: 6 digits, 30 s, SHA-1) ----------
# Works with Microsoft/Google Authenticator and the like, without internet on
# either side. The secret stays in /var/lib/infinity/account/totp (root only).

import base64, struct as _struct


def totp_code(secret_b32, step):
    key = base64.b32decode(secret_b32)
    mac = hmac.new(key, _struct.pack(">Q", step), hashlib.sha1).digest()
    o = mac[-1] & 15
    return "%06d" % ((_struct.unpack(">I", mac[o:o + 4])[0] & 0x7FFFFFFF) % 1000000)


def totp_new(user, label):
    secret = base64.b32encode(secrets.token_bytes(20)).decode()
    write("totp-new", user, {"secret": secret, "t": time.time()})
    issuer = "Infinity"
    uri = ("otpauth://totp/" + urllib.parse.quote(issuer + ":" + label) + "?secret=" + secret
           + "&issuer=" + urllib.parse.quote(issuer) + "&algorithm=SHA1&digits=6&period=30")
    return {"uri": uri, "secret": " ".join(secret[i:i + 4] for i in range(0, len(secret), 4))}


def _totp_match(secret, code, last):
    now = int(time.time() // 30)
    for step in (now - 1, now, now + 1):
        if step > last and hmac.compare_digest(totp_code(secret, step), code):
            return step
    return None


def totp_confirm(user, code):
    new = read("totp-new", user)
    if not new or time.time() - new["t"] > 15 * 60:
        raise Problem("Start again: the QR code is too old.")
    step = _totp_match(new["secret"], code, 0)
    if step is None:
        raise Problem("That code isn't right. Type the 6 digits the app shows now.")
    write("totp", user, {"secret": new["secret"], "last": step})
    remove("totp-new", user)
    publish(user)


def totp_ok(user, code):
    """A code from the app (each code works once)."""
    t = read("totp", user)
    if not t or not code.isdigit() or len(code) != 6:
        return False
    step = _totp_match(t["secret"], code, t.get("last", 0))
    if step is None:
        return False
    t["last"] = step
    write("totp", user, t)
    return True


# ---------- the screens' PIN check (no PAM pause; own limits) ----------

def pin_wait(user):
    """Seconds still to wait before the next PIN try: 5 wrong in an hour -> 30 s after the
    last one, 10 -> 5 minutes."""
    now = time.time()
    try:
        tries = [float(t) for t in open(_path("pintries", user, "")).read().split() if now - float(t) < 3600]
    except (FileNotFoundError, ValueError):
        return 0
    if not tries:
        return 0
    pause = 300 if len(tries) >= 10 else 30 if len(tries) >= 5 else 0
    return max(0, int(tries[-1] + pause - now + 0.999))


def pin_check(user, pin):
    """True/False at once (no 2-second pam_unix pause)."""
    if pin_wait(user):
        raise Problem("Too many tries.")
    if local_password_ok(user, pin, wait=False):
        remove("pintries", user, "")
        return True
    path = _path("pintries", user, "")
    now = time.time()
    try:
        tries = [t for t in open(path).read().split() if now - float(t) < 3600]
    except FileNotFoundError:
        tries = []
    tries.append(str(now))
    with open(os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600), "w") as f:
        f.write("\n".join(tries))
    return False


# ---------- the wallet's own key ----------
# KDE's wallet (ksecretd) used to open with the sign-in password (pam_kwallet); a PIN
# changed in Settings or after "Forgot your PIN?" left it on the old one, and apps then
# asked for that. Now each account's wallet has a random key of its own, kept here (root
# only) and handed to the person's own session (the wallet agent opens the wallet with it).

def wallet_secret(user):
    w = read("wallet", user)
    if not w:
        w = {"secret": secrets.token_hex(32)}
        write("wallet", user, w)
    return w["secret"]
