[General]
Name=Infinity
Parent=FALLBACK/
ShowTerminalSizeHint=false
