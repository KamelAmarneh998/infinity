// A round button with an icon and a label under it (Sleep, Restart, Shut down).
import QtQuick

Column {
    id: button
    property string icon
    property string label
    property real u: 16
    property string fontFamily: ""
    signal activated()
    spacing: 0.35 * u

    Rectangle {
        anchors.horizontalCenter: parent.horizontalCenter
        width: 2.6 * button.u
        height: width
        radius: width / 2
        color: area.containsMouse ? Qt.rgba(1, 1, 1, 0.16) : Qt.rgba(1, 1, 1, 0.08)
        border.color: Qt.rgba(1, 1, 1, 0.12)
        border.width: 1
        Image {
            anchors.centerIn: parent
            source: button.icon
            sourceSize.width: 1.2 * button.u
            sourceSize.height: 1.2 * button.u
        }
        MouseArea {
            id: area
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: button.activated()
        }
    }
    Text {
        anchors.horizontalCenter: parent.horizontalCenter
        text: button.label
        color: Qt.rgba(232 / 255, 236 / 255, 250 / 255, 0.78)
        font.family: button.fontFamily
        font.pixelSize: 0.62 * button.u
    }
}
