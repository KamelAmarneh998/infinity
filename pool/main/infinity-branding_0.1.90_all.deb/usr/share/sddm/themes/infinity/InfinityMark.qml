// The faint ∞ across the wallpaper (90% of the screen width), with the boot
// screen's band of light passing over it once every 6 s. Shared by the login
// screen, the lock screen and the shut-down screen.
import QtQuick

Canvas {
    id: mark
    // The screen this sits on; the ∞ is 280 of the 320-unit wide drawing,
    // so 103% of the screen width puts it at 90%.
    property Item screen: parent
    width: screen.width * 1.03
    height: width / 2
    x: (screen.width - width) / 2
    y: (screen.height - height) / 2

    property real shift: -400

    SequentialAnimation on shift {
        loops: Animation.Infinite
        NumberAnimation { from: -400; to: 400; duration: 3300; easing.type: Easing.InOutQuad }
        PauseAnimation { duration: 2700 }
    }
    onShiftChanged: requestPaint()

    onPaint: {
        var ctx = getContext("2d")
        ctx.reset()
        var s = width / 320
        ctx.scale(s, s)
        ctx.translate(-140, -70)
        function infinity() {
            ctx.beginPath()
            ctx.moveTo(300, 150)
            ctx.bezierCurveTo(340, 90, 440, 90, 440, 150)
            ctx.bezierCurveTo(440, 210, 340, 210, 300, 150)
            ctx.bezierCurveTo(260, 90, 160, 90, 160, 150)
            ctx.bezierCurveTo(160, 210, 260, 210, 300, 150)
            ctx.closePath()
        }
        infinity()
        ctx.globalAlpha = 0.16
        ctx.strokeStyle = "#7D97FF"
        ctx.lineWidth = 1.2
        ctx.stroke()

        var band = ctx.createLinearGradient(250 + shift, 0, 350 + shift, 0)
        band.addColorStop(0, "rgba(255,255,255,0)")
        band.addColorStop(0.5, "rgba(255,255,255,0.9)")
        band.addColorStop(1, "rgba(255,255,255,0)")
        infinity()
        ctx.globalAlpha = 0.55
        ctx.strokeStyle = band
        ctx.lineWidth = 1.6
        ctx.stroke()
    }
}
