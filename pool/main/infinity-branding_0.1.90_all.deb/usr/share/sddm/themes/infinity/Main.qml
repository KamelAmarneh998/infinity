// Infinity login screen (SDDM), as designed in distro/branding/login-preview.html
// (proposal C, "Card").
//
// Kept deliberately light, plain QtQuick only, so it is on screen quickly after
// the boot screen hands over (see infinity-plymouth-handoff); there is no
// logo here, the boot screen already showed it.
//
// Layout: wallpaper with a faint ∞ and a slow band of light across it; one
// glass card in the middle (clock, date, the user, the password field);
// "Switch user" and the keyboard language floating bottom left; Sleep /
// Restart / Shut down bottom right.
import QtQuick
import QtQuick.Window
import org.kde.plasma.workspace.components as PW

Rectangle {
    id: root
    width: 1600
    height: 900
    color: "black"

    // One unit = 1.25% of the screen width (16 px on a 1280 px wide screen);
    // every size below is a multiple of it, like the preview's "em".
    readonly property real u: Math.max(10, width * 0.0125)

    readonly property color ink: "#E8ECFA"
    readonly property color inkSoft: Qt.rgba(232 / 255, 236 / 255, 250 / 255, 0.78)
    readonly property color muted: "#8A93B8"
    readonly property color royal: "#4169E1"
    readonly property color royalDeep: "#2B4FD8"
    readonly property color royalLight: "#7D97FF"
    readonly property color glass: Qt.rgba(14 / 255, 20 / 255, 44 / 255, 0.62)
    readonly property color line: Qt.rgba(125 / 255, 151 / 255, 1, 0.22)
    readonly property color errorColor: "#FF6B7A"
    readonly property string uiFont: "Noto Sans"

    // The account the password is for: the last one used, else the first.
    property string userName: userModel.lastUser
    property string userLabel: userName

    // The account's PIN length (0: a password), from the Infinity Account service: a PIN
    // signs in as soon as it has this many digits, without Enter.
    property int pinLength: 0
    readonly property bool pinMode: pinLength > 0
    property string accountProvider: ""
    property string accountEmail: ""
    property bool hasTotp: false
    property string accountName: ""      // the connected account's name and picture
    property string accountPicture: ""
    property bool hasKey: false
    function loadAccount() {
        const x = new XMLHttpRequest()
        x.open("GET", "http://127.0.0.1:6745/status?user=" + encodeURIComponent(root.userName))
        x.onreadystatechange = function () {
            if (x.readyState !== XMLHttpRequest.DONE) return
            let d = {}
            try { d = JSON.parse(x.responseText) } catch (e) {}
            root.pinLength = d.pin || 0
            root.accountProvider = d.provider || ""
            root.accountEmail = d.email || ""
            root.hasTotp = d.totp === true
            root.accountName = d.name || ""
            root.accountPicture = d.picture || ""
            root.hasKey = d.key === true
        }
        x.send()
    }
    onUserNameChanged: loadAccount()

    // A PIN empties the box at once; one typed while the last is checked goes next.
    // It is checked by the Infinity Account service first (/pin-check: answers at once,
    // limits the tries): a wrong one never reaches PAM, which pauses 2 seconds after
    // each wrong one. A right one signs in through SDDM as usual.
    property bool checking: false
    property string queued: ""
    // After too many wrong PINs the box is closed while the wait counts down.
    property int waitLeft: 0
    function showWait() {
        message.color = root.errorColor
        message.text = "Too many tries. Try again in " + (waitLeft >= 60 ? Math.ceil(waitLeft / 60) + " min" : waitLeft + " s") + "."
    }
    Timer {
        id: waitTimer
        interval: 1000
        repeat: true
        onTriggered: {
            root.waitLeft = Math.max(0, root.waitLeft - 1)
            if (root.waitLeft > 0) {
                root.showWait()
            } else {
                stop()
                message.text = ""
                password.forceActiveFocus()
            }
        }
    }
    function wrongPin(wait) {
        shake.restart()
        if (wait > 0) {
            waitLeft = wait
            showWait()
            waitTimer.restart()
            return
        }
        message.color = root.errorColor
        message.text = "Wrong PIN. Try again."
        password.forceActiveFocus()
    }
    function checkPin(secret) {
        checking = true
        const x = new XMLHttpRequest()
        x.open("POST", "http://127.0.0.1:6745/pin-check")
        x.setRequestHeader("Content-Type", "application/json")
        x.onreadystatechange = function () {
            if (x.readyState !== XMLHttpRequest.DONE) return
            let d = {}
            try { d = JSON.parse(x.responseText) } catch (e) {}
            if (d.right || d.ok !== true) {          // right, or the service can't tell: PAM decides
                sddm.login(root.userName, secret, sessionModel.lastIndex)
                return
            }
            checking = false
            wrongPin(d.wait || 0)
            if (queued !== "") { const next = queued; queued = ""; checkPin(next) }
        }
        x.send(JSON.stringify({ user: root.userName, pin: secret }))
    }
    function signIn() {
        message.text = ""
        if (password.text === "")
            return
        if (pinMode && /^[0-9]+$/.test(password.text)) {
            const pin = password.text
            password.text = ""
            if (checking) queued = pin
            else checkPin(pin)
            return
        }
        if (checking) {
            queued = password.text
            password.text = ""
            return
        }
        checking = true
        const secret = password.text
        if (pinMode)
            password.text = ""
        sddm.login(root.userName, secret, sessionModel.lastIndex)
    }

    // Montserrat, the wordmark's face, for the clock and the initials. Static
    // weights: with the variable font Qt picks its thinnest instance.
    FontLoader { id: wordFont; source: "Montserrat-Light.ttf" }
    FontLoader { source: "Montserrat-Medium.ttf" }

    // Tell the boot screen this one is drawn, so it lets go of the display
    // only now (no black gap on slow computers): infinity-plymouth-handoff
    // waits for this file. A moment after the first frame, so the wallpaper
    // and the card are in it.
    property bool told: false
    Connections {
        target: root.Window.window
        enabled: !root.told
        function onFrameSwapped() { if (!root.told) drawn.start() }
    }
    Timer {
        id: drawn
        interval: 300
        onTriggered: {
            root.told = true
            var x = new XMLHttpRequest()
            x.open("PUT", "file:///tmp/infinity-greeter-drawn")
            x.send("1")
        }
    }

    Connections {
        target: sddm
        function onLoginFailed() {
            message.color = root.errorColor
            message.text = root.pinMode ? "Wrong PIN. Try again." : "Wrong password. Try again."
            root.checking = false
            if (!root.pinMode)
                password.text = ""
            if (root.queued !== "") {
                const next = root.queued
                root.queued = ""
                root.checking = true
                sddm.login(root.userName, next, sessionModel.lastIndex)
            }
            shake.restart()
            password.forceActiveFocus()
        }
    }

    Timer {
        id: clock
        property date now: new Date()
        interval: 1000
        running: true
        repeat: true
        triggeredOnStart: true
        onTriggered: now = new Date()
    }

    Item {
        id: content
        anchors.fill: parent

        // Fade in from the black the boot screen hands over.
        NumberAnimation on opacity { from: 0; to: 1; duration: 450; easing.type: Easing.InOutQuad }

        Image {
            anchors.fill: parent
            source: "background.png"
            fillMode: Image.PreserveAspectCrop
        }

        // The faint ∞ with the band of light (InfinityMark.qml).
        InfinityMark { screen: root }

        // A click anywhere else closes the account list.
        MouseArea {
            anchors.fill: parent
            onClicked: { userList.visible = false; password.forceActiveFocus() }
        }

        // ---------- the card ----------
        Rectangle {
            id: card
            anchors.centerIn: parent
            width: 25 * root.u
            height: column.implicitHeight + 3.8 * root.u
            radius: 1.4 * root.u
            color: root.glass
            border.color: root.line
            border.width: 1

            // back from "Forgot your PIN?" (to the ways, or to the PIN box)
            Rectangle {
                visible: forgot.visible
                z: 1
                x: 1.1 * root.u
                y: 1.1 * root.u
                width: 2.2 * root.u
                height: width
                radius: width / 2
                color: forgotBack.containsMouse ? Qt.rgba(1, 1, 1, 0.14) : Qt.rgba(1, 1, 1, 0.06)
                border.color: Qt.rgba(1, 1, 1, 0.16)
                Image {
                    anchors.centerIn: parent
                    source: "icons/arrow.svg"
                    sourceSize.width: 0.95 * root.u
                    sourceSize.height: 0.95 * root.u
                    rotation: 180
                }
                MouseArea { id: forgotBack; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: forgot.back() }
            }
            Column {
                id: column
                y: 2.2 * root.u
                anchors.horizontalCenter: parent.horizontalCenter
                width: parent.width - 4.4 * root.u
                spacing: 0.9 * root.u

                // "Forgot your PIN?" is a page of its own in the card: its title instead of the clock
                Text {
                    anchors.horizontalCenter: parent.horizontalCenter
                    visible: forgot.visible
                    text: root.pinLength > 0 ? "Forgot your PIN?" : "Forgot your password?"
                    color: root.ink
                    font.family: wordFont.name
                    font.pixelSize: 1.6 * root.u
                }
                Text {
                    anchors.horizontalCenter: parent.horizontalCenter
                    visible: !forgot.visible
                    text: Qt.formatTime(clock.now, "h:mm AP")
                    color: root.ink
                    font.family: wordFont.name
                    font.weight: Font.Light
                    font.pixelSize: 3.4 * root.u
                }
                Text {
                    anchors.horizontalCenter: parent.horizontalCenter
                    visible: !forgot.visible
                    text: Qt.formatDate(clock.now, "dddd, MMMM d")
                    color: root.inkSoft
                    font.family: root.uiFont
                    font.pixelSize: root.u
                }
                Row {
                    anchors.horizontalCenter: parent.horizontalCenter
                    topPadding: 0.6 * root.u
                    spacing: 0.7 * root.u
                    Avatar {
                        size: 3 * root.u
                        letter: root.accountName || root.userLabel
                        source: root.accountPicture
                        fontFamily: wordFont.name
                        anchors.verticalCenter: parent.verticalCenter
                    }
                    Text {
                        anchors.verticalCenter: parent.verticalCenter
                        text: root.accountName || root.userLabel
                        color: root.ink
                        font.family: root.uiFont
                        font.weight: Font.Medium
                        font.pixelSize: 1.35 * root.u
                    }
                }

                // Password field: on a wrong password only this field shakes.
                Item {
                    id: field
                    opacity: root.waitLeft > 0 ? 0.45 : 1
                    // "Forgot your PIN?" takes its place
                    visible: !forgot.visible
                    width: parent.width
                    height: 2.9 * root.u
                    transform: Translate { id: shakeOffset }

                    Rectangle {
                        anchors.fill: parent
                        radius: height / 2
                        color: Qt.rgba(1, 1, 1, 0.08)
                        border.color: password.activeFocus ? root.royalLight : Qt.rgba(1, 1, 1, 0.16)
                        border.width: 1
                    }
                    TextInput {
                        id: password
                        enabled: root.waitLeft === 0
                        anchors.left: parent.left
                        anchors.leftMargin: 1.2 * root.u
                        anchors.right: mainEye.left
                        anchors.rightMargin: 0.6 * root.u
                        anchors.verticalCenter: parent.verticalCenter
                        echoMode: mainEye.shown ? TextInput.Normal : TextInput.Password
                        // a PIN signs in as soon as it's complete (a recovery key has letters: Enter)
                        onTextChanged: if (root.pinMode && text.length === root.pinLength && /^[0-9]+$/.test(text)) root.signIn()
                        passwordCharacter: "•"
                        color: root.ink
                        selectionColor: root.royal
                        font.family: root.uiFont
                        font.pixelSize: root.u
                        clip: true
                        focus: true
                        Keys.onReturnPressed: root.signIn()
                        Keys.onEnterPressed: root.signIn()
                        Keys.onEscapePressed: userList.visible = false

                        Text {
                            anchors.verticalCenter: parent.verticalCenter
                            visible: password.text.length === 0
                            text: root.pinLength > 0 ? "PIN" : "Password"
                            color: Qt.rgba(232 / 255, 236 / 255, 250 / 255, 0.5)
                            font: password.font
                        }
                    }
                    Eye {
                        id: mainEye
                        anchors.right: go.left
                        anchors.rightMargin: 0.7 * root.u
                        anchors.verticalCenter: parent.verticalCenter
                    }
                    Rectangle {
                        id: go
                        // a PIN signs in by itself: no arrow then
                        visible: !root.pinMode
                        width: visible ? 2.2 * root.u : 0
                        height: width
                        radius: width / 2
                        anchors.right: parent.right
                        anchors.rightMargin: 0.35 * root.u
                        anchors.verticalCenter: parent.verticalCenter
                        color: goArea.containsMouse ? root.royalLight : root.royal
                        Image {
                            anchors.centerIn: parent
                            source: "icons/arrow.svg"
                            sourceSize.width: root.u
                            sourceSize.height: root.u
                        }
                        MouseArea {
                            id: goArea
                            anchors.fill: parent
                            hoverEnabled: true
                            cursorShape: Qt.PointingHandCursor
                            onClicked: root.signIn()
                        }
                    }

                    SequentialAnimation {
                        id: shake
                        NumberAnimation { target: shakeOffset; property: "x"; to: -0.6 * root.u; duration: 60 }
                        NumberAnimation { target: shakeOffset; property: "x"; to: 0.6 * root.u; duration: 80 }
                        NumberAnimation { target: shakeOffset; property: "x"; to: -0.6 * root.u; duration: 80 }
                        NumberAnimation { target: shakeOffset; property: "x"; to: 0.6 * root.u; duration: 80 }
                        NumberAnimation { target: shakeOffset; property: "x"; to: 0; duration: 60 }
                    }
                }

                Text {
                    id: message
                    visible: !forgot.visible
                    width: parent.width
                    height: 1.4 * root.u
                    horizontalAlignment: Text.AlignHCenter
                    color: root.errorColor
                    font.family: root.uiFont
                    font.pixelSize: 0.9 * root.u
                }

                // Forgot your PIN? The ways this account has (Forgot.qml): an authenticator
                // app's code, a link to the connected account's e-mail, or the recovery key.
                Text {
                    anchors.horizontalCenter: parent.horizontalCenter
                    visible: !forgot.visible
                    text: root.pinLength > 0 ? "Forgot your PIN?" : "Forgot your password?"
                    color: forgotArea.containsMouse ? root.ink : root.muted
                    font.family: root.uiFont
                    font.pixelSize: 0.85 * root.u
                    font.underline: forgotArea.containsMouse
                    MouseArea {
                        id: forgotArea
                        anchors.fill: parent
                        anchors.margins: -0.4 * root.u
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        onClicked: { message.text = ""; forgot.open() }
                    }
                }
                Forgot {
                    id: forgot
                    width: parent.width
                    userName: root.userName
                    email: root.accountEmail
                    hasTotp: root.hasTotp
                    hasEmail: root.accountProvider !== ""
                    hasKey: root.hasKey
                    request: function (method, path, body, done) {
                        const x = new XMLHttpRequest()
                        x.open(method, "http://127.0.0.1:6745" + path)
                        x.setRequestHeader("Content-Type", "application/json")
                        x.onreadystatechange = function () {
                            if (x.readyState !== XMLHttpRequest.DONE) return
                            let d = {}
                            try { d = JSON.parse(x.responseText) } catch (e) {}
                            if (x.status === 0) d = { ok: false, error: "The Infinity Account service isn't answering." }
                            done(d)
                        }
                        x.send(body === null ? "" : JSON.stringify(body))
                    }
                    onFinished: { root.loadAccount(); message.color = "#5ED6A0"; message.text = "Your new PIN is saved. Type it above." }
                    onVisibleChanged: if (!visible) password.forceActiveFocus()
                }
            }
        }

        // ---------- Switch user (bottom left) ----------
        Column {
            anchors.left: parent.left
            anchors.leftMargin: root.width * 0.04
            anchors.bottom: parent.bottom
            anchors.bottomMargin: root.height * 0.05
            spacing: 0.6 * root.u

            Rectangle {
                id: userList
                visible: false
                width: 13 * root.u
                height: listColumn.implicitHeight + 1.6 * root.u
                radius: root.u
                color: root.glass
                border.color: root.line
                border.width: 1
                transform: Translate { id: listOffset }

                onVisibleChanged: if (visible) pop.restart()
                ParallelAnimation {
                    id: pop
                    NumberAnimation { target: userList; property: "opacity"; from: 0; to: 1; duration: 220; easing.type: Easing.OutQuad }
                    NumberAnimation { target: listOffset; property: "y"; from: 0.6 * root.u; to: 0; duration: 220; easing.type: Easing.OutQuad }
                }

                Column {
                    id: listColumn
                    x: 0.8 * root.u
                    y: 0.8 * root.u
                    width: parent.width - 1.6 * root.u
                    spacing: 0.2 * root.u

                    Text {
                        leftPadding: 0.4 * root.u
                        bottomPadding: 0.5 * root.u
                        text: "SWITCH USER"
                        color: root.muted
                        font.family: root.uiFont
                        font.weight: Font.Medium
                        font.pixelSize: 0.75 * root.u
                        font.letterSpacing: 0.06 * root.u
                    }
                    Repeater {
                        model: userModel
                        delegate: Rectangle {
                            id: entry
                            readonly property string label: model.realName || model.name
                            width: listColumn.width
                            height: 2.6 * root.u
                            radius: 0.7 * root.u
                            color: (rowArea.containsMouse || model.name === root.userName)
                                   ? Qt.rgba(125 / 255, 151 / 255, 1, 0.16) : "transparent"

                            // Show the real name of the preselected account.
                            Component.onCompleted: {
                                if (root.userName === "" && index === 0)
                                    root.userName = model.name
                                if (model.name === root.userName)
                                    root.userLabel = entry.label
                            }

                            Row {
                                x: 0.45 * root.u
                                anchors.verticalCenter: parent.verticalCenter
                                spacing: 0.7 * root.u
                                Avatar {
                                    size: 1.9 * root.u
                                    letter: entry.label
                                    fontFamily: wordFont.name
                                    anchors.verticalCenter: parent.verticalCenter
                                }
                                Text {
                                    anchors.verticalCenter: parent.verticalCenter
                                    text: entry.label
                                    color: root.ink
                                    font.family: root.uiFont
                                    font.pixelSize: 0.95 * root.u
                                }
                            }
                            MouseArea {
                                id: rowArea
                                anchors.fill: parent
                                hoverEnabled: true
                                cursorShape: Qt.PointingHandCursor
                                onClicked: {
                                    root.userName = model.name
                                    root.userLabel = entry.label
                                    userList.visible = false
                                    message.text = ""
                                    password.text = ""
                                    password.forceActiveFocus()
                                }
                            }
                        }
                    }
                }
            }

            Rectangle {
                width: switchRow.implicitWidth + 1.45 * root.u
                height: 2.9 * root.u
                radius: height / 2
                color: root.glass
                border.color: root.line
                border.width: 1
                visible: userModel.count > 1

                Row {
                    id: switchRow
                    x: 0.45 * root.u
                    anchors.verticalCenter: parent.verticalCenter
                    spacing: 0.6 * root.u
                    Rectangle {
                        width: 2 * root.u
                        height: width
                        radius: width / 2
                        color: Qt.rgba(1, 1, 1, 0.08)
                        Image {
                            anchors.centerIn: parent
                            source: "icons/users.svg"
                            sourceSize.width: 1.1 * root.u
                            sourceSize.height: 1.1 * root.u
                        }
                    }
                    Text {
                        anchors.verticalCenter: parent.verticalCenter
                        text: "Switch user"
                        color: root.inkSoft
                        font.family: root.uiFont
                        font.pixelSize: 0.85 * root.u
                    }
                }
                MouseArea {
                    anchors.fill: parent
                    cursorShape: Qt.PointingHandCursor
                    onClicked: userList.visible = !userList.visible
                }
            }

            // Keyboard language (only with several), as on the lock screen; a
            // click switches to the next one. SDDM's own keyboard model knows
            // nothing on Wayland; the login screen's KWin answers on its bus.
            Rectangle {
                visible: layouts.hasMultipleKeyboardLayouts
                width: layoutRow.implicitWidth + 1.4 * root.u
                height: 2.4 * root.u
                radius: height / 2
                color: root.glass
                border.color: root.line
                border.width: 1
                Row {
                    id: layoutRow
                    anchors.centerIn: parent
                    spacing: 0.5 * root.u
                    Image {
                        anchors.verticalCenter: parent.verticalCenter
                        source: "icons/keyboard.svg"
                        sourceSize.width: root.u
                        sourceSize.height: root.u
                    }
                    Text {
                        anchors.verticalCenter: parent.verticalCenter
                        text: layouts.layoutNames.shortName.toUpperCase()
                        color: root.inkSoft
                        font.family: root.uiFont
                        font.pixelSize: 0.85 * root.u
                    }
                }
                PW.KeyboardLayoutSwitcher {
                    id: layouts
                    anchors.fill: parent
                    onClicked: password.forceActiveFocus()
                }
            }
        }

        // ---------- Sleep / Restart / Shut down (bottom right) ----------
        Row {
            anchors.right: parent.right
            anchors.rightMargin: root.width * 0.04
            anchors.bottom: parent.bottom
            anchors.bottomMargin: root.height * 0.05
            spacing: root.u

            PowerButton { u: root.u; fontFamily: root.uiFont; icon: "icons/sleep.svg"; label: "Sleep"; visible: sddm.canSuspend; onActivated: sddm.suspend() }
            PowerButton { u: root.u; fontFamily: root.uiFont; icon: "icons/restart.svg"; label: "Restart"; visible: sddm.canReboot; onActivated: sddm.reboot() }
            PowerButton { u: root.u; fontFamily: root.uiFont; icon: "icons/off.svg"; label: "Shut down"; visible: sddm.canPowerOff; onActivated: sddm.powerOff() }
        }
    }

    Component.onCompleted: { loadAccount(); password.forceActiveFocus() }
}
