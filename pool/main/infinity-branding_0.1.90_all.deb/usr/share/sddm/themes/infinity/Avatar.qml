// A round account picture: the account's photo when there is one (the Infinity
// Account keeps the connected account's picture on the computer), else the first
// letter of the name on royal blue.
import QtQuick
import org.kde.kirigami as Kirigami

Rectangle {
    id: avatar
    property real size: 48
    property string letter: ""
    property string fontFamily: ""
    property string source: ""
    width: size
    height: size
    radius: size / 2
    gradient: Gradient {
        GradientStop { position: 0; color: "#7D97FF" }
        GradientStop { position: 1; color: "#2B4FD8" }
    }
    border.color: Qt.rgba(1, 1, 1, 0.14)
    border.width: Math.max(1, size * 0.03)
    Text {
        anchors.centerIn: parent
        visible: photo.status !== Image.Ready
        text: letter.length ? letter.charAt(0).toUpperCase() : ""
        color: "white"
        font.family: fontFamily
        font.weight: Font.Medium
        font.pixelSize: size * 0.4
    }
    Kirigami.ShadowedImage {
        id: photo
        anchors.fill: parent
        visible: avatar.source !== "" && status === Image.Ready
        source: avatar.source
        sourceSize.width: avatar.size * 2
        sourceSize.height: avatar.size * 2
        radius: width / 2
        fillMode: Image.PreserveAspectCrop
        asynchronous: true
    }
}
