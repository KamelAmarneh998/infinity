// "Forgot your PIN?" on the sign-in screen (Main.qml) and the lock screen
// (lockscreen/LockScreen.qml): the ways this account has, one at a time:
//   Authenticator app  a code from Microsoft/Google Authenticator (set up in Settings; works offline)
//   By e-mail          a link to the connected account's e-mail ("Yes, it's me")
//   Recovery key       the key kept at setup (used up; the agent saves a new one)
// then a new PIN. Everything goes to the Infinity Account service's local port
// (127.0.0.1:6745) through `request`: the sign-in screen calls it directly, the
// lock screen (no network allowed) through the session bus helper.
import QtQuick

Column {
    id: forgot
    visible: false
    spacing: 0.6 * root.u

    property string userName
    property string email           // k•••l@gmail.com
    property bool hasTotp: false
    property bool hasEmail: false
    property bool hasKey: false
    // request(method, path, body or null, function (reply) {...}); reply.ok false: reply.error
    property var request

    signal finished()                // new PIN saved

    property string step: ""         // choose | totp | email | key | pin
    property string via: ""          // totp | email | key
    property string note: ""

    function open() {
        visible = true
        note = ""
        const ways = (hasTotp ? 1 : 0) + (hasEmail ? 1 : 0) + (hasKey ? 1 : 0)
        if (ways === 1)
            hasTotp ? pick("totp") : hasEmail ? pick("email") : pick("key")
        else
            step = "choose"
    }
    function pick(way) {
        note = ""
        step = way
        if (way === "totp") code.forceActiveFocus()
        if (way === "key") keyBox.forceActiveFocus()
        if (way === "email") sendMail()
    }
    function back() {
        if (step !== "choose" && step !== "pin" && (hasTotp + hasEmail + hasKey) > 1) {
            mailPoll.stop(); note = ""; step = "choose"
        } else close()
    }
    function close() {
        visible = false; step = ""; note = ""; mailPoll.stop()
        code.text = ""; keyBox.text = ""; newPin.text = ""; newPin2.text = ""
    }
    function checkCode() {
        if (code.text.length !== 6) return
        note = "Checking…"
        request("POST", "/totp-check", { user: userName, code: code.text }, function (d) {
            code.text = ""
            if (d.ok) { note = ""; via = "totp"; step = "pin"; newPin.forceActiveFocus() }
            else note = d.error || "That didn't work. Try again."
        })
    }
    property bool checkingKey: false
    function checkKey() {
        if (checkingKey) return
        if (keyBox.text.replace(/[-\s]/g, "").length !== 24) { note = "A recovery key has 24 letters and digits."; return }
        checkingKey = true
        note = "Checking…"
        request("POST", "/key-check", { user: userName, key: keyBox.text }, function (d) {
            checkingKey = false
            if (d.ok) { keyBox.text = ""; note = ""; via = "key"; step = "pin"; newPin.forceActiveFocus() }
            else note = d.error || "That didn't work. Try again."
        })
    }
    function sendMail() {
        note = "Sending…"
        request("POST", "/reset-email", { user: userName }, function (d) {
            if (d.ok) { note = ""; mailPoll.start() }
            else note = d.error || "No internet here. Connect a cable, or use another way."
        })
    }
    Timer {
        id: mailPoll
        interval: 3000
        repeat: true
        onTriggered: forgot.request("GET", "/reset-email?user=" + encodeURIComponent(forgot.userName), null, function (d) {
            if (d.confirmed) { mailPoll.stop(); forgot.via = "email"; forgot.step = "pin"; newPin.forceActiveFocus() }
        })
    }
    function save() {
        if (newPin.text.length < 4) { note = "A PIN is 4 to 16 digits."; return }
        if (newPin.text !== newPin2.text) { note = "The two PINs are not the same."; return }
        note = "Saving…"
        request("POST", "/reset", { user: userName, provider: via, pin: newPin.text }, function (d) {
            if (d.ok) { close(); finished() }
            else note = d.error || "That didn't work. Try again."
        })
    }

    component Small: Text {
        width: forgot.width
        wrapMode: Text.Wrap
        horizontalAlignment: Text.AlignHCenter
        color: root.inkSoft
        font.family: root.uiFont
        font.pixelSize: 0.85 * root.u
    }
    component Way: Rectangle {
        property string title
        property string detail
        signal picked()
        width: forgot.width
        height: wayText.implicitHeight + 1.2 * root.u
        radius: 0.8 * root.u
        color: wayArea.containsMouse ? Qt.rgba(1, 1, 1, 0.1) : Qt.rgba(1, 1, 1, 0.05)
        border.color: wayArea.containsMouse ? root.royalLight : Qt.rgba(1, 1, 1, 0.12)
        Column {
            id: wayText
            anchors.left: parent.left; anchors.leftMargin: 1.1 * root.u
            anchors.right: parent.right; anchors.rightMargin: 1.1 * root.u
            anchors.verticalCenter: parent.verticalCenter
            spacing: 0.1 * root.u
            Text { text: title; color: root.ink; font.family: root.uiFont; font.pixelSize: 0.9 * root.u; font.weight: Font.Medium }
            Text { width: parent.width; text: detail; color: root.muted; font.family: root.uiFont; font.pixelSize: 0.75 * root.u; elide: Text.ElideRight }
        }
        MouseArea { id: wayArea; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: parent.picked() }
    }
    component DigitBox: Item {
        property alias text: box.text
        property alias hint: hintText.text
        property int digits: 16
        property bool secret: true
        property bool onlyDigits: true
        signal accepted()
        width: forgot.width
        height: 2.5 * root.u
        function forceActiveFocus() { box.forceActiveFocus() }
        Rectangle { anchors.fill: parent; radius: height / 2; color: Qt.rgba(1, 1, 1, 0.08); border.color: box.activeFocus ? root.royalLight : Qt.rgba(1, 1, 1, 0.16) }
        TextInput {
            id: box
            anchors.left: parent.left; anchors.leftMargin: 1.2 * root.u
            anchors.right: boxEye.left; anchors.rightMargin: 0.5 * root.u
            anchors.verticalCenter: parent.verticalCenter
            echoMode: secret && !boxEye.shown ? TextInput.Password : TextInput.Normal
            passwordCharacter: "•"
            maximumLength: digits
            validator: RegularExpressionValidator { regularExpression: onlyDigits ? /[0-9]*/ : /.*/ }
            inputMethodHints: onlyDigits ? Qt.ImhDigitsOnly : Qt.ImhPreferUppercase
            color: root.ink; font.family: root.uiFont; font.pixelSize: root.u; clip: true
            Keys.onReturnPressed: parent.accepted()
            Keys.onEnterPressed: parent.accepted()
            Keys.onEscapePressed: forgot.close()
            Text { id: hintText; anchors.verticalCenter: parent.verticalCenter; visible: box.text.length === 0; color: Qt.rgba(232 / 255, 236 / 255, 250 / 255, 0.5); font: box.font }
        }
        Eye { id: boxEye; visible: secret; anchors.right: parent.right; anchors.rightMargin: 0.8 * root.u; anchors.verticalCenter: parent.verticalCenter }
    }

    // ---------- the ways ----------
    Small { visible: forgot.step === "choose"; text: "How do you want to prove it's you?" }
    Way { visible: forgot.step === "choose" && forgot.hasTotp; title: "Authenticator app"; detail: "A code from the app on your phone"; onPicked: forgot.pick("totp") }
    Way { visible: forgot.step === "choose" && forgot.hasEmail; title: "By e-mail"; detail: "A link to " + forgot.email; onPicked: forgot.pick("email") }
    Way { visible: forgot.step === "choose" && forgot.hasKey; title: "Recovery key"; detail: "The key you kept somewhere safe"; onPicked: forgot.pick("key") }
    Small {
        visible: forgot.step === "choose" && !forgot.hasTotp && !forgot.hasEmail && !forgot.hasKey
        text: "This account has no way to get back in by itself. Someone who manages this computer can set a new PIN in Settings > Users."
    }

    // authenticator app
    Small { visible: forgot.step === "totp"; text: "Open your authenticator app and type the 6 digits it shows for Infinity:" }
    DigitBox { id: code; visible: forgot.step === "totp"; digits: 6; secret: false; hint: "6-digit code"; onTextChanged: if (text.length === 6) forgot.checkCode() }

    // e-mail
    Small {
        visible: forgot.step === "email" && forgot.note === ""
        text: "We sent a link to " + forgot.email + ". Open it on any device and tap “Yes, it's me”. This screen moves on by itself."
    }

    // recovery key
    Small { visible: forgot.step === "key"; text: "Type or paste your recovery key (24 letters and digits):" }
    DigitBox { id: keyBox; visible: forgot.step === "key"; digits: 40; secret: false; onlyDigits: false; hint: "XXXX-XXXX-XXXX-XXXX-XXXX-XXXX"
               // always 24: checked as soon as it's all there (typed or pasted)
               onAccepted: forgot.checkKey(); onTextChanged: if (text.replace(/[-\s]/g, "").length === 24) forgot.checkKey() }
    Small { visible: forgot.step === "key"; color: root.muted; text: "It works once: afterwards you get a new one, saved in Documents." }

    // the new PIN
    Small { visible: forgot.step === "pin"; text: "It's you. Choose a new PIN:" }
    DigitBox { id: newPin; visible: forgot.step === "pin"; hint: "New PIN (4 to 16 digits)"; onAccepted: newPin2.forceActiveFocus() }
    DigitBox { id: newPin2; visible: forgot.step === "pin"; hint: "The PIN again"; onAccepted: forgot.save() }
    Rectangle {
        visible: forgot.step === "pin"
        anchors.horizontalCenter: parent.horizontalCenter
        width: saveText.implicitWidth + 2.4 * root.u
        height: 2.3 * root.u
        radius: height / 2
        color: saveArea.containsMouse ? root.royalLight : root.royal
        Text { id: saveText; anchors.centerIn: parent; text: "Save the PIN"; color: "white"; font.family: root.uiFont; font.pixelSize: 0.9 * root.u }
        MouseArea { id: saveArea; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: forgot.save() }
    }
    Small { visible: forgot.note !== ""; color: root.muted; text: forgot.note }
}
