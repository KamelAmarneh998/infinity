// The eye in a password or PIN box: shows what was typed, again hides it.
import QtQuick

Item {
    id: eye
    property bool shown: false
    width: icon.width
    height: icon.height
    implicitWidth: icon.width
    implicitHeight: icon.height
    Image {
        id: icon
        source: eye.shown ? "icons/eye-off.svg" : "icons/eye.svg"
        width: Math.round(1.25 * (root.u || 16)); height: width
        sourceSize.width: width * 2; sourceSize.height: height * 2
        opacity: area.containsMouse ? 1 : 0.6
    }
    MouseArea {
        id: area
        anchors.fill: parent
        anchors.margins: -0.4 * (root.u || 16)
        hoverEnabled: true
        cursorShape: Qt.PointingHandCursor
        onClicked: eye.shown = !eye.shown
    }
}
