// Infinity desktop splash, shown by ksplashqml between the login screen
// and the desktop. The logo already showed while the system booted, so this
// is only the desktop's own wallpaper (no logo) while the desktop assembles
// on top of it; when Plasma is ready ksplashqml closes it and the desktop,
// with the same wallpaper, takes its place. Black until the picture is read
// (on a slow disk that can take a moment).
import QtQuick

Rectangle {
    id: root
    color: "black"

    // Set by ksplashqml as Plasma starts up.
    property int stage

    Image {
        anchors.fill: parent
        source: "file:///usr/share/wallpapers/Infinity/contents/images/"
                + (root.width > 2560 ? "3840x2160" : root.width > 1920 ? "2560x1440" : "1920x1080") + ".png"
        fillMode: Image.PreserveAspectCrop
        asynchronous: true
        opacity: status === Image.Ready ? 1 : 0
        Behavior on opacity { NumberAnimation { duration: 300 } }
    }
}
