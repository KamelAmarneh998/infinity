// A big round button with a label under it (Sleep, Restart, Shut down, Log out).
// The default one is filled royal blue.
import QtQuick

Column {
    id: button
    property string icon
    property string label
    property bool isDefault: false
    property real u: 16
    property string fontFamily: ""
    signal activated()
    spacing: 0.7 * u
    activeFocusOnTab: true
    Keys.onReturnPressed: activated()
    Keys.onEnterPressed: activated()
    Keys.onSpacePressed: activated()

    readonly property bool lit: isDefault || area.containsMouse || activeFocus

    Rectangle {
        anchors.horizontalCenter: parent.horizontalCenter
        width: 5.4 * button.u
        height: width
        radius: width / 2
        color: button.lit ? "#4169E1" : Qt.rgba(1, 1, 1, 0.08)
        border.color: button.lit ? "#4169E1" : Qt.rgba(1, 1, 1, 0.16)
        border.width: 1
        scale: area.containsMouse ? 1.05 : 1
        Behavior on scale { NumberAnimation { duration: 150 } }
        Behavior on color { ColorAnimation { duration: 150 } }

        // The focused button that is not the default gets a ring.
        Rectangle {
            anchors.fill: parent
            anchors.margins: -0.3 * button.u
            radius: width / 2
            color: "transparent"
            border.color: "#7D97FF"
            border.width: 2
            visible: button.activeFocus && !button.isDefault
        }
        Image {
            anchors.centerIn: parent
            source: button.icon
            sourceSize.width: 2 * button.u
            sourceSize.height: 2 * button.u
        }
        MouseArea {
            id: area
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: button.activated()
        }
    }
    Text {
        anchors.horizontalCenter: parent.horizontalCenter
        text: button.label
        color: "#E8ECFA"
        font.family: button.fontFamily
        font.pixelSize: button.u
    }
}
