// Infinity shut-down screen, as designed in distro/branding/system-preview.html:
// the desktop dims behind four big buttons (Sleep, Restart, Shut down, Log out).
// The button for what was asked (Shut down, Restart or Log out) is the default
// and runs by itself after 30 seconds. Esc, Cancel or a click outside goes back.
// No logo here: the ∞ belongs to the boot screen.
//
// ksmserver-logout-greeter shows this on every screen and provides sdtype,
// maysd, canLogout, spdMethods, softwareUpdatePending and screenGeometry.
// The buttons are on the main screen only, the others just dim. Qt on Wayland
// doesn't know which screen is the main one: infinity-main-screen (user unit)
// writes its place to $XDG_RUNTIME_DIR/infinity-screens.ini. Without that
// file, the top-left screen (where KDE puts the main one) gets them.
import QtQuick
import QtQuick.Controls as QQC2
import QtCore
import org.kde.plasma.private.sessions
import "timer.js" as AutoTriggerTimer

Item {
    id: root
    height: screenGeometry.height
    width: screenGeometry.width

    signal logoutRequested()
    signal haltRequested()
    signal haltUpdateRequested()
    signal suspendRequested(int spdMethod)
    signal rebootRequested()
    signal rebootRequested2(int opt)
    signal rebootUpdateRequested()
    signal cancelRequested()
    signal lockScreenRequested()
    signal cancelSoftwareUpdateRequested()

    readonly property string assets: "file:///usr/share/sddm/themes/infinity/"
    readonly property real u: Math.max(10, width * 0.0125)
    Settings {
        id: mainScreen
        location: StandardPaths.writableLocation(StandardPaths.RuntimeLocation) + "/infinity-screens.ini"
        category: "main"
        property int x: -100000
        property int y: -100000
    }
    readonly property bool primary: {
        if (Qt.application.screens.length < 2)
            return true
        if (mainScreen.x !== -100000)
            return mainScreen.x === screenGeometry.x && mainScreen.y === screenGeometry.y
        let main = null
        for (const s of Qt.application.screens)
            if (!main || s.virtualX < main.virtualX || (s.virtualX === main.virtualX && s.virtualY < main.virtualY))
                main = s
        return !main || (main.virtualX === screenGeometry.x && main.virtualY === screenGeometry.y)
    }

    // What was asked for; "Leave..." (the default type) means shut down.
    readonly property string action: {
        switch (sdtype) {
        case ShutdownType.ShutdownTypeReboot: return "restart"
        case ShutdownType.ShutdownTypeNone: return "logout"
        default: return maysd ? "halt" : "logout"
        }
    }

    function run(what) {
        AutoTriggerTimer.cancelAutoTrigger()
        switch (what) {
        case "sleep": root.suspendRequested(2); break
        case "restart": softwareUpdatePending ? root.rebootUpdateRequested() : root.rebootRequested(); break
        case "halt": softwareUpdatePending ? root.haltUpdateRequested() : root.haltRequested(); break
        default: root.logoutRequested()
        }
    }

    property int remainingTime: 30
    onRemainingTimeChanged: if (remainingTime <= 0) run(action)

    Timer {
        id: countDown
        running: true
        repeat: true
        interval: 1000
        onTriggered: root.remainingTime--
        Component.onCompleted: AutoTriggerTimer.addCancelAutoTriggerCallback(() => countDown.running = false)
    }

    QQC2.Action {
        onTriggered: root.cancelRequested()
        shortcut: "Escape"
    }

    // Other people still signed in would lose their work.
    SessionsModel {
        id: otherSessions
        includeUnusedSessions: false
        includeOwnSession: false
    }

    FontLoader { id: wordFont; source: root.assets + "Montserrat-Light.ttf" }

    Rectangle {
        anchors.fill: parent
        color: Qt.rgba(5 / 255, 7 / 255, 15 / 255, 0.82)
        NumberAnimation on opacity { from: 0; to: 1; duration: 250; easing.type: Easing.OutQuad }
    }
    MouseArea {
        anchors.fill: parent
        onClicked: root.cancelRequested()
    }

    Column {
        anchors.centerIn: parent
        spacing: 2.2 * root.u
        visible: root.primary

        NumberAnimation on opacity { from: 0; to: 1; duration: 300; easing.type: Easing.OutQuad }

        Text {
            anchors.horizontalCenter: parent.horizontalCenter
            text: root.action === "restart" ? "Restart this computer?"
                : root.action === "logout" ? "Log out?"
                : "Shut down this computer?"
            color: "#E8ECFA"
            font.family: wordFont.name
            font.weight: Font.Light
            font.pixelSize: 1.5 * root.u
        }

        Row {
            id: buttons
            anchors.horizontalCenter: parent.horizontalCenter
            spacing: 2.4 * root.u

            BigButton {
                id: sleepButton
                u: root.u; fontFamily: "Noto Sans"
                icon: root.assets + "icons/sleep.svg"; label: "Sleep"
                visible: spdMethods.SuspendState
                onActivated: root.run("sleep")
                KeyNavigation.right: restartButton
            }
            BigButton {
                id: restartButton
                u: root.u; fontFamily: "Noto Sans"
                icon: root.assets + "icons/restart.svg"
                label: softwareUpdatePending ? "Update and restart" : "Restart"
                visible: maysd
                isDefault: root.action === "restart"
                onActivated: root.run("restart")
                KeyNavigation.left: sleepButton
                KeyNavigation.right: haltButton
            }
            BigButton {
                id: haltButton
                u: root.u; fontFamily: "Noto Sans"
                icon: root.assets + "icons/off.svg"
                label: softwareUpdatePending ? "Update and shut down" : "Shut down"
                visible: maysd
                isDefault: root.action === "halt"
                onActivated: root.run("halt")
                KeyNavigation.left: restartButton
                KeyNavigation.right: logoutButton
            }
            BigButton {
                id: logoutButton
                u: root.u; fontFamily: "Noto Sans"
                icon: root.assets + "icons/logout.svg"; label: "Log out"
                visible: canLogout
                isDefault: root.action === "logout"
                onActivated: root.run("logout")
                KeyNavigation.left: haltButton
            }
        }

        Text {
            anchors.horizontalCenter: parent.horizontalCenter
            opacity: countDown.running ? 1 : 0
            Behavior on opacity { NumberAnimation { duration: 200 } }
            textFormat: Text.StyledText
            text: (root.action === "restart" ? "Restarting" : root.action === "logout" ? "Logging out" : "Shutting down")
                  + " in <b>" + root.remainingTime + "</b> " + (root.remainingTime === 1 ? "second" : "seconds")
            color: "#8A93B8"
            font.family: "Noto Sans"
            font.pixelSize: 0.95 * root.u
        }

        Text {
            anchors.horizontalCenter: parent.horizontalCenter
            visible: otherSessions.count > 0 && root.action !== "logout"
            text: otherSessions.count === 1
                  ? "Someone else is still signed in and may lose their work."
                  : otherSessions.count + " other people are still signed in and may lose their work."
            color: "#FFB86B"
            font.family: "Noto Sans"
            font.pixelSize: 0.9 * root.u
        }

        Rectangle {
            anchors.horizontalCenter: parent.horizontalCenter
            width: cancelText.implicitWidth + 2.8 * root.u
            height: 2.2 * root.u
            radius: height / 2
            color: cancelArea.containsMouse ? Qt.rgba(1, 1, 1, 0.08) : "transparent"
            border.color: Qt.rgba(125 / 255, 151 / 255, 1, 0.3)
            border.width: 1
            Text {
                id: cancelText
                anchors.centerIn: parent
                text: "Cancel"
                color: "#E8ECFA"
                font.family: "Noto Sans"
                font.pixelSize: 0.9 * root.u
            }
            MouseArea {
                id: cancelArea
                anchors.fill: parent
                hoverEnabled: true
                cursorShape: Qt.PointingHandCursor
                onClicked: root.cancelRequested()
            }
        }
    }

    // Any key stops the countdown (on every screen); Enter runs the default.
    Keys.onPressed: event => AutoTriggerTimer.cancelAutoTrigger()
    Component.onCompleted: {
        const byAction = { restart: restartButton, halt: haltButton, logout: logoutButton }
        byAction[action].forceActiveFocus()
    }
}
