// Infinity: the top bar's battery menu is Infinity's (org.infinity.battery: a time
// left that holds still, from the battery agent) instead of Plasma's. Plasma's stays
// in knownItems, so the tray doesn't add it back. (From the next login: a running
// Plasma loads a new tray widget only when it starts.)
panels().forEach(function (panel) {
    panel.widgets("org.kde.plasma.systemtray").forEach(function (tray) {
        tray.currentConfigGroup = ["General"]
        var list = function (key) {
            var v = tray.readConfig(key, [])
            return typeof v === "string" ? (v ? v.split(",") : []) : Array.prototype.slice.call(v)
        }
        var extra = list("extraItems").filter(function (id) { return id !== "org.kde.plasma.battery" })
        if (extra.indexOf("org.infinity.battery") < 0)
            extra.push("org.infinity.battery")
        tray.writeConfig("extraItems", extra)
        var known = list("knownItems")
        ;["org.kde.plasma.battery", "org.infinity.battery"].forEach(function (id) {
            if (known.indexOf(id) < 0)
                known.push(id)
        })
        tray.writeConfig("knownItems", known)
    })
})
