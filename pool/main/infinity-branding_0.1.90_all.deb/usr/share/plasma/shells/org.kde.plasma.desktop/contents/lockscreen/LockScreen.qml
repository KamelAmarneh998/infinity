// Infinity lock screen, as designed in distro/branding/system-preview.html:
// the login screen's card again (clock, date, the user, the password field),
// so locking and signing in look like one screen, with the same Sleep /
// Restart / Shut down buttons at the bottom right (no user switching); music
// that is playing shows below the card.
//
// kscreenlocker loads this file from the Plasma shell package; the stock one
// is diverted to LockScreen.qml.infinity-stock by infinity-branding's preinst.
// Shared pieces (fonts, icons, Avatar, InfinityMark) come from the login theme.
import QtQuick
import org.kde.coreaddons as KCoreAddons
import org.kde.plasma.private.keyboardindicator as KeyboardIndicator
import org.kde.plasma.private.mpris as Mpris
import org.kde.plasma.private.sessions
import org.kde.plasma.workspace.components as PW
import org.kde.plasma.workspace.dbus as DBus
import "file:///usr/share/sddm/themes/infinity" as Ui

Item {
    id: root
    property bool debug: false
    property string notification
    signal clearPassword()
    signal notificationRepeated()

    // These are magical properties that kscreenlocker looks for
    property bool viewVisible: false
    property bool suspendToRamSupported: false
    property bool suspendToDiskSupported: false

    // These are magical signals that kscreenlocker looks for
    signal suspendToDisk()
    signal suspendToRam()

    implicitWidth: 800
    implicitHeight: 600

    readonly property string assets: "file:///usr/share/sddm/themes/infinity/"
    // One unit = 1.25% of the screen width, as on the login screen.
    readonly property real u: Math.max(10, width * 0.0125)

    readonly property color ink: "#E8ECFA"
    readonly property color inkSoft: Qt.rgba(232 / 255, 236 / 255, 250 / 255, 0.78)
    readonly property color muted: "#8A93B8"
    readonly property color royal: "#4169E1"
    readonly property color royalLight: "#7D97FF"
    readonly property color glass: Qt.rgba(14 / 255, 20 / 255, 44 / 255, 0.62)
    readonly property color line: Qt.rgba(125 / 255, 151 / 255, 1, 0.22)
    readonly property color errorColor: "#FF6B7A"
    readonly property string uiFont: "Noto Sans"

    // An account without a password unlocks with the button alone.
    property bool noPassword: false

    // kscreenlocker only accepts a password while a check is running, and a
    // check can end on its own (e.g. after the screen went to sleep). Like
    // KDE's own lock screen, start one whenever the user shows up: a key
    // press or a mouse move. Starting while one runs does nothing.
    property double lastWake: 0
    function wake() {
        const now = Date.now()
        if (graceTimer.running || now - lastWake < 1000) // mouse moves come in floods
            return
        lastWake = now
        authenticator.startAuthenticating()
    }

    // A PIN (its length from the Infinity Account service) unlocks as soon as it's
    // complete, without Enter. The box empties at once and can be typed in again
    // while PAM still answers: a PIN finished meanwhile goes next ("queued").
    property int pinLength: 0
    // the login name: kscreenlocker_userName is the full name when the account has one
    // (connecting an Infinity Account sets it), and the account's files go by login name
    readonly property string login: kuser.loginName
    property bool hasTotp: false
    property bool hasKey: false
    property string accountProvider: ""
    property string accountEmail: ""
    property string accountName: ""      // the connected account's name and picture
    property string accountPicture: ""
    readonly property bool pinMode: pinLength > 0
    property bool checking: false
    property string queued: ""
    function loadAccount() {
        const x = new XMLHttpRequest()
        // a file: the lock screen has no network (60-infinity-lockscreen.conf allows the read)
        x.open("GET", "file:///var/lib/infinity/account-public/" + root.login + ".json")
        x.onreadystatechange = function () {
            if (x.readyState !== XMLHttpRequest.DONE) return
            let d = {}
            try { d = JSON.parse(x.responseText) } catch (e) {}
            root.pinLength = d.pin || 0
            root.hasTotp = d.totp === true
            root.hasKey = d.key === true
            root.accountProvider = d.provider || ""
            root.accountEmail = d.email || ""
            root.accountName = d.name || ""
            root.accountPicture = d.picture || ""
        }
        x.send()
    }

    // A PIN is checked by the Infinity Account service first (/pin-check through the session
    // bus helper: answers at once, limits the tries); a wrong one never reaches PAM (2-second
    // pause, a new PAM round each time: slow, and the box lost its focus). Only a right one does.
    // After too many wrong PINs the box is closed while the wait counts down.
    property int waitLeft: 0
    function showWait() {
        message.color = root.errorColor
        message.text = "Too many tries. Try again in " + (waitLeft >= 60 ? Math.ceil(waitLeft / 60) + " min" : waitLeft + " s") + "."
    }
    Timer {
        id: waitTimer
        interval: 1000
        repeat: true
        onTriggered: {
            root.waitLeft = Math.max(0, root.waitLeft - 1)
            if (root.waitLeft > 0) {
                root.showWait()
            } else {
                stop()
                message.text = ""
                password.forceActiveFocus()
            }
        }
    }
    function wrongPin(wait) {
        shake.restart()
        if (wait > 0) {
            waitLeft = wait
            showWait()
            waitTimer.restart()
            return
        }
        message.color = root.errorColor
        message.text = "Wrong PIN. Try again."
        password.forceActiveFocus()
    }
    function checkPin(secret) {
        checking = true
        forgot.request("POST", "/pin-check", { user: root.login, pin: secret }, function (d) {
            if (d.right || d.ok !== true) {          // right, or the service can't tell: PAM decides
                authenticator.respond(secret)
                return
            }
            checking = false
            wrongPin(d.wait || 0)
            if (queued !== "") { const next = queued; queued = ""; checkPin(next) }
        })
    }

    function unlock() {
        if (noPassword) {
            Qt.quit()
            return
        }
        if (!field.enabled || password.text === "")
            return
        message.text = ""
        if (pinMode && /^[0-9]+$/.test(password.text)) {
            const pin = password.text
            password.text = ""
            if (checking) queued = pin
            else checkPin(pin)
            return
        }
        if (checking) {               // the last try isn't answered yet
            queued = password.text
            password.text = ""
            return
        }
        checking = true
        authenticator.respond(password.text)
        if (pinMode)
            password.text = ""
    }

    FontLoader { id: wordFont; source: root.assets + "Montserrat-Light.ttf" }
    FontLoader { source: root.assets + "Montserrat-Medium.ttf" }

    KCoreAddons.KUser { id: kuser }
    KeyboardIndicator.KeyState { id: capsLock; key: Qt.Key_CapsLock }
    SessionManagement { id: sessionManagement }

    Connections {
        target: authenticator
        function onFailed(kind) {
            if (kind != 0) // fingerprint and smartcard are turned off on Infinity
                return
            // Only a PIN or password that was sent is wrong. A check restarted while PAM still
            // finishes the last one fails at once, and did again and again (~40 times in 1.5 s:
            // the box shook like mad): such a failure just tries again, a little later.
            if (!root.checking) {
                graceTimer.interval = 500
                graceTimer.restart()
                return
            }
            message.color = root.errorColor
            message.text = root.pinMode ? "Wrong PIN. Try again." : "Wrong password. Try again."
            if (!root.pinMode)
                password.text = ""
            root.checking = false
            shake.restart()
            graceTimer.interval = 50
            graceTimer.restart()
        }
        function onSucceeded() {
            if (authenticator.hadPrompt) {
                Qt.quit()
            } else {
                root.noPassword = true
                go.forceActiveFocus()
            }
        }
        function onInfoMessageChanged() {
            message.color = root.inkSoft
            message.text = authenticator.infoMessage
        }
        function onErrorMessageChanged() {
            message.color = root.errorColor
            message.text = authenticator.errorMessage
        }
        function onPromptForSecretChanged() {
            password.forceActiveFocus()
            if (root.queued !== "" && !root.pinMode) {   // a password typed while the last one was checked
                const next = root.queued
                root.queued = ""
                root.checking = true
                authenticator.respond(next)
            }
        }
    }
    Connections {
        target: sessionManagement
        function onAboutToSuspend() { root.clearPassword() }
    }
    onClearPassword: password.text = ""

    // After a wrong PIN or password, ask again at once (PAM itself waits a moment).
    Timer {
        id: graceTimer
        interval: 50
        onTriggered: {
            authenticator.startAuthenticating()
            password.forceActiveFocus()
        }
    }

    Timer {
        id: clock
        property date now: new Date()
        interval: 1000
        running: true
        repeat: true
        triggeredOnStart: true
        onTriggered: now = new Date()
    }

    Rectangle {
        id: content
        anchors.fill: parent
        color: "#070B1C"

        NumberAnimation on opacity { from: 0; to: 1; duration: 450; easing.type: Easing.InOutQuad }

        Image {
            anchors.fill: parent
            source: root.assets + "background.png"
            fillMode: Image.PreserveAspectCrop
        }
        Ui.InfinityMark { screen: content }

        MouseArea {
            anchors.fill: parent
            hoverEnabled: true
            onPositionChanged: root.wake()
            onClicked: { root.wake(); password.forceActiveFocus() }
        }

        // ---------- the card ----------
        Rectangle {
            id: card
            anchors.centerIn: parent
            width: 25 * root.u
            height: column.implicitHeight + 3.8 * root.u
            radius: 1.4 * root.u
            color: root.glass
            border.color: root.line
            border.width: 1

            // back from "Forgot your PIN?" (to the ways, or to the PIN box)
            Rectangle {
                visible: forgot.visible
                z: 1
                x: 1.1 * root.u
                y: 1.1 * root.u
                width: 2.2 * root.u
                height: width
                radius: width / 2
                color: forgotBack.containsMouse ? Qt.rgba(1, 1, 1, 0.14) : Qt.rgba(1, 1, 1, 0.06)
                border.color: Qt.rgba(1, 1, 1, 0.16)
                Image {
                    anchors.centerIn: parent
                    source: root.assets + "icons/arrow.svg"
                    sourceSize.width: 0.95 * root.u
                    sourceSize.height: 0.95 * root.u
                    rotation: 180
                }
                MouseArea { id: forgotBack; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: forgot.back() }
            }
            Column {
                id: column
                y: 2.2 * root.u
                anchors.horizontalCenter: parent.horizontalCenter
                width: parent.width - 4.4 * root.u
                spacing: 0.9 * root.u

                // "Forgot your PIN?" is a page of its own in the card: its title instead of the clock
                Text {
                    anchors.horizontalCenter: parent.horizontalCenter
                    visible: forgot.visible
                    text: root.pinLength > 0 ? "Forgot your PIN?" : "Forgot your password?"
                    color: root.ink
                    font.family: wordFont.name
                    font.pixelSize: 1.6 * root.u
                }
                Text {
                    anchors.horizontalCenter: parent.horizontalCenter
                    visible: !forgot.visible
                    text: Qt.formatTime(clock.now, "h:mm AP")
                    color: root.ink
                    font.family: wordFont.name
                    font.weight: Font.Light
                    font.pixelSize: 3.4 * root.u
                }
                Text {
                    anchors.horizontalCenter: parent.horizontalCenter
                    visible: !forgot.visible
                    text: Qt.formatDate(clock.now, "dddd, MMMM d")
                    color: root.inkSoft
                    font.family: root.uiFont
                    font.pixelSize: root.u
                }
                Row {
                    anchors.horizontalCenter: parent.horizontalCenter
                    topPadding: 0.6 * root.u
                    spacing: 0.7 * root.u
                    Ui.Avatar {
                        size: 3 * root.u
                        letter: root.accountName || kuser.fullName || kscreenlocker_userName
                        source: root.accountPicture
                        fontFamily: wordFont.name
                        anchors.verticalCenter: parent.verticalCenter
                    }
                    Text {
                        anchors.verticalCenter: parent.verticalCenter
                        text: root.accountName || kuser.fullName || kscreenlocker_userName
                        color: root.ink
                        font.family: root.uiFont
                        font.weight: Font.Medium
                        font.pixelSize: 1.35 * root.u
                    }
                }

                // Password field: on a wrong password only this field shakes.
                Item {
                    id: field
                    opacity: root.waitLeft > 0 ? 0.45 : 1
                    // "Forgot your PIN?" takes its place
                    visible: !forgot.visible
                    width: parent.width
                    height: 2.9 * root.u
                    enabled: !graceTimer.running
                    transform: Translate { id: shakeOffset }

                    Rectangle {
                        anchors.fill: parent
                        radius: height / 2
                        visible: !root.noPassword
                        color: Qt.rgba(1, 1, 1, 0.08)
                        border.color: password.activeFocus ? root.royalLight : Qt.rgba(1, 1, 1, 0.16)
                        border.width: 1
                    }
                    TextInput {
                        id: password
                        enabled: root.waitLeft === 0
                        visible: !root.noPassword
                        anchors.left: parent.left
                        anchors.leftMargin: 1.2 * root.u
                        anchors.right: eye.left
                        anchors.rightMargin: 0.6 * root.u
                        anchors.verticalCenter: parent.verticalCenter
                        echoMode: eye.shown ? TextInput.Normal : TextInput.Password
                        onTextChanged: if (root.pinMode && text.length === root.pinLength && /^[0-9]+$/.test(text)) root.unlock()
                        passwordCharacter: "•"
                        color: root.ink
                        selectionColor: root.royal
                        font.family: root.uiFont
                        font.pixelSize: root.u
                        clip: true
                        focus: true
                        Keys.onPressed: event => { root.wake(); event.accepted = false }
                        Keys.onReturnPressed: root.unlock()
                        Keys.onEnterPressed: root.unlock()
                        // Escape turns the screen off (kscreenlocker); start over.
                        Keys.onEscapePressed: event => { password.text = ""; event.accepted = false }

                        Text {
                            anchors.verticalCenter: parent.verticalCenter
                            visible: password.text.length === 0
                            text: root.pinLength > 0 ? "PIN" : "Password"
                            color: Qt.rgba(232 / 255, 236 / 255, 250 / 255, 0.5)
                            font: password.font
                        }
                    }
                    // the eye: shows what was typed
                    Item {
                        id: eye
                        property bool shown: false
                        visible: !root.noPassword
                        width: 1.25 * root.u; height: width
                        anchors.right: go.left
                        anchors.rightMargin: 0.7 * root.u
                        anchors.verticalCenter: parent.verticalCenter
                        Image {
                            anchors.fill: parent
                            source: root.assets + (eye.shown ? "icons/eye-off.svg" : "icons/eye.svg")
                            sourceSize.width: width * 2; sourceSize.height: height * 2
                            opacity: eyeArea.containsMouse ? 1 : 0.6
                        }
                        MouseArea { id: eyeArea; anchors.fill: parent; anchors.margins: -0.4 * root.u; hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                                    onClicked: { eye.shown = !eye.shown; password.forceActiveFocus() } }
                    }
                    Rectangle {
                        id: go
                        // a PIN unlocks by itself: no arrow then
                        visible: root.noPassword || !root.pinMode
                        width: root.noPassword ? parent.width : visible ? 2.2 * root.u : 0
                        height: root.noPassword ? parent.height : width
                        radius: height / 2
                        anchors.right: parent.right
                        anchors.rightMargin: root.noPassword ? 0 : 0.35 * root.u
                        anchors.verticalCenter: parent.verticalCenter
                        color: goArea.containsMouse ? root.royalLight : root.royal
                        Keys.onReturnPressed: root.unlock()
                        Keys.onEnterPressed: root.unlock()
                        Image {
                            anchors.centerIn: parent
                            visible: !root.noPassword
                            source: root.assets + "icons/arrow.svg"
                            sourceSize.width: root.u
                            sourceSize.height: root.u
                        }
                        Text {
                            anchors.centerIn: parent
                            visible: root.noPassword
                            text: "Unlock"
                            color: "white"
                            font.family: root.uiFont
                            font.weight: Font.Medium
                            font.pixelSize: root.u
                        }
                        MouseArea {
                            id: goArea
                            anchors.fill: parent
                            hoverEnabled: true
                            cursorShape: Qt.PointingHandCursor
                            onClicked: root.unlock()
                        }
                    }

                    SequentialAnimation {
                        id: shake
                        NumberAnimation { target: shakeOffset; property: "x"; to: -0.6 * root.u; duration: 60 }
                        NumberAnimation { target: shakeOffset; property: "x"; to: 0.6 * root.u; duration: 80 }
                        NumberAnimation { target: shakeOffset; property: "x"; to: -0.6 * root.u; duration: 80 }
                        NumberAnimation { target: shakeOffset; property: "x"; to: 0.6 * root.u; duration: 80 }
                        NumberAnimation { target: shakeOffset; property: "x"; to: 0; duration: 60 }
                    }
                }

                Text {
                    id: message
                    visible: !forgot.visible
                    width: parent.width
                    height: 1.4 * root.u
                    horizontalAlignment: Text.AlignHCenter
                    elide: Text.ElideRight
                    color: root.errorColor
                    font.family: root.uiFont
                    font.pixelSize: 0.9 * root.u
                }

                Row {
                    anchors.horizontalCenter: parent.horizontalCenter
                    visible: !forgot.visible
                    spacing: 0.4 * root.u
                    Image {
                        anchors.verticalCenter: parent.verticalCenter
                        source: root.assets + "icons/lock.svg"
                        sourceSize.width: 0.9 * root.u
                        sourceSize.height: 0.9 * root.u
                        opacity: 0.6
                    }
                    Text {
                        anchors.verticalCenter: parent.verticalCenter
                        text: capsLock.locked ? "Locked · Caps Lock is on" : "Locked"
                        color: root.muted
                        font.family: root.uiFont
                        font.pixelSize: 0.8 * root.u
                    }
                }

                // Forgot your PIN? The same ways as on the sign-in screen (Ui.Forgot); the
                // lock screen may not use the network, so its requests go through the
                // session bus helper (org.infinity.AccountHelper, infinity-account).
                Text {
                    anchors.horizontalCenter: parent.horizontalCenter
                    visible: !forgot.visible && !root.noPassword && (root.hasTotp || root.hasKey || root.accountProvider !== "")
                    text: root.pinLength > 0 ? "Forgot your PIN?" : "Forgot your password?"
                    color: forgotArea.containsMouse ? root.ink : root.muted
                    font.family: root.uiFont
                    font.pixelSize: 0.85 * root.u
                    font.underline: forgotArea.containsMouse
                    MouseArea {
                        id: forgotArea
                        anchors.fill: parent
                        anchors.margins: -0.4 * root.u
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        onClicked: { message.text = ""; forgot.open() }
                    }
                }
                Ui.Forgot {
                    id: forgot
                    width: parent.width
                    userName: root.login
                    email: root.accountEmail
                    hasTotp: root.hasTotp
                    hasEmail: root.accountProvider !== ""
                    hasKey: root.hasKey
                    request: function (method, path, body, done) {
                        const reply = DBus.SessionBus.asyncCall({
                            service: "org.infinity.AccountHelper", path: "/org/infinity/AccountHelper",
                            iface: "org.infinity.AccountHelper", member: "Request",
                            arguments: [JSON.stringify({ method: method, path: path, body: body })] })
                        reply.finished.connect(function () {
                            let d = { ok: false, error: "The Infinity Account service isn't answering." }
                            if (!reply.isError) try { d = JSON.parse(reply.value) } catch (e) {}
                            done(d)
                        })
                    }
                    onFinished: { root.loadAccount(); message.color = "#5ED6A0"; message.text = "Your new PIN is saved. Type it above." }
                    onVisibleChanged: if (!visible) password.forceActiveFocus()
                }
            }
        }

        // ---------- now playing (only while a player is open) ----------
        Repeater {
            model: Mpris.MultiplexerModel { }
            delegate: Rectangle {
                anchors.horizontalCenter: parent.horizontalCenter
                anchors.bottom: parent.bottom
                anchors.bottomMargin: root.height * 0.06
                width: mediaRow.implicitWidth + 1.5 * root.u
                height: 4 * root.u
                radius: root.u
                color: root.glass
                border.color: root.line
                border.width: 1

                Row {
                    id: mediaRow
                    x: 0.6 * root.u
                    anchors.verticalCenter: parent.verticalCenter
                    spacing: 0.9 * root.u

                    Rectangle {
                        width: 2.8 * root.u
                        height: width
                        radius: 0.6 * root.u
                        clip: true
                        gradient: Gradient {
                            GradientStop { position: 0; color: "#7D97FF" }
                            GradientStop { position: 1; color: "#2B4FD8" }
                        }
                        Image {
                            anchors.fill: parent
                            source: model.artUrl || ""
                            fillMode: Image.PreserveAspectCrop
                            asynchronous: true
                        }
                    }
                    Column {
                        anchors.verticalCenter: parent.verticalCenter
                        width: Math.min(14 * root.u, Math.max(trackText.implicitWidth, appText.implicitWidth))
                        Text {
                            id: trackText
                            width: parent.width
                            elide: Text.ElideRight
                            text: model.track || "No title"
                            color: root.ink
                            font.family: root.uiFont
                            font.weight: Font.Medium
                            font.pixelSize: 0.9 * root.u
                        }
                        Text {
                            id: appText
                            width: parent.width
                            elide: Text.ElideRight
                            text: model.artist || model.identity || ""
                            color: root.muted
                            font.family: root.uiFont
                            font.pixelSize: 0.78 * root.u
                        }
                    }
                    Repeater {
                        model: [
                            { icon: "previous", run: () => model.container.Previous(), on: model.canGoPrevious },
                            { icon: model.playbackStatus === Mpris.PlaybackStatus.Playing ? "pause" : "play",
                              run: () => model.container.PlayPause(), on: true },
                            { icon: "next", run: () => model.container.Next(), on: model.canGoNext }
                        ]
                        delegate: Rectangle {
                            anchors.verticalCenter: parent.verticalCenter
                            width: 2 * root.u
                            height: width
                            radius: width / 2
                            color: mediaArea.containsMouse ? Qt.rgba(1, 1, 1, 0.08) : "transparent"
                            opacity: modelData.on ? 1 : 0.35
                            Image {
                                anchors.centerIn: parent
                                source: root.assets + "icons/" + modelData.icon + ".svg"
                                sourceSize.width: root.u
                                sourceSize.height: root.u
                            }
                            MouseArea {
                                id: mediaArea
                                anchors.fill: parent
                                hoverEnabled: true
                                enabled: modelData.on
                                onClicked: modelData.run()
                            }
                        }
                    }
                }
            }
        }

        // ---------- Sleep / Restart / Shut down (bottom right, as on the login screen) ----------
        Row {
            anchors.right: parent.right
            anchors.rightMargin: root.width * 0.04
            anchors.bottom: parent.bottom
            anchors.bottomMargin: root.height * 0.05
            spacing: root.u

            Ui.PowerButton {
                u: root.u; fontFamily: root.uiFont; icon: root.assets + "icons/sleep.svg"; label: "Sleep"
                visible: root.suspendToRamSupported
                onActivated: root.suspendToRam()
            }
            Ui.PowerButton {
                u: root.u; fontFamily: root.uiFont; icon: root.assets + "icons/restart.svg"; label: "Restart"
                visible: sessionManagement.canReboot
                onActivated: sessionManagement.requestReboot(SessionManagement.Skip)
            }
            Ui.PowerButton {
                u: root.u; fontFamily: root.uiFont; icon: root.assets + "icons/off.svg"; label: "Shut down"
                visible: sessionManagement.canShutdown
                onActivated: sessionManagement.requestShutdown(SessionManagement.Skip)
            }
        }

        // ---------- keyboard layout (bottom left, only with several) ----------
        Rectangle {
            anchors.left: parent.left
            anchors.leftMargin: root.width * 0.04
            anchors.bottom: parent.bottom
            anchors.bottomMargin: root.height * 0.05 + 0.6 * root.u
            visible: layouts.hasMultipleKeyboardLayouts
            width: layoutRow.implicitWidth + 1.4 * root.u
            height: 2.4 * root.u
            radius: height / 2
            color: root.glass
            border.color: root.line
            border.width: 1
            Row {
                id: layoutRow
                anchors.centerIn: parent
                spacing: 0.5 * root.u
                Image {
                    anchors.verticalCenter: parent.verticalCenter
                    source: root.assets + "icons/keyboard.svg"
                    sourceSize.width: root.u
                    sourceSize.height: root.u
                }
                Text {
                    anchors.verticalCenter: parent.verticalCenter
                    text: layouts.layoutNames.shortName.toUpperCase()
                    color: root.inkSoft
                    font.family: root.uiFont
                    font.pixelSize: 0.85 * root.u
                }
            }
            // A click switches to the next layout.
            PW.KeyboardLayoutSwitcher {
                id: layouts
                anchors.fill: parent
            }
        }
    }

    // Passwords are typed in a Latin layout: like macOS, switch to the first
    // one (e.g. from Arabic to English) when the screen locks. The layout
    // button at the bottom right still switches by hand.
    property bool layoutPicked: false
    function latinLayout() {
        const list = layouts.keyboardLayout.layoutsList
        if (layoutPicked || list.length === 0) // the list arrives a moment later
            return
        layoutPicked = true
        const nonLatin = ["ara", "ir", "af", "pk", "il", "ru", "ua", "by", "bg", "mk", "rs", "gr",
                          "am", "ge", "th", "kr", "jp", "cn", "in", "bd", "np", "lk", "kh", "la", "mm", "et"]
        for (let i = 0; i < list.length; ++i) {
            if (nonLatin.indexOf(list[i].shortName) < 0) {
                if (layouts.keyboardLayout.layout !== i)
                    layouts.keyboardLayout.layout = i
                return
            }
        }
    }

    Connections {
        target: layouts.keyboardLayout
        function onLayoutsListChanged() { root.latinLayout() }
    }

    Component.onCompleted: {
        loadAccount()
        // start the session bus helper now, so the first PIN check answers at once
        forgot.request("GET", "/status?user=" + encodeURIComponent(root.login), null, function () {})
        latinLayout()
        authenticator.startAuthenticating()
        password.forceActiveFocus()
    }
}
