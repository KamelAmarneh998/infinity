// Infinity: accounts made before the 2026-10 look get the slimmer top bar
// and the dock that floats above windows (as in the layout script).
// Plasma runs each script here once per account.
panels().forEach(function (panel) {
    if (panel.location == "top") {
        panel.height = 24
    } else if (panel.location == "bottom") {
        panel.height = 42
        panel.floating = true
        panel.hiding = "windowsgobelow"
    }
})
