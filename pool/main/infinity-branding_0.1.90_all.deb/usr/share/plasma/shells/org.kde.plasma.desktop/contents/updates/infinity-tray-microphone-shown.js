// Infinity: the microphone Plasma shows while something listens back on the top
// bar (tray-tidy had moved it into the arrow): listening for "Infinity" must be seen.
panels().forEach(function (panel) {
    panel.widgets("org.kde.plasma.systemtray").forEach(function (tray) {
        tray.currentConfigGroup = ["General"]
        var v = tray.readConfig("hiddenItems", [])
        var items = typeof v === "string" ? (v ? v.split(",") : []) : Array.prototype.slice.call(v)
        var at = items.indexOf("plasmashell_microphone")
        if (at >= 0) {
            items.splice(at, 1)
            tray.writeConfig("hiddenItems", items)
        }
    })
})
