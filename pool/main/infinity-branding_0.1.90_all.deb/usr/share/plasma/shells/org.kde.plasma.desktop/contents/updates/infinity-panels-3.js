// Infinity: the top bar slim again (24 px) where infinity-panels-2.js
// left it 40 px tall (Plasma had measured it with the dock's round corners).
panels().forEach(function (panel) {
    if (panel.location == "top")
        panel.height = 24
})
