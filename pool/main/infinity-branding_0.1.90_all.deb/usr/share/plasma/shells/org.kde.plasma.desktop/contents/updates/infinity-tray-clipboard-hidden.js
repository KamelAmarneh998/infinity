// Infinity: the clipboard back in the tray, hidden in the arrow (no icon in
// the top bar). Without it loaded, Meta+V (clipboard history) did nothing.
panels().forEach(function (panel) {
    panel.widgets("org.kde.plasma.systemtray").forEach(function (tray) {
        tray.currentConfigGroup = ["General"]
        var list = function (key) {
            var v = tray.readConfig(key, [])
            return typeof v === "string" ? (v ? v.split(",") : []) : Array.prototype.slice.call(v)
        }
        var add = function (key) {
            var items = list(key)
            if (items.indexOf("org.kde.plasma.clipboard") < 0)
                items.push("org.kde.plasma.clipboard")
            tray.writeConfig(key, items)
        }
        add("hiddenItems")
        add("extraItems")
    })
})
